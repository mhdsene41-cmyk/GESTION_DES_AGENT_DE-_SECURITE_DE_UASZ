
document.addEventListener("DOMContentLoaded", function () {
    const statut = document.getElementById("statut");
    const arrivee = document.getElementById("heure_arrivee");
    const depart = document.getElementById("heure_depart");

    function gererChampsHoraires() {
        if (!statut || !arrivee || !depart) {
            return;
        }

        const estAbsent = statut.value === "absent";

        arrivee.disabled = estAbsent;
        depart.disabled = estAbsent;

        if (estAbsent) {
            arrivee.value = "";
            depart.value = "";
        }
    }

    if (statut) {
        statut.addEventListener("change", gererChampsHoraires);
        gererChampsHoraires();
    }

    const formulaire = document.querySelector(".form-presence");

    if (formulaire) {
        formulaire.addEventListener("submit", function (evenement) {
            if (
                statut.value !== "absent" &&
                arrivee.value &&
                depart.value &&
                depart.value <= arrivee.value
            ) {
                evenement.preventDefault();
                alert("L'heure de départ doit être après l'heure d'arrivée.");
                depart.focus();
            }
        });
    }
});


document.addEventListener("DOMContentLoaded", function () {

    const tableau = document.getElementById("tableauCandidatures");
    const formulaire = document.getElementById("formulaireCandidature");
    const modal = document.getElementById("modalCandidature");
    const modalDetails = document.getElementById("modalDetails");

    const recherche = document.getElementById("rechercheCandidat");
    const filtreStatut = document.getElementById("filtreStatut");
    const filtrePoste = document.getElementById("filtrePoste");

    const boutonEnregistrer = document.getElementById("boutonEnregistrer");

    let candidatures = [];
    let idEnModification = null;

    const jetonCSRF = formulaire.querySelector('[name="jeton_csrf"]').value;

    // Protection contre l'injection HTML
    function echapperHTML(texte) {
        return String(texte ?? "").replace(/[&<>"']/g, caractere => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[caractere]);
    }

    // Date du jour
    document.getElementById("dateActuelle").textContent =
        new Date().toLocaleDateString("fr-FR", {
            weekday: "long",
            day: "numeric",
            month: "long",
            year: "numeric"
        });

    function formaterDate(date) {
        if (!date) return "-";

        const parties = date.split("-");
        return `${parties[2]}/${parties[1]}/${parties[0]}`;
    }

    // Communication avec PHP
    async function envoyerRequete(action, donnees = {}) {

        const formulaireDonnees = new FormData();

        formulaireDonnees.append("action", action);
        formulaireDonnees.append("jeton_csrf", jetonCSRF);

        Object.entries(donnees).forEach(([cle, valeur]) => {
            formulaireDonnees.append(cle, valeur ?? "");
        });

        const reponse = await fetch(window.location.href, {
            method: "POST",
            body: formulaireDonnees
        });

        const resultat = await reponse.json();

        if (!reponse.ok || !resultat.succes) {
            throw new Error(resultat.message || "Une erreur est survenue.");
        }

        return resultat;
    }

    // Chargement des candidatures depuis MySQL
    async function chargerCandidatures() {

        tableau.innerHTML = `
            <tr><td colspan="7">Chargement...</td></tr>
        `;

        try {
            const resultat = await envoyerRequete("lister");
            candidatures = resultat.donnees || [];
            filtrerCandidatures();

        } catch (erreur) {
            tableau.innerHTML = `
                <tr>
                    <td colspan="7" class="empty-message">
                        ${echapperHTML(erreur.message)}
                    </td>
                </tr>
            `;

            alert(erreur.message);
        }
    }

    // Statistiques
    function actualiserStatistiques() {

        document.getElementById("totalCandidatures").textContent =
            candidatures.length;

        document.getElementById("candidaturesAttente").textContent =
            candidatures.filter(c => c.statut === "En attente").length;

        document.getElementById("candidaturesAcceptees").textContent =
            candidatures.filter(c => c.statut === "Acceptée").length;

        document.getElementById("candidaturesRefusees").textContent =
            candidatures.filter(c => c.statut === "Refusée").length;
    }

    // Affichage du tableau
    function afficherCandidatures(liste) {

        tableau.innerHTML = "";

        if (liste.length === 0) {
            tableau.innerHTML = `
                <tr>
                    <td colspan="7" class="empty-message">
                        Aucune candidature trouvée.
                    </td>
                </tr>
            `;
        } else {

            liste.forEach(candidat => {

                let classeStatut = "status-pending";

                if (candidat.statut === "Acceptée") {
                    classeStatut = "status-accepted";
                } else if (candidat.statut === "Refusée") {
                    classeStatut = "status-refused";
                }

                const ligne = document.createElement("tr");

                ligne.innerHTML = `
                    <td><strong>${echapperHTML(candidat.reference)}</strong></td>
                    <td>${echapperHTML(candidat.prenom)} ${echapperHTML(candidat.nom)}</td>
                    <td>${echapperHTML(candidat.telephone)}</td>
                    <td>${echapperHTML(candidat.poste)}</td>
                    <td>${formaterDate(candidat.date_candidature)}</td>
                    <td>
                        <span class="status ${classeStatut}">
                            ${echapperHTML(candidat.statut)}
                        </span>
                    </td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn-details" data-action="details" data-id="${candidat.id}">
                                Détails
                            </button>
                            <button class="btn-edit" data-action="modifier" data-id="${candidat.id}">
                                Modifier
                            </button>
                            <button class="btn-delete" data-action="supprimer" data-id="${candidat.id}">
                                Supprimer
                            </button>
                        </div>
                    </td>
                `;

                tableau.appendChild(ligne);
            });
        }

        document.getElementById("nombreResultats").textContent =
            `${liste.length} candidature(s)`;

        actualiserStatistiques();
    }

    // Recherche et filtres
    function filtrerCandidatures() {

        const mot = recherche.value.toLowerCase().trim();
        const statut = filtreStatut.value;
        const poste = filtrePoste.value;

        const resultats = candidatures.filter(candidat => {

            const texte = [
                candidat.reference,
                candidat.nom,
                candidat.prenom,
                candidat.telephone,
                candidat.poste
            ].join(" ").toLowerCase();

            return texte.includes(mot)
                && (!statut || candidat.statut === statut)
                && (!poste || candidat.poste === poste);
        });

        afficherCandidatures(resultats);
    }

    recherche.addEventListener("input", filtrerCandidatures);
    filtreStatut.addEventListener("change", filtrerCandidatures);
    filtrePoste.addEventListener("change", filtrerCandidatures);

    // Gestion des modales
    function ouvrirModal() {
        modal.classList.add("show");
    }

    function fermerModal() {
        modal.classList.remove("show");
        formulaire.reset();
        idEnModification = null;

        document.getElementById("idCandidature").value = "";
        document.getElementById("titreModal").textContent =
            "Nouvelle candidature";

        document.getElementById("nomCV").textContent = "";
        document.getElementById("nomPhoto").textContent = "";

        boutonEnregistrer.textContent = "Enregistrer la candidature";
    }

    function fermerDetails() {
        modalDetails.classList.remove("show");
    }

    document.getElementById("ouvrirModal").addEventListener("click", () => {

        fermerModal();

        document.getElementById("dateCandidature").value =
            new Date().toISOString().slice(0, 10);

        ouvrirModal();
    });

    document.getElementById("fermerModal").addEventListener("click", fermerModal);
    document.getElementById("annulerModal").addEventListener("click", fermerModal);
    document.getElementById("fermerDetails").addEventListener("click", fermerDetails);

    modal.addEventListener("click", event => {
        if (event.target === modal) fermerModal();
    });

    modalDetails.addEventListener("click", event => {
        if (event.target === modalDetails) fermerDetails();
    });

    // Indiquer les fichiers sélectionnés
    document.getElementById("cv").addEventListener("change", function () {
        document.getElementById("nomCV").textContent =
            this.files.length ? this.files[0].name : "";
    });

    document.getElementById("photo").addEventListener("change", function () {
        document.getElementById("nomPhoto").textContent =
            this.files.length ? this.files[0].name : "";
    });

    // Enregistrement et modification
    formulaire.addEventListener("submit", async function (event) {

        event.preventDefault();

        const donnees = new FormData(formulaire);

        donnees.append("action", idEnModification ? "modifier" : "ajouter");

        boutonEnregistrer.disabled = true;
        boutonEnregistrer.textContent = "Enregistrement...";

        try {

            const reponse = await fetch(window.location.href, {
                method: "POST",
                body: donnees
            });

            const resultat = await reponse.json();

            if (!reponse.ok || !resultat.succes) {
                throw new Error(resultat.message || "Erreur d'enregistrement.");
            }

            alert(resultat.message);

            fermerModal();
            await chargerCandidatures();

        } catch (erreur) {
            alert(erreur.message);
        } finally {
            boutonEnregistrer.disabled = false;
            boutonEnregistrer.textContent = idEnModification
                ? "Modifier la candidature"
                : "Enregistrer la candidature";
        }
    });

    // Affichage des détails
    function afficherDetails(candidat) {

        const contenu = document.getElementById("contenuDetails");

        const lienCV = candidat.cv
            ? `<a href="../../../${echapperHTML(candidat.cv)}" target="_blank" rel="noopener">Consulter le CV</a>`
            : "Non fourni";

        const lienPhoto = candidat.photo
            ? `<a href="../../../${echapperHTML(candidat.photo)}" target="_blank" rel="noopener">Consulter la photo</a>`
            : "Non fournie";

        contenu.innerHTML = `
            <div class="detail-item">
                <small>Référence</small>
                <strong>${echapperHTML(candidat.reference)}</strong>
            </div>

            <div class="detail-item">
                <small>Nom complet</small>
                <strong>${echapperHTML(candidat.prenom)} ${echapperHTML(candidat.nom)}</strong>
            </div>

            <div class="detail-item">
                <small>Téléphone</small>
                <strong>${echapperHTML(candidat.telephone)}</strong>
            </div>

            <div class="detail-item">
                <small>Adresse e-mail</small>
                <strong>${echapperHTML(candidat.email || "Non renseignée")}</strong>
            </div>

            <div class="detail-item">
                <small>Poste demandé</small>
                <strong>${echapperHTML(candidat.poste)}</strong>
            </div>

            <div class="detail-item">
                <small>Date de candidature</small>
                <strong>${formaterDate(candidat.date_candidature)}</strong>
            </div>

            <div class="detail-item">
                <small>Statut</small>
                <strong>${echapperHTML(candidat.statut)}</strong>
            </div>

            <div class="detail-item">
                <small>CV</small>
                <strong>${lienCV}</strong>
            </div>

            <div class="detail-item">
                <small>Photo</small>
                <strong>${lienPhoto}</strong>
            </div>

            <div class="detail-item">
                <small>Observations</small>
                <strong>${echapperHTML(candidat.observation || "Aucune observation")}</strong>
            </div>
        `;

        modalDetails.classList.add("show");
    }

    // Actions du tableau
    tableau.addEventListener("click", async function (event) {

        const bouton = event.target.closest("button[data-action]");

        if (!bouton) return;

        const id = Number(bouton.dataset.id);
        const action = bouton.dataset.action;

        const candidat = candidatures.find(c => Number(c.id) === id);

        if (!candidat) return;

        if (action === "details") {
            afficherDetails(candidat);
        }

        if (action === "modifier") {

            idEnModification = id;

            document.getElementById("titreModal").textContent =
                "Modifier la candidature";

            document.getElementById("idCandidature").value = id;

            document.getElementById("nom").value = candidat.nom;
            document.getElementById("prenom").value = candidat.prenom;
            document.getElementById("telephone").value = candidat.telephone;
            document.getElementById("email").value = candidat.email || "";
            document.getElementById("poste").value = candidat.poste;
            document.getElementById("dateCandidature").value =
                candidat.date_candidature;
            document.getElementById("statut").value = candidat.statut;
            document.getElementById("observation").value =
                candidat.observation || "";

            document.getElementById("nomCV").textContent =
                candidat.cv ? "Un CV est déjà enregistré. Choisissez un autre fichier pour le remplacer." : "";

            document.getElementById("nomPhoto").textContent =
                candidat.photo ? "Une photo est déjà enregistrée. Choisissez une autre photo pour la remplacer." : "";

            boutonEnregistrer.textContent = "Modifier la candidature";

            ouvrirModal();
        }

        if (action === "supprimer") {

            const confirmation = confirm(
                `Voulez-vous vraiment supprimer le dossier ${candidat.reference} ?`
            );

            if (!confirmation) return;

            try {

                const resultat = await envoyerRequete("supprimer", { id });

                alert(resultat.message);
                await chargerCandidatures();

            } catch (erreur) {
                alert(erreur.message);
            }
        }
    });

    // Déconnexion
    document.getElementById("deconnexion").addEventListener("click", function (event) {

        event.preventDefault();

        if (confirm("Voulez-vous vraiment vous déconnecter ?")) {
            window.location.href = "../authentification/connexion.php";
        }
    });

    // Démarrage
    chargerCandidatures();

});


/* =========================================
   GESTION SECURITE UASZ
   JAVASCRIPT DE CONNEXION
========================================= */


/* 1. AFFICHER OU MASQUER LE MOT DE PASSE */

const champMotDePasse = document.getElementById("mot_de_passe");

const boutonOeil = document.getElementById("afficherMotDePasse");

const iconeOeil = document.getElementById("iconeOeil");


if (champMotDePasse && boutonOeil && iconeOeil) {

    boutonOeil.addEventListener("click", function () {

        const motDePasseVisible =
            champMotDePasse.type === "text";

        if (motDePasseVisible) {

            // Masquer le mot de passe
            champMotDePasse.type = "password";

            boutonOeil.setAttribute(
                "aria-label",
                "Afficher le mot de passe"
            );

            boutonOeil.setAttribute(
                "title",
                "Afficher le mot de passe"
            );

            boutonOeil.setAttribute("aria-pressed", "false");

            // Afficher l'icône œil
            iconeOeil.innerHTML = `
                <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/>
                <circle cx="12" cy="12" r="3"/>
            `;

        } else {

            // Afficher le mot de passe
            champMotDePasse.type = "text";

            boutonOeil.setAttribute(
                "aria-label",
                "Masquer le mot de passe"
            );

            boutonOeil.setAttribute(
                "title",
                "Masquer le mot de passe"
            );

            boutonOeil.setAttribute("aria-pressed", "true");

            // Afficher l'icône œil barré
            iconeOeil.innerHTML = `
                <path d="M3 3l18 18"/>
                <path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"/>
                <path d="M9.9 5.2A10.5 10.5 0 0 1 12 5
                c6.4 0 10 7 10 7a13.5 13.5 0 0 1-3 3.7"/>
                <path d="M6.6 6.6C3.6 8.4 2 12 2 12
                s3.6 7 10 7c1.1 0 2.1-.2 3-.5"/>
            `;
        }

    });

}


/* 2. VERIFICATION DU FORMULAIRE */

const formulaire = document.querySelector("form");

if (formulaire) {

    formulaire.addEventListener("submit", function (event) {

        const identifiant = formulaire.querySelector(
            'input[name="identifiant"]'
        );

        const motDePasse = formulaire.querySelector(
            'input[name="mot_de_passe"]'
        );

        if (
            !identifiant ||
            !motDePasse ||
            identifiant.value.trim() === "" ||
            motDePasse.value === ""
        ) {

            event.preventDefault();

            alert("Veuillez remplir tous les champs.");

        }

        // Si les champs sont remplis,
        // le formulaire est envoyé normalement à PHP.

    });

}

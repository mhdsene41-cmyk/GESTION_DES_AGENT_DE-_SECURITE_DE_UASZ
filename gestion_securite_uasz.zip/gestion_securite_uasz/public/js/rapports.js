
document.addEventListener("DOMContentLoaded", function () {

    // ==========================================
    // 1. RECUPERATION DES ELEMENTS HTML
    // ==========================================

    const dateDebut = document.getElementById("dateDebut");
    const dateFin = document.getElementById("dateFin");

    const btnFiltrer = document.getElementById("btnFiltrer");
    const btnReinitialiser = document.getElementById("btnReinitialiser");
    const btnImprimer = document.getElementById("btnImprimer");

    const couleurs = [
        "#1d4ed8",
        "#16a34a",
        "#f59e0b",
        "#dc2626",
        "#7c3aed",
        "#0891b2"
    ];

    let donneesRapport = null;


    // ==========================================
    // 2. FONCTIONS UTILITAIRES
    // ==========================================

    function afficherNombre(id, valeur) {

        const element = document.getElementById(id);

        if (element) {
            element.textContent = Number(valeur || 0).toLocaleString("fr-FR");
        }
    }


    function totalObjet(objet) {

        return Object.values(objet || {}).reduce(
            (total, valeur) => total + Number(valeur || 0),
            0
        );
    }


    function libelleStatut(statut) {

        const libelles = {
            present: "Présent",
            absent: "Absent",
            retard: "En retard",

            nouveau: "Nouveau",
            en_cours: "En cours",
            resolu: "Résolu",
            cloture: "Clôturé",

            "En attente": "En attente",
            "Acceptée": "Acceptée",
            "Refusée": "Refusée",

            planifiee: "Planifiée",
            terminee: "Terminée",
            annulee: "Annulée",

            active: "Actif",
            inactif: "Inactif"
        };

        return libelles[statut] || statut;
    }


    // ==========================================
    // 3. AFFICHAGE DES LEGENDES
    // ==========================================

    function afficherLegende(id, donnees) {

        const conteneur = document.getElementById(id);

        if (!conteneur) return;

        conteneur.innerHTML = "";

        const entrees = Object.entries(donnees || {});

        if (entrees.length === 0) {

            conteneur.textContent = "Aucune donnée disponible";
            return;
        }

        entrees.forEach(([statut, valeur], index) => {

            const ligne = document.createElement("div");
            ligne.className = "element-legende";

            const couleur = document.createElement("span");
            couleur.className = "couleur-legende";

            couleur.style.backgroundColor =
                couleurs[index % couleurs.length];

            const texte = document.createElement("span");

            texte.textContent =
                libelleStatut(statut) + " : " +
                Number(valeur).toLocaleString("fr-FR");

            ligne.appendChild(couleur);
            ligne.appendChild(texte);

            conteneur.appendChild(ligne);
        });
    }


    // ==========================================
    // 4. GRAPHIQUE DES PRESENCES ET INCIDENTS
    // ==========================================

    function dessinerDiagramme(id, donnees) {

        const canvas = document.getElementById(id);

        if (!canvas || typeof canvas.getContext !== "function") {
            console.error("Canvas introuvable ou invalide :", id);
            return;
        }

        const contexte = canvas.getContext("2d");

        if (!contexte) return;

        const largeur = canvas.clientWidth || 300;
        const hauteur = canvas.clientHeight || 250;
        const ratio = window.devicePixelRatio || 1;

        canvas.width = largeur * ratio;
        canvas.height = hauteur * ratio;

        contexte.setTransform(ratio, 0, 0, ratio, 0, 0);

        contexte.clearRect(0, 0, largeur, hauteur);

        const entrees = Object.entries(donnees || {});
        const total = totalObjet(donnees);

        const centreX = largeur / 2;
        const centreY = hauteur / 2;

        const rayon = Math.min(largeur, hauteur) * 0.36;
        const epaisseur = Math.max(18, rayon * 0.35);


        // Aucune donnée
        if (total === 0) {

            contexte.beginPath();

            contexte.arc(
                centreX,
                centreY,
                rayon,
                0,
                Math.PI * 2
            );

            contexte.strokeStyle = "#e5e7eb";
            contexte.lineWidth = epaisseur;
            contexte.stroke();

            contexte.fillStyle = "#64748b";
            contexte.font = "13px Arial";
            contexte.textAlign = "center";

            contexte.fillText(
                "Aucune donnée",
                centreX,
                centreY + 5
            );

            return;
        }


        // Dessin du diagramme circulaire
        let angleDepart = -Math.PI / 2;

        entrees.forEach(([statut, valeur], index) => {

            const angle =
                (Number(valeur) / total) * Math.PI * 2;

            contexte.beginPath();

            contexte.arc(
                centreX,
                centreY,
                rayon,
                angleDepart,
                angleDepart + angle
            );

            contexte.strokeStyle =
                couleurs[index % couleurs.length];

            contexte.lineWidth = epaisseur;
            contexte.stroke();

            angleDepart += angle;
        });


        // Total au centre
        contexte.fillStyle = "#1e293b";
        contexte.font = "bold 23px Arial";
        contexte.textAlign = "center";
        contexte.textBaseline = "middle";

        contexte.fillText(
            total.toLocaleString("fr-FR"),
            centreX,
            centreY
        );

        contexte.fillStyle = "#64748b";
        contexte.font = "11px Arial";

        contexte.fillText(
            "Total",
            centreX,
            centreY + 21
        );
    }


    // ==========================================
    // 5. GRAPHIQUE DES DEMANDES
    // IMPORTANT : graphiqueDemandes est un DIV
    // ==========================================

    function dessinerBarresDemandes(donnees) {

        const conteneur =
            document.getElementById("graphiqueDemandes");

        if (!conteneur) return;

        // On vide le graphique précédent
        conteneur.innerHTML = "";

        const entrees = Object.entries(donnees || {});

        const maximum = Math.max(
            ...entrees.map(([statut, valeur]) => Number(valeur)),
            1
        );

        conteneur.style.display = "flex";
        conteneur.style.flexDirection = "column";
        conteneur.style.gap = "20px";
        conteneur.style.padding = "20px 10px";


        // Aucune demande
        if (entrees.length === 0) {

            const message = document.createElement("p");

            message.textContent =
                "Aucune demande disponible pour cette période.";

            message.style.textAlign = "center";
            message.style.color = "#64748b";

            conteneur.appendChild(message);

            return;
        }


        // Création des barres
        entrees.forEach(([statut, valeur], index) => {

            const ligne = document.createElement("div");

            ligne.style.display = "grid";
            ligne.style.gridTemplateColumns = "110px 1fr 35px";
            ligne.style.alignItems = "center";
            ligne.style.gap = "12px";


            // Libellé
            const libelle = document.createElement("span");

            libelle.textContent = libelleStatut(statut);
            libelle.style.fontSize = "13px";
            libelle.style.color = "#334155";


            // Fond de la barre
            const fond = document.createElement("div");

            fond.style.height = "18px";
            fond.style.background = "#e2e8f0";
            fond.style.borderRadius = "20px";
            fond.style.overflow = "hidden";


            // Barre colorée
            const barre = document.createElement("div");

            barre.style.height = "100%";

            barre.style.width =
                (Number(valeur) / maximum * 100) + "%";

            barre.style.backgroundColor =
                couleurs[index % couleurs.length];

            barre.style.borderRadius = "20px";
            barre.style.transition = "width 0.4s ease";

            fond.appendChild(barre);


            // Nombre
            const nombre = document.createElement("strong");

            nombre.textContent =
                Number(valeur).toLocaleString("fr-FR");

            nombre.style.fontSize = "13px";
            nombre.style.color = "#1e293b";


            // Assemblage
            ligne.appendChild(libelle);
            ligne.appendChild(fond);
            ligne.appendChild(nombre);

            conteneur.appendChild(ligne);
        });
    }


    // ==========================================
    // 6. DETAILS DES STATUTS
    // ==========================================

    function detailsStatuts(donnees) {

        const entrees = Object.entries(donnees || {});

        if (entrees.length === 0) {
            return "Aucune donnée";
        }

        return entrees.map(([statut, valeur]) => {

            return libelleStatut(statut) + " : " + valeur;

        }).join(" | ");
    }


    // ==========================================
    // 7. TABLEAU RECAPITULATIF
    // ==========================================

    function afficherTableau(donnees) {

        const tableau = document.getElementById("tableauRapport");

        if (!tableau) return;

        tableau.innerHTML = "";

        const lignes = [

            {
                module: "Agents actifs",
                total: donnees.agents,
                details: "Effectif actuel"
            },

            {
                module: "Présences",
                total: donnees.presences,
                details: detailsStatuts(donnees.details.presences)
            },

            {
                module: "Incidents",
                total: donnees.incidents,
                details: detailsStatuts(donnees.details.incidents)
            },

            {
                module: "Demandes",
                total: donnees.demandes,
                details: detailsStatuts(donnees.details.demandes)
            },

            {
                module: "Affectations",
                total: donnees.totaux.affectations,
                details: detailsStatuts(donnees.details.affectations)
            }

        ];


        lignes.forEach((ligne) => {

            const tr = document.createElement("tr");

            const valeurs = [
                ligne.module,
                Number(ligne.total || 0).toLocaleString("fr-FR"),
                ligne.details
            ];

            valeurs.forEach((valeur) => {

                const td = document.createElement("td");

                td.textContent = valeur;

                tr.appendChild(td);
            });

            tableau.appendChild(tr);
        });
    }


    // ==========================================
    // 8. AFFICHAGE GENERAL DU RAPPORT
    // ==========================================

    function afficherRapport(donnees) {

        donneesRapport = donnees;

        // Indicateurs
        afficherNombre("statAgents", donnees.agents);
        afficherNombre("statPresences", donnees.presences);
        afficherNombre("statIncidents", donnees.incidents);
        afficherNombre("statDemandes", donnees.demandes);


        // Graphiques
        dessinerDiagramme(
            "graphiquePresences",
            donnees.details.presences
        );

        dessinerDiagramme(
            "graphiqueIncidents",
            donnees.details.incidents
        );

        dessinerBarresDemandes(
            donnees.details.demandes
        );


        // Légendes
        afficherLegende(
            "legendePresences",
            donnees.details.presences
        );

        afficherLegende(
            "legendeIncidents",
            donnees.details.incidents
        );


        // Tableau
        afficherTableau(donnees);


        // Date de génération
        const dateGeneration =
            document.getElementById("dateGeneration");

        if (dateGeneration) {

            dateGeneration.textContent =
                new Date().toLocaleString("fr-FR");
        }
    }


    // ==========================================
    // 9. CHARGEMENT DES DONNEES MYSQL
    // ==========================================

    async function chargerRapports() {

        const parametres = new URLSearchParams();

        if (dateDebut && dateDebut.value) {

            parametres.append(
                "dateDebut",
                dateDebut.value
            );
        }

        if (dateFin && dateFin.value) {

            parametres.append(
                "dateFin",
                dateFin.value
            );
        }


        const url =
            "../../controleurs/rapports.php?" +
            parametres.toString();


        try {

            if (btnFiltrer) {
                btnFiltrer.disabled = true;
            }

            const reponse = await fetch(url, {
                method: "GET",
                headers: {
                    "Accept": "application/json"
                }
            });

            const resultat = await reponse.json();

            if (!reponse.ok || !resultat.succes) {

                throw new Error(
                    resultat.message ||
                    "Erreur lors du chargement des rapports."
                );
            }

            afficherRapport(resultat.donnees);

        } catch (erreur) {

            console.error("Erreur rapports :", erreur);

            alert(
                erreur.message ||
                "Impossible de charger les rapports."
            );

        } finally {

            if (btnFiltrer) {
                btnFiltrer.disabled = false;
            }
        }
    }


    // ==========================================
    // 10. BOUTON APPLIQUER
    // ==========================================

    if (btnFiltrer) {

        btnFiltrer.addEventListener("click", function () {

            if (
                dateDebut &&
                dateFin &&
                dateDebut.value &&
                dateFin.value &&
                dateDebut.value > dateFin.value
            ) {

                alert(
                    "La date de début doit être antérieure à la date de fin."
                );

                return;
            }

            chargerRapports();
        });
    }


    // ==========================================
    // 11. BOUTON REINITIALISER
    // ==========================================

    if (btnReinitialiser) {

        btnReinitialiser.addEventListener("click", function () {

            if (dateDebut) {
                dateDebut.value = "";
            }

            if (dateFin) {
                dateFin.value = "";
            }

            chargerRapports();
        });
    }


    // ==========================================
    // 12. BOUTON IMPRIMER
    // ==========================================

    if (btnImprimer) {

        btnImprimer.addEventListener("click", function () {

            window.print();
        });
    }


    // ==========================================
    // 13. REDIMENSIONNEMENT DES GRAPHIQUES
    // ==========================================

    window.addEventListener("resize", function () {

        if (donneesRapport) {

            afficherRapport(donneesRapport);
        }
    });


    // ==========================================
    // 14. CHARGEMENT AUTOMATIQUE
    // ==========================================

    chargerRapports();

});

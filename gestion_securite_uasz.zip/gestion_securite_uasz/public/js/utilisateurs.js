
/* ==========================================
   GESTION SECURITE UASZ
   JAVASCRIPT UTILISATEURS
========================================== */

// Recherche dans la liste des utilisateurs

const recherche = document.getElementById("rechercheUtilisateur");

const lignes = document.querySelectorAll("#listeUtilisateurs tr");

if (recherche) {

    recherche.addEventListener("input", function () {

        const texte = recherche.value.toLowerCase().trim();

        lignes.forEach(function (ligne) {

            const contenu = ligne.textContent.toLowerCase();

            ligne.style.display = contenu.includes(texte) ? "" : "none";

        });

    });

}

// Confirmation avant activation ou désactivation

const formulairesStatut = document.querySelectorAll(".form-statut");

formulairesStatut.forEach(function (formulaire) {

    formulaire.addEventListener("submit", function (event) {

        const statut = formulaire.querySelector(
            'input[name="statut"]'
        ).value;

        const confirmation = statut === "inactif"
            ? "Voulez-vous vraiment désactiver ce compte ?"
            : "Voulez-vous vraiment réactiver ce compte ?";

        if (!confirm(confirmation)) {
            event.preventDefault();
        }

    });

});

// Confirmation avant la création ou la modification

const formulaireUtilisateur = document.getElementById("formulaireUtilisateur");

if (formulaireUtilisateur) {

    formulaireUtilisateur.addEventListener("submit", function (event) {

        const motDePasse = document.getElementById("mot_de_passe");

        if (motDePasse && motDePasse.value !== "" && motDePasse.value.length < 8) {

            event.preventDefault();

            alert("Le mot de passe doit contenir au moins 8 caractères.");

        }

    });

}
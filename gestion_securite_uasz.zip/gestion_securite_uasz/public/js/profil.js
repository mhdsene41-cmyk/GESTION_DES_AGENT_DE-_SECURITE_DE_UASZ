
document.addEventListener("DOMContentLoaded", () => {

    const URL_PROFIL = "../../controleurs/profil.php";

    const formulaireProfil = document.getElementById("formProfil");
    const formulaireMotDePasse = document.getElementById("formMotDePasse");

    let jetonCSRF = "";

    // AFFICHAGE DES MESSAGES
    function afficherMessage(id, message, succes = true) {
        const element = document.getElementById(id);

        if (!element) return;

        element.textContent = message;
        element.className = succes ? "message succes" : "message erreur";
    }

    // COMMUNICATION AVEC LE CONTROLEUR
    async function envoyerRequete(options = {}) {

        const reponse = await fetch(URL_PROFIL, {
            ...options,
            headers: {
                "Accept": "application/json",
                ...(options.headers || {})
            }
        });

        let resultat;

        try {
            resultat = await reponse.json();
        } catch {
            throw new Error("Réponse invalide du serveur.");
        }

        if (!reponse.ok || !resultat.succes) {
            throw new Error(resultat.message || "Une erreur est survenue.");
        }

        return resultat;
    }

    // OUTILS D'AFFICHAGE
    function definirValeur(id, valeur) {
        const champ = document.getElementById(id);

        if (champ) {
            champ.value = valeur ?? "";
        }
    }

    function afficherTexte(id, valeur) {
        const element = document.getElementById(id);

        if (element) {
            element.textContent = valeur ?? "";
        }
    }

    function initiales(nom, prenom) {
        const premiere = (prenom || "").trim().charAt(0);
        const seconde = (nom || "").trim().charAt(0);

        return (premiere + seconde).toUpperCase() || "U";
    }

    function traduireRole(role) {
        const roles = {
            administrateur: "Administrateur",
            utilisateur: "Utilisateur",
            agent: "Agent"
        };

        return roles[role] || role || "";
    }

    function traduireStatut(statut) {
        const statuts = {
            actif: "Actif",
            inactif: "Inactif"
        };

        return statuts[statut] || statut || "";
    }

    // CHARGEMENT DU PROFIL
    async function chargerProfil() {

        try {
            const resultat = await envoyerRequete();

            const utilisateur = resultat.donnees.utilisateur;

            jetonCSRF = resultat.donnees.csrf_token;

            definirValeur("csrfProfil", jetonCSRF);

            const nom = utilisateur.nom || "";
            const prenom = utilisateur.prenom || "";
            const nomComplet = `${prenom} ${nom}`.trim();

            definirValeur("nom", nom);
            definirValeur("prenom", prenom);
            definirValeur("identifiant", utilisateur.identifiant);
            definirValeur("email", utilisateur.email);
            definirValeur("telephone", utilisateur.telephone);
            definirValeur("role", traduireRole(utilisateur.role));
            definirValeur("statut", traduireStatut(utilisateur.statut));

            afficherTexte("nomAffiche", nomComplet);
            afficherTexte("roleAffiche", traduireRole(utilisateur.role));
            afficherTexte("nomUtilisateur", nomComplet);

            const lettres = initiales(nom, prenom);

            afficherTexte("avatarUtilisateur", lettres);
            afficherTexte("grandAvatar", lettres);

        } catch (erreur) {
            afficherMessage("messageProfil", erreur.message, false);
        }
    }

    // MODIFICATION DES INFORMATIONS PERSONNELLES
    if (formulaireProfil) {

        formulaireProfil.addEventListener("submit", async evenement => {

            evenement.preventDefault();

            const bouton = formulaireProfil.querySelector('button[type="submit"]');
            const texteInitial = bouton.textContent;

            bouton.disabled = true;
            bouton.textContent = "Enregistrement...";

            const donnees = {
                action: "modifier_profil",
                csrf_token: jetonCSRF,
                nom: document.getElementById("nom").value.trim(),
                prenom: document.getElementById("prenom").value.trim(),
                email: document.getElementById("email").value.trim(),
                telephone: document.getElementById("telephone").value.trim()
            };

            try {

                const resultat = await envoyerRequete({
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(donnees)
                });

                afficherMessage("messageProfil", resultat.message, true);

                await chargerProfil();

            } catch (erreur) {

                afficherMessage("messageProfil", erreur.message, false);

            } finally {

                bouton.disabled = false;
                bouton.textContent = texteInitial;

            }
        });
    }

    // MODIFICATION DU MOT DE PASSE
    if (formulaireMotDePasse) {

        formulaireMotDePasse.addEventListener("submit", async evenement => {

            evenement.preventDefault();

            const bouton = formulaireMotDePasse.querySelector('button[type="submit"]');
            const texteInitial = bouton.textContent;

            const ancien = document.getElementById("ancienMotDePasse").value;
            const nouveau = document.getElementById("nouveauMotDePasse").value;
            const confirmation = document.getElementById("confirmationMotDePasse").value;

            if (nouveau.length < 8) {
                afficherMessage(
                    "messageMotDePasse",
                    "Le nouveau mot de passe doit contenir au moins 8 caractères.",
                    false
                );
                return;
            }

            if (nouveau !== confirmation) {
                afficherMessage(
                    "messageMotDePasse",
                    "Les deux nouveaux mots de passe ne correspondent pas.",
                    false
                );
                return;
            }

            bouton.disabled = true;
            bouton.textContent = "Modification...";

            const donnees = {
                action: "modifier_mot_de_passe",
                csrf_token: jetonCSRF,
                ancien_mot_de_passe: ancien,
                nouveau_mot_de_passe: nouveau,
                confirmation_mot_de_passe: confirmation
            };

            try {

                const resultat = await envoyerRequete({
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(donnees)
                });

                afficherMessage(
                    "messageMotDePasse",
                    resultat.message,
                    true
                );

                formulaireMotDePasse.reset();

            } catch (erreur) {

                afficherMessage(
                    "messageMotDePasse",
                    erreur.message,
                    false
                );

            } finally {

                bouton.disabled = false;
                bouton.textContent = texteInitial;

            }
        });
    }

    // INITIALISATION
    chargerProfil();

});


/* ==========================================
   GESTION SÉCURITÉ UASZ - DEMANDES
   Connexion réelle à MySQL
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const tableDemandes = document.getElementById("tableDemandes");
    const modalDemande = document.getElementById("modalDemande");
    const formDemande = document.getElementById("formDemande");

    const btnAjouter = document.getElementById("btnAjouter");
    const btnFermer = document.getElementById("btnFermer");
    const btnAnnuler = document.getElementById("btnAnnuler");
    const btnEnregistrer = document.getElementById("btnEnregistrer");

    const titreModal = document.getElementById("titreModal");

    const rechercheDemande = document.getElementById("rechercheDemande");
    const filtreStatut = document.getElementById("filtreStatut");
    const filtreType = document.getElementById("filtreType");

    const messageVide = document.getElementById("messageVide");

    let demandes = [];

    /* ======================================
       COMMUNICATION AVEC LE SERVEUR PHP
    ====================================== */

    async function envoyerRequete(action, donnees = {}) {

        const parametres = new URLSearchParams();

        parametres.append("action", action);
        parametres.append("csrf_token", window.CSRF_DEMANDES);

        Object.keys(donnees).forEach(function (cle) {
            parametres.append(cle, donnees[cle]);
        });

        const reponse = await fetch(window.location.href, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: parametres
        });

        const resultat = await reponse.json();

        if (!reponse.ok || !resultat.succes) {
            throw new Error(resultat.message || "Une erreur est survenue.");
        }

        return resultat;
    }

    /* ======================================
       SÉCURISER LES TEXTES
    ====================================== */

    function securiserTexte(texte) {

        return String(texte ?? "").replace(/[&<>"']/g, function (caractere) {

            const caracteres = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            };

            return caracteres[caractere];
        });
    }

    /* ======================================
       CHARGER LES DEMANDES DEPUIS MYSQL
    ====================================== */

    async function chargerDemandes() {

        tableDemandes.innerHTML = `
            <tr>
                <td colspan="7" style="text-align:center;">
                    Chargement des demandes...
                </td>
            </tr>
        `;

        try {

            const resultat = await envoyerRequete("lister");

            demandes = resultat.donnees.map(function (demande) {

                return {
                    id: Number(demande.id),
                    reference: demande.reference,
                    demandeur: demande.demandeur,
                    type: demande.type,
                    date: demande.date_demande,
                    priorite: demande.priorite,
                    statut: demande.statut,
                    description: demande.description
                };

            });

            afficherDemandes();

        } catch (erreur) {

            tableDemandes.innerHTML = "";

            messageVide.style.display = "block";
            messageVide.textContent = erreur.message;

            console.error(erreur);
        }
    }

    /* ======================================
       CALCULER LES STATISTIQUES
    ====================================== */

    function calculerStatistiques() {

        const total = demandes.length;

        const enAttente = demandes.filter(function (demande) {
            return demande.statut === "En attente";
        }).length;

        const acceptees = demandes.filter(function (demande) {
            return demande.statut === "Acceptée";
        }).length;

        const refusees = demandes.filter(function (demande) {
            return demande.statut === "Refusée";
        }).length;

        document.getElementById("totalDemandes").textContent = total;
        document.getElementById("enAttente").textContent = enAttente;
        document.getElementById("acceptees").textContent = acceptees;
        document.getElementById("refusees").textContent = refusees;
    }

    /* ======================================
       AFFICHER LES DEMANDES
    ====================================== */

    function afficherDemandes() {

        tableDemandes.innerHTML = "";

        const recherche = rechercheDemande.value.toLowerCase().trim();
        const statutChoisi = filtreStatut.value;
        const typeChoisi = filtreType.value;

        const demandesFiltrees = demandes.filter(function (demande) {

            const correspondRecherche =
                demande.reference.toLowerCase().includes(recherche) ||
                demande.demandeur.toLowerCase().includes(recherche) ||
                demande.type.toLowerCase().includes(recherche) ||
                demande.description.toLowerCase().includes(recherche);

            const correspondStatut =
                statutChoisi === "" || demande.statut === statutChoisi;

            const correspondType =
                typeChoisi === "" || demande.type === typeChoisi;

            return correspondRecherche &&
                correspondStatut &&
                correspondType;
        });

        messageVide.style.display =
            demandesFiltrees.length === 0 ? "block" : "none";

        if (demandesFiltrees.length === 0) {
            messageVide.textContent = demandes.length === 0
                ? "Aucune demande enregistrée pour le moment."
                : "Aucune demande ne correspond à votre recherche.";
        }

        demandesFiltrees.forEach(function (demande) {

            let classeStatut = "statut-attente";

            if (demande.statut === "Acceptée") {
                classeStatut = "statut-acceptee";
            } else if (demande.statut === "Refusée") {
                classeStatut = "statut-refusee";
            }

            let classePriorite = "priorite-normale";

            if (demande.priorite === "Importante") {
                classePriorite = "priorite-importante";
            } else if (demande.priorite === "Urgente") {
                classePriorite = "priorite-urgente";
            }

            let actionsSupplementaires = "";

            if (demande.statut === "En attente") {

                actionsSupplementaires = `
                    <button
                        class="btn-action btn-accepter"
                        data-action="accepter"
                        data-id="${demande.id}">
                        Accepter
                    </button>

                    <button
                        class="btn-action btn-refuser"
                        data-action="refuser"
                        data-id="${demande.id}">
                        Refuser
                    </button>
                `;
            }

            const ligne = document.createElement("tr");

            ligne.innerHTML = `

                <td>
                    <strong>${securiserTexte(demande.reference)}</strong>
                </td>

                <td>${securiserTexte(demande.demandeur)}</td>

                <td>${securiserTexte(demande.type)}</td>

                <td>${securiserTexte(demande.date)}</td>

                <td>
                    <span class="badge ${classePriorite}">
                        ${securiserTexte(demande.priorite)}
                    </span>
                </td>

                <td>
                    <span class="badge ${classeStatut}">
                        ${securiserTexte(demande.statut)}
                    </span>
                </td>

                <td>
                    <div class="actions">

                        ${actionsSupplementaires}

                        <button
                            class="btn-action btn-modifier"
                            data-action="modifier"
                            data-id="${demande.id}">
                            Modifier
                        </button>

                        <button
                            class="btn-action btn-supprimer"
                            data-action="supprimer"
                            data-id="${demande.id}">
                            Supprimer
                        </button>

                    </div>
                </td>

            `;

            tableDemandes.appendChild(ligne);
        });

        calculerStatistiques();
    }

    /* ======================================
       DATE ACTUELLE
    ====================================== */

    function obtenirDateActuelle() {

        const aujourdHui = new Date();

        const annee = aujourdHui.getFullYear();
        const mois = String(aujourdHui.getMonth() + 1).padStart(2, "0");
        const jour = String(aujourdHui.getDate()).padStart(2, "0");

        return `${annee}-${mois}-${jour}`;
    }

    /* ======================================
       OUVRIR ET FERMER LA FENÊTRE
    ====================================== */

    function ouvrirModal() {
        modalDemande.classList.add("show");
    }

    function fermerModal() {

        modalDemande.classList.remove("show");

        formDemande.reset();

        document.getElementById("demandeId").value = "";

        titreModal.textContent = "Nouvelle demande";

        btnEnregistrer.disabled = false;
        btnEnregistrer.textContent = "Enregistrer";
    }

    btnAjouter.addEventListener("click", function () {

        formDemande.reset();

        document.getElementById("demandeId").value = "";
        document.getElementById("dateDemande").value = obtenirDateActuelle();
        document.getElementById("statutDemande").value = "En attente";

        titreModal.textContent = "Nouvelle demande";

        ouvrirModal();
    });

    btnFermer.addEventListener("click", fermerModal);
    btnAnnuler.addEventListener("click", fermerModal);

    modalDemande.addEventListener("click", function (event) {

        if (event.target === modalDemande) {
            fermerModal();
        }
    });

    /* ======================================
       ENREGISTRER OU MODIFIER
    ====================================== */

    formDemande.addEventListener("submit", async function (event) {

        event.preventDefault();

        const id = document.getElementById("demandeId").value;

        const donnees = {
            demandeur: document.getElementById("nomDemandeur").value.trim(),
            type: document.getElementById("typeDemande").value,
            date: document.getElementById("dateDemande").value,
            priorite: document.getElementById("prioriteDemande").value,
            statut: document.getElementById("statutDemande").value,
            description: document.getElementById("descriptionDemande").value.trim()
        };

        if (
            !donnees.demandeur ||
            !donnees.type ||
            !donnees.date ||
            !donnees.priorite ||
            !donnees.statut ||
            !donnees.description
        ) {
            alert("Veuillez remplir tous les champs obligatoires.");
            return;
        }

        btnEnregistrer.disabled = true;
        btnEnregistrer.textContent = "Enregistrement...";

        try {

            if (id !== "") {

                donnees.id = id;

                const resultat = await envoyerRequete("modifier", donnees);

                alert(resultat.message);

            } else {

                const resultat = await envoyerRequete("ajouter", donnees);

                alert(resultat.message);
            }

            fermerModal();

            await chargerDemandes();

        } catch (erreur) {

            alert(erreur.message);

            btnEnregistrer.disabled = false;
            btnEnregistrer.textContent = "Enregistrer";
        }
    });

    /* ======================================
       ACTIONS DU TABLEAU
    ====================================== */

    tableDemandes.addEventListener("click", async function (event) {

        const bouton = event.target.closest("button[data-action]");

        if (!bouton) {
            return;
        }

        const id = Number(bouton.dataset.id);
        const action = bouton.dataset.action;

        const demande = demandes.find(function (element) {
            return element.id === id;
        });

        if (!demande) {
            return;
        }

        /* MODIFIER */

        if (action === "modifier") {

            document.getElementById("demandeId").value = demande.id;
            document.getElementById("nomDemandeur").value = demande.demandeur;
            document.getElementById("typeDemande").value = demande.type;
            document.getElementById("dateDemande").value = demande.date;
            document.getElementById("prioriteDemande").value = demande.priorite;
            document.getElementById("statutDemande").value = demande.statut;
            document.getElementById("descriptionDemande").value = demande.description;

            titreModal.textContent = "Modifier une demande";

            ouvrirModal();

            return;
        }

        /* SUPPRIMER */

        if (action === "supprimer") {

            const confirmation = confirm(
                "Voulez-vous vraiment supprimer la demande " +
                demande.reference + " ?"
            );

            if (!confirmation) {
                return;
            }

            try {

                const resultat = await envoyerRequete("supprimer", {
                    id: id
                });

                alert(resultat.message);

                await chargerDemandes();

            } catch (erreur) {
                alert(erreur.message);
            }

            return;
        }

        /* ACCEPTER OU REFUSER */

        if (action === "accepter" || action === "refuser") {

            const nouveauStatut =
                action === "accepter" ? "Acceptée" : "Refusée";

            const confirmation = confirm(
                "Voulez-vous vraiment " +
                (action === "accepter" ? "accepter" : "refuser") +
                " cette demande ?"
            );

            if (!confirmation) {
                return;
            }

            try {

                const resultat = await envoyerRequete("changer_statut", {
                    id: id,
                    statut: nouveauStatut
                });

                alert(resultat.message);

                await chargerDemandes();

            } catch (erreur) {
                alert(erreur.message);
            }
        }
    });

    /* ======================================
       RECHERCHE ET FILTRES
    ====================================== */

    rechercheDemande.addEventListener("input", afficherDemandes);
    filtreStatut.addEventListener("change", afficherDemandes);
    filtreType.addEventListener("change", afficherDemandes);

    /* ======================================
       DÉCONNEXION
    ====================================== */

    const boutonDeconnexion = document.getElementById("deconnexion");

    boutonDeconnexion.addEventListener("click", function (event) {

        const confirmation = confirm(
            "Voulez-vous vraiment vous déconnecter ?"
        );

        if (!confirmation) {
            event.preventDefault();
        }
    });

    /* ======================================
       AFFICHAGE INITIAL
    ====================================== */

    chargerDemandes();

});

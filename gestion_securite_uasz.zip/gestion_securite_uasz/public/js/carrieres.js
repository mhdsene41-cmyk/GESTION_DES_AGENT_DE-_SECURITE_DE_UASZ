
/* =====================================================
   GESTION DES CARRIERES - UASZ
   Connexion à MySQL avec PHP
===================================================== */

document.addEventListener("DOMContentLoaded", function () {

    const tableauCarrieres = document.getElementById("tableauCarrieres");
    const modalCarriere = document.getElementById("modalCarriere");
    const formCarriere = document.getElementById("formCarriere");

    const btnAjouterCarriere = document.getElementById("btnAjouterCarriere");
    const btnEnregistrer = document.getElementById("btnEnregistrerCarriere");

    const fermerModal = document.getElementById("fermerModal");
    const annulerCarriere = document.getElementById("annulerCarriere");

    const agentCarriere = document.getElementById("agentCarriere");
    const rechercheCarriere = document.getElementById("rechercheCarriere");
    const filtreType = document.getElementById("filtreType");
    const filtreStatut = document.getElementById("filtreStatut");

    let carrieres = [];
    let agents = [];

    /* =================================================
       COMMUNICATION AVEC PHP
    ================================================= */

    async function envoyerRequete(action, donnees = {}) {

        const formulaire = new URLSearchParams();

        formulaire.append("action", action);
        formulaire.append("csrf_token", window.CSRF_CARRIERES);

        Object.entries(donnees).forEach(([cle, valeur]) => {
            formulaire.append(cle, valeur ?? "");
        });

        const reponse = await fetch(window.location.href, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
            },
            body: formulaire.toString()
        });

        const resultat = await reponse.json();

        if (!reponse.ok || !resultat.succes) {
            throw new Error(resultat.message || "Une erreur est survenue.");
        }

        return resultat.donnees;
    }

    /* =================================================
       SECURISER LES TEXTES
    ================================================= */

    function echapperHTML(valeur) {

        return String(valeur ?? "").replace(/[&<>"']/g, caractere => {

            const caracteres = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            };

            return caracteres[caractere];
        });
    }

    /* =================================================
       CHARGER LES AGENTS DEPUIS MYSQL
    ================================================= */

    async function chargerAgents() {

        try {

            agents = await envoyerRequete("charger_agents");

            agentCarriere.innerHTML =
                '<option value="">Sélectionner un agent</option>';

            if (agents.length === 0) {

                agentCarriere.innerHTML =
                    '<option value="">Aucun agent enregistré</option>';

                return;
            }

            agents.forEach(agent => {

                const option = document.createElement("option");

                option.value = agent.id;

                let nomComplet =
                    `${agent.prenom} ${agent.nom} (${agent.matricule})`;

                if (agent.poste) {
                    nomComplet += ` - ${agent.poste}`;
                }

                if (agent.statut === "inactif") {
                    nomComplet += " - Inactif";
                }

                option.textContent = nomComplet;

                agentCarriere.appendChild(option);
            });

        } catch (erreur) {

            console.error(erreur);

            agentCarriere.innerHTML =
                '<option value="">Erreur de chargement des agents</option>';

            alert(erreur.message);
        }
    }

    /* =================================================
       CHARGER LES CARRIERES DEPUIS MYSQL
    ================================================= */

    async function chargerCarrieres() {

        tableauCarrieres.innerHTML = `
            <tr>
                <td colspan="8" style="text-align:center;padding:25px;">
                    Chargement des évolutions...
                </td>
            </tr>
        `;

        try {

            carrieres = await envoyerRequete("lister");

            afficherCarrieres();

        } catch (erreur) {

            console.error(erreur);

            tableauCarrieres.innerHTML = `
                <tr>
                    <td colspan="8" style="text-align:center;padding:25px;">
                        Impossible de charger les évolutions.
                    </td>
                </tr>
            `;

            alert(erreur.message);
        }
    }

    /* =================================================
       CLASSE DES STATUTS
    ================================================= */

    function classeStatut(statut) {

        if (statut === "Validée") {
            return "statut-validee";
        }

        if (statut === "Refusée") {
            return "statut-refusee";
        }

        return "statut-attente";
    }

    /* =================================================
       FORMATAGE DES DATES
    ================================================= */

    function formaterDate(date) {

        if (!date) return "";

        const morceaux = date.split("-");

        if (morceaux.length !== 3) return date;

        return `${morceaux[2]}/${morceaux[1]}/${morceaux[0]}`;
    }

    /* =================================================
       STATISTIQUES
    ================================================= */

    function afficherStatistiques() {

        document.getElementById("totalCarrieres").textContent =
            carrieres.length;

        document.getElementById("totalPromotions").textContent =
            carrieres.filter(c =>
                c.type_evolution === "Promotion"
            ).length;

        document.getElementById("totalFonctions").textContent =
            carrieres.filter(c =>
                c.type_evolution === "Changement de fonction"
            ).length;

        document.getElementById("totalEnAttente").textContent =
            carrieres.filter(c =>
                c.statut === "En attente"
            ).length;
    }

    /* =================================================
       AFFICHER LES CARRIERES
    ================================================= */

    function afficherCarrieres() {

        const recherche = rechercheCarriere.value
            .trim()
            .toLowerCase();

        const type = filtreType.value;
        const statut = filtreStatut.value;

        const resultats = carrieres.filter(carriere => {

            const nomAgent =
                `${carriere.prenom} ${carriere.nom}`.toLowerCase();

            const correspondRecherche =
                nomAgent.includes(recherche) ||
                String(carriere.reference).toLowerCase().includes(recherche) ||
                String(carriere.matricule).toLowerCase().includes(recherche);

            const correspondType =
                type === "" || carriere.type_evolution === type;

            const correspondStatut =
                statut === "" || carriere.statut === statut;

            return correspondRecherche &&
                correspondType &&
                correspondStatut;
        });

        tableauCarrieres.innerHTML = "";

        if (resultats.length === 0) {

            tableauCarrieres.innerHTML = `
                <tr>
                    <td colspan="8" style="text-align:center;padding:25px;">
                        Aucune évolution professionnelle trouvée.
                    </td>
                </tr>
            `;

        } else {

            resultats.forEach(carriere => {

                const ligne = document.createElement("tr");

                ligne.innerHTML = `
                    <td>
                        <strong>${echapperHTML(carriere.reference)}</strong>
                    </td>

                    <td>
                        <strong>
                            ${echapperHTML(carriere.prenom)}
                            ${echapperHTML(carriere.nom)}
                        </strong>
                        <br>
                        <small>${echapperHTML(carriere.matricule)}</small>
                    </td>

                    <td>${echapperHTML(carriere.type_evolution)}</td>

                    <td>${echapperHTML(carriere.ancienne_fonction)}</td>

                    <td>${echapperHTML(carriere.nouvelle_fonction)}</td>

                    <td>${formaterDate(carriere.date_evolution)}</td>

                    <td>
                        <span class="statut ${classeStatut(carriere.statut)}">
                            ${echapperHTML(carriere.statut)}
                        </span>
                    </td>

                    <td>
                        <button
                            type="button"
                            class="action-btn btn-edit"
                            data-action="modifier"
                            data-id="${Number(carriere.id)}">
                            Modifier
                        </button>

                        <button
                            type="button"
                            class="action-btn btn-delete"
                            data-action="supprimer"
                            data-id="${Number(carriere.id)}">
                            Supprimer
                        </button>
                    </td>
                `;

                tableauCarrieres.appendChild(ligne);
            });
        }

        afficherStatistiques();
    }

    /* =================================================
       OUVRIR ET FERMER LE MODAL
    ================================================= */

    function ouvrirModal() {
        modalCarriere.classList.add("active");
    }

    function fermerFenetre() {

        modalCarriere.classList.remove("active");

        formCarriere.reset();

        document.getElementById("idCarriere").value = "";

        document.getElementById("titreModal").textContent =
            "Nouvelle évolution";

        btnEnregistrer.disabled = false;
        btnEnregistrer.textContent = "Enregistrer";
    }

    function ajouterCarriere() {

        formCarriere.reset();

        document.getElementById("idCarriere").value = "";

        document.getElementById("titreModal").textContent =
            "Nouvelle évolution";

        ouvrirModal();
    }

    /* =================================================
       ENREGISTRER UNE EVOLUTION
    ================================================= */

    formCarriere.addEventListener("submit", async function (e) {

        e.preventDefault();

        const id = document.getElementById("idCarriere").value;

        const donnees = {
            id: id,
            agent_id: agentCarriere.value,

            type_evolution:
                document.getElementById("typeEvolution").value,

            ancienne_fonction:
                document.getElementById("ancienneFonction").value.trim(),

            nouvelle_fonction:
                document.getElementById("nouvelleFonction").value.trim(),

            date_evolution:
                document.getElementById("dateEvolution").value,

            statut:
                document.getElementById("statutCarriere").value,

            motif:
                document.getElementById("motifCarriere").value.trim()
        };

        if (!donnees.agent_id) {
            alert("Veuillez sélectionner un agent.");
            return;
        }

        if (
            !donnees.ancienne_fonction ||
            !donnees.nouvelle_fonction ||
            !donnees.date_evolution
        ) {
            alert("Veuillez remplir tous les champs obligatoires.");
            return;
        }

        const action = id ? "modifier" : "ajouter";

        btnEnregistrer.disabled = true;
        btnEnregistrer.textContent = "Enregistrement...";

        try {

            const resultat = await envoyerRequete(action, donnees);

            alert(resultat.message || "Opération effectuée avec succès.");

            fermerFenetre();

            await chargerCarrieres();

        } catch (erreur) {

            console.error(erreur);

            alert(erreur.message);

        } finally {

            btnEnregistrer.disabled = false;
            btnEnregistrer.textContent = "Enregistrer";
        }
    });

    /* =================================================
       MODIFIER UNE EVOLUTION
    ================================================= */

    function modifierCarriere(id) {

        const carriere = carrieres.find(c =>
            Number(c.id) === Number(id)
        );

        if (!carriere) {
            alert("Évolution introuvable.");
            return;
        }

        document.getElementById("idCarriere").value =
            carriere.id;

        document.getElementById("titreModal").textContent =
            "Modifier une évolution";

        agentCarriere.value = carriere.agent_id;

        document.getElementById("typeEvolution").value =
            carriere.type_evolution;

        document.getElementById("ancienneFonction").value =
            carriere.ancienne_fonction;

        document.getElementById("nouvelleFonction").value =
            carriere.nouvelle_fonction;

        document.getElementById("dateEvolution").value =
            carriere.date_evolution;

        document.getElementById("statutCarriere").value =
            carriere.statut;

        document.getElementById("motifCarriere").value =
            carriere.motif || "";

        ouvrirModal();
    }

    /* =================================================
       SUPPRIMER UNE EVOLUTION
    ================================================= */

    async function supprimerCarriere(id) {

        const confirmation = confirm(
            "Voulez-vous vraiment supprimer cette évolution professionnelle ?\n\nSon historique sera conservé."
        );

        if (!confirmation) return;

        try {

            const resultat = await envoyerRequete("supprimer", {
                id: id
            });

            alert(resultat.message);

            await chargerCarrieres();

        } catch (erreur) {

            console.error(erreur);

            alert(erreur.message);
        }
    }

    /* =================================================
       GESTION DES BOUTONS DU TABLEAU
    ================================================= */

    tableauCarrieres.addEventListener("click", function (e) {

        const bouton = e.target.closest("button[data-action]");

        if (!bouton) return;

        const id = Number(bouton.dataset.id);
        const action = bouton.dataset.action;

        if (action === "modifier") {
            modifierCarriere(id);
        }

        if (action === "supprimer") {
            supprimerCarriere(id);
        }
    });

    /* =================================================
       EVENEMENTS
    ================================================= */

    btnAjouterCarriere.addEventListener("click", ajouterCarriere);

    fermerModal.addEventListener("click", fermerFenetre);

    annulerCarriere.addEventListener("click", fermerFenetre);

    modalCarriere.addEventListener("click", function (e) {

        if (e.target === modalCarriere) {
            fermerFenetre();
        }
    });

    rechercheCarriere.addEventListener("input", afficherCarrieres);

    filtreType.addEventListener("change", afficherCarrieres);

    filtreStatut.addEventListener("change", afficherCarrieres);

    /* =================================================
       INITIALISATION
    ================================================= */

    async function initialiser() {

        await chargerAgents();

        await chargerCarrieres();
    }

    initialiser();

});


document.addEventListener("DOMContentLoaded", function () {
    const inputPhoto = document.getElementById("photoAgent");
    const apercu = document.getElementById("apercuPhoto");
    const textePhoto = document.getElementById("textePhoto");

    if (inputPhoto && apercu) {
        inputPhoto.addEventListener("change", function () {
            const fichier = this.files[0];

            if (!fichier) return;

            if (fichier.size > 3 * 1024 * 1024) {
                alert("La photo ne doit pas dépasser 3 Mo.");
                this.value = "";
                return;
            }

            const formatsAcceptes = [
                "image/jpeg",
                "image/png",
                "image/webp"
            ];

            if (!formatsAcceptes.includes(fichier.type)) {
                alert("Choisis une photo JPG, PNG ou WEBP.");
                this.value = "";
                return;
            }

            apercu.src = URL.createObjectURL(fichier);
            apercu.hidden = false;

            if (textePhoto) {
                textePhoto.hidden = true;
            }
        });
    }

    document.querySelectorAll(".form-desactivation").forEach(function (formulaire) {
        formulaire.addEventListener("submit", function (event) {
            const message = this.dataset.confirmation || "Confirmer cette opération ?";

            if (!confirm(message)) {
                event.preventDefault();
            }
        });
    });
});


document.addEventListener('DOMContentLoaded', () => {

    const config = window.NOTIFICATIONS_CONFIG;

    const liste = document.getElementById('listeNotifications');
    const recherche = document.getElementById('rechercheNotification');
    const filtreType = document.getElementById('filtreType');
    const filtreStatut = document.getElementById('filtreStatut');
    const boutonToutLire = document.getElementById('toutMarquerLu');

    const totalElement = document.getElementById('totalNotifications');
    const nonLuesElement = document.getElementById('notificationsNonLues');
    const luesElement = document.getElementById('notificationsLues');

    const messageVide = document.getElementById('messageVide');
    const messageFiltreVide = document.getElementById('messageFiltreVide');

    if (!config || !liste) {
        console.error('Configuration des notifications introuvable.');
        return;
    }

    // Envoi sécurisé des actions au serveur
    async function envoyerAction(donnees) {

        const formulaire = new FormData();

        Object.entries(donnees).forEach(([cle, valeur]) => {
            formulaire.append(cle, valeur);
        });

        const reponse = await fetch(config.endpoint, {
            method: 'POST',
            headers: {
                'X-CSRF-Token': config.csrf
            },
            body: formulaire
        });

        const resultat = await reponse.json();

        if (!reponse.ok || !resultat.success) {
            throw new Error(resultat.message || 'Une erreur est survenue.');
        }

        return resultat;
    }

    // Mise à jour des statistiques à partir de la liste affichée
    function actualiserStatistiques() {

        const cartes = [...liste.querySelectorAll('.notification-card')];

        const total = cartes.length;
        const nonLues = cartes.filter(carte =>
            carte.dataset.statut === '0'
        ).length;

        const lues = total - nonLues;

        totalElement.textContent = total;
        nonLuesElement.textContent = nonLues;
        luesElement.textContent = lues;

        boutonToutLire.disabled = nonLues === 0;

        messageVide.hidden = total !== 0;
    }

    // Recherche et filtres
    function filtrerNotifications() {

        const texte = recherche.value.trim().toLowerCase();
        const type = filtreType.value;
        const statut = filtreStatut.value;

        const cartes = liste.querySelectorAll('.notification-card');

        let resultats = 0;

        cartes.forEach(carte => {

            const contenu = carte.textContent.toLowerCase();

            const correspondRecherche = contenu.includes(texte);
            const correspondType = !type || carte.dataset.type === type;
            const correspondStatut = statut === '' ||
                carte.dataset.statut === statut;

            const visible =
                correspondRecherche &&
                correspondType &&
                correspondStatut;

            carte.hidden = !visible;

            if (visible) {
                resultats++;
            }
        });

        messageFiltreVide.hidden = resultats !== 0;
    }

    recherche.addEventListener('input', filtrerNotifications);
    filtreType.addEventListener('change', filtrerNotifications);
    filtreStatut.addEventListener('change', filtrerNotifications);

    // Marquer une notification comme lue
    liste.addEventListener('click', async (evenement) => {

        const bouton = evenement.target.closest('.btn-read');

        if (!bouton) return;

        const carte = bouton.closest('.notification-card');

        if (!carte) return;

        bouton.disabled = true;
        bouton.textContent = 'Traitement...';

        try {

            await envoyerAction({
                action: 'marquer_lue',
                id: carte.dataset.id
            });

            carte.dataset.statut = '1';
            carte.classList.remove('non-lue');
            carte.classList.add('lue');

            const badge = carte.querySelector('.badge-statut');

            if (badge) {
                badge.textContent = 'Lue';
            }

            bouton.remove();

            actualiserStatistiques();
            filtrerNotifications();

        } catch (erreur) {

            alert(erreur.message);
            bouton.disabled = false;
            bouton.textContent = 'Marquer comme lue';
        }
    });

    // Marquer toutes les notifications comme lues
    boutonToutLire.addEventListener('click', async () => {

        if (boutonToutLire.disabled) return;

        const confirmation = confirm(
            'Voulez-vous vraiment marquer toutes les notifications comme lues ?'
        );

        if (!confirmation) return;

        boutonToutLire.disabled = true;
        boutonToutLire.textContent = 'Traitement...';

        try {

            await envoyerAction({
                action: 'tout_marquer_lu'
            });

            liste.querySelectorAll('.notification-card').forEach(carte => {

                carte.dataset.statut = '1';
                carte.classList.remove('non-lue');
                carte.classList.add('lue');

                const badge = carte.querySelector('.badge-statut');
                const bouton = carte.querySelector('.btn-read');

                if (badge) {
                    badge.textContent = 'Lue';
                }

                if (bouton) {
                    bouton.remove();
                }
            });

            actualiserStatistiques();
            filtrerNotifications();

            boutonToutLire.textContent = '✓ Tout est lu';

        } catch (erreur) {

            alert(erreur.message);
            boutonToutLire.textContent = '✓ Tout marquer comme lu';
            boutonToutLire.disabled = false;
        }
    });

    actualiserStatistiques();
    filtrerNotifications();

});

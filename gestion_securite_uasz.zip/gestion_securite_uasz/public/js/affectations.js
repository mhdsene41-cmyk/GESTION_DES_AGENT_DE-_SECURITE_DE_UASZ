
document.addEventListener("DOMContentLoaded", function () {

    /* Prévisualisation de la photo du bâtiment */
    const champPhoto = document.getElementById("photo_batiment");
    const apercu = document.getElementById("apercu-photo");
    const texteApercu = document.getElementById("texte-apercu");

    if (champPhoto && apercu) {
        champPhoto.addEventListener("change", function () {
            const fichier = this.files[0];

            if (!fichier) {
                return;
            }

            const formatsAutorises = [
                "image/jpeg",
                "image/png",
                "image/webp"
            ];

            if (!formatsAutorises.includes(fichier.type)) {
                alert("Format non accepté. Choisissez une image JPG, PNG ou WEBP.");
                this.value = "";
                return;
            }

            if (fichier.size > 4 * 1024 * 1024) {
                alert("La photo ne doit pas dépasser 4 Mo.");
                this.value = "";
                return;
            }

            const lecteur = new FileReader();

            lecteur.onload = function (evenement) {
                apercu.src = evenement.target.result;
                apercu.classList.add("visible");

                if (texteApercu) {
                    texteApercu.hidden = true;
                }
            };

            lecteur.readAsDataURL(fichier);
        });
    }

    /* Vérification des horaires avant envoi */
    const formulaire = document.querySelector(".form-affectation");

    if (formulaire) {
        formulaire.addEventListener("submit", function (evenement) {
            const debut = document.getElementById("heure_debut");
            const fin = document.getElementById("heure_fin");

            if (
                debut &&
                fin &&
                debut.value &&
                fin.value &&
                debut.value >= fin.value
            ) {
                evenement.preventDefault();

                alert("L'heure de fin doit être après l'heure de début.");

                fin.focus();
                return;
            }
        });
    }

    /* Confirmation avant suppression */
    const formulairesSuppression = document.querySelectorAll(".form-suppression");

    formulairesSuppression.forEach(function (formulaireSuppression) {
        formulaireSuppression.addEventListener("submit", function (evenement) {
            const confirmation = confirm(
                "Voulez-vous vraiment supprimer cette affectation ?\n\n" +
                "Une copie sera conservée dans l'historique."
            );

            if (!confirmation) {
                evenement.preventDefault();
            }
        });
    });

});

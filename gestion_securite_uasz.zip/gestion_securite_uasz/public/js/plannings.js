
document.addEventListener("DOMContentLoaded", function () {
    const formulaire = document.querySelector(".form-planning");

    if (!formulaire) {
        return;
    }

    const heureDebut = document.getElementById("heure_debut");
    const heureFin = document.getElementById("heure_fin");

    formulaire.addEventListener("submit", function (evenement) {
        if (
            heureDebut.value &&
            heureFin.value &&
            heureDebut.value >= heureFin.value
        ) {
            evenement.preventDefault();

            alert("L'heure de fin doit être après l'heure de début.");

            heureFin.focus();
        }
    });
});


/* ==========================================
   GESTION DU MENU LATERAL
========================================== */

const barreLaterale = document.getElementById("barreLaterale");
const boutonMenu = document.getElementById("boutonMenu");
const fondMenu = document.getElementById("fondMenu");

function ouvrirMenu() {
    if (!barreLaterale || !fondMenu || !boutonMenu) return;

    barreLaterale.classList.add("ouverte");
    fondMenu.classList.add("visible");
    boutonMenu.setAttribute("aria-expanded", "true");
}

function fermerMenu() {
    if (!barreLaterale || !fondMenu || !boutonMenu) return;

    barreLaterale.classList.remove("ouverte");
    fondMenu.classList.remove("visible");
    boutonMenu.setAttribute("aria-expanded", "false");
}

if (boutonMenu) {
    boutonMenu.addEventListener("click", () => {
        const menuOuvert = barreLaterale.classList.contains("ouverte");

        if (menuOuvert) {
            fermerMenu();
        } else {
            ouvrirMenu();
        }
    });
}

if (fondMenu) {
    fondMenu.addEventListener("click", fermerMenu);
}

// Fermer le menu après avoir choisi une page
document.querySelectorAll(".barre-laterale a").forEach(lien => {
    lien.addEventListener("click", fermerMenu);
});

// Fermer le menu avec la touche Échap
document.addEventListener("keydown", evenement => {
    if (evenement.key === "Escape") {
        fermerMenu();
    }
});


/* ==========================================
   AFFICHAGE DE LA DATE
========================================== */

const dateActuelle = document.getElementById("dateActuelle");

if (dateActuelle) {
    const aujourdHui = new Date();

    const dateFormatee = aujourdHui.toLocaleDateString("fr-FR", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric"
    });

    dateActuelle.textContent =
        dateFormatee.charAt(0).toUpperCase() + dateFormatee.slice(1);
}


/* ==========================================
   AFFICHAGE DE L'ANNEE
========================================== */

const anneeActuelle = document.getElementById("anneeActuelle");

if (anneeActuelle) {
    anneeActuelle.textContent = new Date().getFullYear();
}

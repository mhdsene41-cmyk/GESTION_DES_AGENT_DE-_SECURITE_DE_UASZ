
/* =====================================================
   GESTION SÉCURITÉ UASZ — MODULE DES INCIDENTS
   Prévisualisation et validation des preuves
===================================================== */

document.addEventListener("DOMContentLoaded", function () {

    "use strict";

    // Récupération des éléments du formulaire
    const formulaire = document.querySelector(".form-incident");

    const champPhoto = document.getElementById("photo_incident");
    const champVideo = document.getElementById("video_incident");

    const apercuPhoto = document.getElementById("apercu_photo");
    const apercuVideo = document.getElementById("apercu_video");

    // Vérifier que les éléments existent
    if (!formulaire || !champPhoto || !champVideo ||
        !apercuPhoto || !apercuVideo) {
        console.warn(
            "Module incidents : certains éléments du formulaire sont introuvables."
        );
        return;
    }

    // Limites de taille
    const TAILLE_MAX_PHOTO = 5 * 1024 * 1024;
    const TAILLE_MAX_VIDEO = 30 * 1024 * 1024;

    // Extensions autorisées
    const EXTENSIONS_PHOTO = ["jpg", "jpeg", "png", "webp"];
    const EXTENSIONS_VIDEO = ["mp4", "webm"];

    // Types MIME autorisés
    const TYPES_PHOTO = [
        "image/jpeg",
        "image/png",
        "image/webp"
    ];

    const TYPES_VIDEO = [
        "video/mp4",
        "video/webm"
    ];

    // Conserver les URL temporaires pour les libérer ensuite
    let urlPhoto = null;
    let urlVideo = null;

    // Récupérer l'extension d'un fichier
    function obtenirExtension(fichier) {

        const nom = fichier.name.toLowerCase();
        const position = nom.lastIndexOf(".");

        if (position === -1) {
            return "";
        }

        return nom.substring(position + 1);
    }

    // Formater une taille en Mo
    function formaterTaille(taille) {
        return (taille / (1024 * 1024)).toFixed(2) + " Mo";
    }

    // Afficher une erreur sans supprimer les liens existants
    function afficherErreur(conteneur, message) {

        supprimerElementTemporaire(conteneur);

        const erreur = document.createElement("p");
        erreur.className = "erreur-fichier temporaire";
        erreur.textContent = message;

        conteneur.appendChild(erreur);
    }

    // Supprimer uniquement les éléments créés par le JavaScript
    function supprimerElementTemporaire(conteneur) {

        const elements = conteneur.querySelectorAll(".temporaire");

        elements.forEach(function (element) {
            element.remove();
        });
    }

    // Afficher une information sur le fichier
    function afficherInformation(conteneur, fichier) {

        const information = document.createElement("p");

        information.className = "information-fichier temporaire";

        information.textContent =
            "Fichier sélectionné : " +
            fichier.name +
            " (" +
            formaterTaille(fichier.size) +
            ")";

        conteneur.appendChild(information);
    }

    // Prévisualiser une photo
    function previsualiserPhoto(fichier) {

        supprimerElementTemporaire(apercuPhoto);

        if (urlPhoto) {
            URL.revokeObjectURL(urlPhoto);
            urlPhoto = null;
        }

        if (!fichier) {
            return true;
        }

        const extension = obtenirExtension(fichier);

        if (
            !EXTENSIONS_PHOTO.includes(extension) ||
            !TYPES_PHOTO.includes(fichier.type)
        ) {
            afficherErreur(
                apercuPhoto,
                "Format invalide. Utilisez une photo JPG, JPEG, PNG ou WEBP."
            );

            return false;
        }

        if (fichier.size > TAILLE_MAX_PHOTO) {

            afficherErreur(
                apercuPhoto,
                "La photo dépasse la limite autorisée de 5 Mo."
            );

            return false;
        }

        if (fichier.size === 0) {

            afficherErreur(
                apercuPhoto,
                "Le fichier sélectionné est vide."
            );

            return false;
        }

        urlPhoto = URL.createObjectURL(fichier);

        const image = document.createElement("img");

        image.className = "temporaire";
        image.src = urlPhoto;
        image.alt = "Aperçu de la photo de l'incident";

        apercuPhoto.appendChild(image);

        afficherInformation(apercuPhoto, fichier);

        return true;
    }

    // Prévisualiser une vidéo
    function previsualiserVideo(fichier) {

        supprimerElementTemporaire(apercuVideo);

        if (urlVideo) {
            URL.revokeObjectURL(urlVideo);
            urlVideo = null;
        }

        if (!fichier) {
            return true;
        }

        const extension = obtenirExtension(fichier);

        if (
            !EXTENSIONS_VIDEO.includes(extension) ||
            !TYPES_VIDEO.includes(fichier.type)
        ) {
            afficherErreur(
                apercuVideo,
                "Format invalide. Utilisez une vidéo MP4 ou WEBM."
            );

            return false;
        }

        if (fichier.size > TAILLE_MAX_VIDEO) {

            afficherErreur(
                apercuVideo,
                "La vidéo dépasse la limite autorisée de 30 Mo."
            );

            return false;
        }

        if (fichier.size === 0) {

            afficherErreur(
                apercuVideo,
                "Le fichier sélectionné est vide."
            );

            return false;
        }

        urlVideo = URL.createObjectURL(fichier);

        const video = document.createElement("video");

        video.className = "temporaire";
        video.src = urlVideo;
        video.controls = true;
        video.preload = "metadata";

        video.setAttribute(
            "aria-label",
            "Aperçu de la vidéo de l'incident"
        );

        apercuVideo.appendChild(video);

        afficherInformation(apercuVideo, fichier);

        return true;
    }

    // Quand une photo est sélectionnée
    champPhoto.addEventListener("change", function () {

        const fichier = champPhoto.files[0];

        if (!previsualiserPhoto(fichier)) {
            champPhoto.value = "";
        }
    });

    // Quand une vidéo est sélectionnée
    champVideo.addEventListener("change", function () {

        const fichier = champVideo.files[0];

        if (!previsualiserVideo(fichier)) {
            champVideo.value = "";
        }
    });

    // Vérification avant l'envoi du formulaire
    formulaire.addEventListener("submit", function (event) {

        const photo = champPhoto.files[0];
        const video = champVideo.files[0];

        let formulaireValide = true;

        if (photo && !previsualiserPhoto(photo)) {
            formulaireValide = false;
        }

        if (video && !previsualiserVideo(video)) {
            formulaireValide = false;
        }

        if (!formulaireValide) {

            event.preventDefault();

            alert(
                "Veuillez corriger les fichiers sélectionnés avant de continuer."
            );

            return;
        }

        // Ne pas bloquer l'envoi :
        // PHP et MySQL enregistrent réellement l'incident.
    });

    // Libérer les URL temporaires lorsque la page est quittée
    window.addEventListener("beforeunload", function () {

        if (urlPhoto) {
            URL.revokeObjectURL(urlPhoto);
        }

        if (urlVideo) {
            URL.revokeObjectURL(urlVideo);
        }
    });

});

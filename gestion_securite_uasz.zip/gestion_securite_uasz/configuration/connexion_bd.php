
<?php

$serveur = "localhost";
$nom_base = "gestion_securite_uasz";
$utilisateur = "root";
$mot_de_passe = "";

try {
    $connexion = new PDO(
        "mysql:host=$serveur;dbname=$nom_base;charset=utf8mb4",
        $utilisateur,
        $mot_de_passe
    );

    $connexion->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

    $connexion->setAttribute(
        PDO::ATTR_DEFAULT_FETCH_MODE,
        PDO::FETCH_ASSOC
    );

} catch (PDOException $erreur) {
    die("Erreur de connexion à la base de données.");
}

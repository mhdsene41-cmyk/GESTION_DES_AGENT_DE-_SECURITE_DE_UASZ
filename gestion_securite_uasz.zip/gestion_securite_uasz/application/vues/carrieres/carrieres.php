
<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';

exigerAcces('carrieres');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_carrieres'])) {
    $_SESSION['csrf_carrieres'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_carrieres'];

/* =====================================================
   FONCTIONS UTILITAIRES
===================================================== */

function reponseJSON($succes, $message = '', $donnees = [])
{
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'succes' => $succes,
        'message' => $message,
        'donnees' => $donnees
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

function nettoyer($valeur)
{
    return trim((string) ($valeur ?? ''));
}

function dateValide($date)
{
    $objet = DateTime::createFromFormat('!Y-m-d', $date);

    return $objet && $objet->format('Y-m-d') === $date;
}

function obtenirCarriere($connexion, $id)
{
    $requete = $connexion->prepare("
        SELECT
            c.*,
            a.matricule,
            a.nom,
            a.prenom
        FROM carrieres c
        INNER JOIN agents a ON a.id = c.agent_id
        WHERE c.id = ?
    ");

    $requete->execute([$id]);

    return $requete->fetch();
}

function enregistrerHistorique(
    $connexion,
    $carriere,
    $action,
    $ancienStatut = null,
    $nouveauStatut = null
) {
    $requete = $connexion->prepare("
        INSERT INTO historique_carrieres (
            carriere_id,
            agent_id,
            utilisateur_id,
            reference,
            matricule_agent,
            nom_agent,
            prenom_agent,
            type_evolution,
            ancienne_fonction,
            nouvelle_fonction,
            date_evolution,
            ancien_statut,
            nouveau_statut,
            motif,
            action
        ) VALUES (
            :carriere_id,
            :agent_id,
            :utilisateur_id,
            :reference,
            :matricule,
            :nom,
            :prenom,
            :type_evolution,
            :ancienne_fonction,
            :nouvelle_fonction,
            :date_evolution,
            :ancien_statut,
            :nouveau_statut,
            :motif,
            :action
        )
    ");

    $requete->execute([
        ':carriere_id' => $carriere['id'],
        ':agent_id' => $carriere['agent_id'],
        ':utilisateur_id' => $_SESSION['utilisateur_id'] ?? null,
        ':reference' => $carriere['reference'],
        ':matricule' => $carriere['matricule'],
        ':nom' => $carriere['nom'],
        ':prenom' => $carriere['prenom'],
        ':type_evolution' => $carriere['type_evolution'],
        ':ancienne_fonction' => $carriere['ancienne_fonction'],
        ':nouvelle_fonction' => $carriere['nouvelle_fonction'],
        ':date_evolution' => $carriere['date_evolution'],
        ':ancien_statut' => $ancienStatut,
        ':nouveau_statut' => $nouveauStatut,
        ':motif' => $carriere['motif'],
        ':action' => $action
    ]);
}

function notifierEvolution($connexion, $carriere, $modification = false)
{
    $utilisateurActuel = $_SESSION['utilisateur_id'] ?? 0;

    /*
     * Notifications destinées aux administrateurs
     * et aux utilisateurs ayant accès au module Notifications.
     */
    $requete = $connexion->prepare("
        SELECT DISTINCT u.id
        FROM utilisateurs u
        LEFT JOIN utilisateur_modules um
            ON um.utilisateur_id = u.id
        LEFT JOIN modules m
            ON m.id = um.module_id
        WHERE u.statut = 'actif'
          AND u.id <> ?
          AND (
              u.role = 'administrateur'
              OR m.code = 'notifications'
          )
    ");

    $requete->execute([$utilisateurActuel]);

    $destinataires = $requete->fetchAll(PDO::FETCH_COLUMN);

    $titre = $modification
        ? "Évolution professionnelle modifiée"
        : "Nouvelle évolution professionnelle";

    $message = $carriere['prenom'] . ' ' . $carriere['nom']
        . ' (' . $carriere['matricule'] . ') : '
        . $carriere['type_evolution']
        . ' — ' . $carriere['ancienne_fonction']
        . ' vers ' . $carriere['nouvelle_fonction']
        . '. Statut : ' . $carriere['statut'] . '.';

    $insertion = $connexion->prepare("
        INSERT INTO notifications (
            utilisateur_id,
            titre,
            message,
            type,
            lien
        ) VALUES (?, ?, ?, 'Carrières', ?)
    ");

    foreach ($destinataires as $destinataire) {
        $insertion->execute([
            $destinataire,
            $titre,
            $message,
            '../carrieres/carrieres.php'
        ]);
    }
}

/* =====================================================
   TRAITEMENT DES REQUÊTES AJAX
===================================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    if (
        !isset($_POST['csrf_token']) ||
        !hash_equals($_SESSION['csrf_carrieres'], $_POST['csrf_token'])
    ) {
        reponseJSON(false, 'Session expirée ou jeton de sécurité invalide.');
    }

    $action = nettoyer($_POST['action']);

    try {

        /* ---------------------------------------------
           CHARGER LES AGENTS
        --------------------------------------------- */

        if ($action === 'charger_agents') {

            $requete = $connexion->query("
                SELECT
                    id,
                    matricule,
                    nom,
                    prenom,
                    poste,
                    grade,
                    statut
                FROM agents
                ORDER BY nom ASC, prenom ASC
            ");

            reponseJSON(
                true,
                'Liste des agents chargée.',
                $requete->fetchAll()
            );
        }

        /* ---------------------------------------------
           LISTER LES CARRIERES
        --------------------------------------------- */

        if ($action === 'lister') {

            $requete = $connexion->query("
                SELECT
                    c.id,
                    c.reference,
                    c.agent_id,
                    c.type_evolution,
                    c.ancienne_fonction,
                    c.nouvelle_fonction,
                    c.date_evolution,
                    c.statut,
                    c.motif,
                    c.date_creation,
                    a.matricule,
                    a.nom,
                    a.prenom
                FROM carrieres c
                INNER JOIN agents a ON a.id = c.agent_id
                ORDER BY c.date_evolution DESC, c.id DESC
            ");

            reponseJSON(
                true,
                'Évolutions chargées.',
                $requete->fetchAll()
            );
        }

        /* ---------------------------------------------
           AJOUTER OU MODIFIER UNE EVOLUTION
        --------------------------------------------- */

        if ($action === 'ajouter' || $action === 'modifier') {

            $id = filter_var(
                $_POST['id'] ?? null,
                FILTER_VALIDATE_INT
            );

            $agentId = filter_var(
                $_POST['agent_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            $type = nettoyer($_POST['type_evolution'] ?? '');
            $ancienneFonction = nettoyer($_POST['ancienne_fonction'] ?? '');
            $nouvelleFonction = nettoyer($_POST['nouvelle_fonction'] ?? '');
            $date = nettoyer($_POST['date_evolution'] ?? '');
            $statut = nettoyer($_POST['statut'] ?? '');
            $motif = nettoyer($_POST['motif'] ?? '');

            $typesAutorises = [
                'Promotion',
                'Changement de grade',
                'Changement de fonction'
            ];

            $statutsAutorises = [
                'En attente',
                'Validée',
                'Refusée'
            ];

            if (!$agentId || $agentId <= 0) {
                reponseJSON(false, 'Veuillez sélectionner un agent.');
            }

            if (!in_array($type, $typesAutorises, true)) {
                reponseJSON(false, 'Type d’évolution invalide.');
            }

            if ($ancienneFonction === '' || $nouvelleFonction === '') {
                reponseJSON(false, 'Veuillez renseigner les deux fonctions ou grades.');
            }

            if (
                mb_strlen($ancienneFonction) > 150 ||
                mb_strlen($nouvelleFonction) > 150
            ) {
                reponseJSON(false, 'Les fonctions ou grades ne doivent pas dépasser 150 caractères.');
            }

            if (!dateValide($date)) {
                reponseJSON(false, 'Veuillez renseigner une date valide.');
            }

            if (!in_array($statut, $statutsAutorises, true)) {
                reponseJSON(false, 'Statut invalide.');
            }

            $requeteAgent = $connexion->prepare("
                SELECT id
                FROM agents
                WHERE id = ?
            ");

            $requeteAgent->execute([$agentId]);

            if (!$requeteAgent->fetch()) {
                reponseJSON(false, 'L’agent sélectionné n’existe pas.');
            }

            $connexion->beginTransaction();

            if ($action === 'ajouter') {

                $reference = 'CAR-' . date('Ymd') . '-'
                    . strtoupper(bin2hex(random_bytes(3)));

                $requete = $connexion->prepare("
                    INSERT INTO carrieres (
                        reference,
                        agent_id,
                        type_evolution,
                        ancienne_fonction,
                        nouvelle_fonction,
                        date_evolution,
                        statut,
                        motif,
                        utilisateur_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

                $requete->execute([
                    $reference,
                    $agentId,
                    $type,
                    $ancienneFonction,
                    $nouvelleFonction,
                    $date,
                    $statut,
                    $motif !== '' ? $motif : null,
                    $_SESSION['utilisateur_id'] ?? null
                ]);

                $nouvelId = (int) $connexion->lastInsertId();

                $carriere = obtenirCarriere($connexion, $nouvelId);

                enregistrerHistorique(
                    $connexion,
                    $carriere,
                    'creation',
                    null,
                    $statut
                );

                notifierEvolution($connexion, $carriere, false);

                $connexion->commit();

                reponseJSON(
                    true,
                    'Évolution professionnelle enregistrée avec succès.'
                );
            }

            /* MODIFICATION */

            if (!$id || $id <= 0) {
                $connexion->rollBack();
                reponseJSON(false, 'Identifiant de carrière invalide.');
            }

            $ancienneCarriere = obtenirCarriere($connexion, $id);

            if (!$ancienneCarriere) {
                $connexion->rollBack();
                reponseJSON(false, 'Cette évolution professionnelle est introuvable.');
            }

            $requete = $connexion->prepare("
                UPDATE carrieres
                SET
                    agent_id = ?,
                    type_evolution = ?,
                    ancienne_fonction = ?,
                    nouvelle_fonction = ?,
                    date_evolution = ?,
                    statut = ?,
                    motif = ?
                WHERE id = ?
            ");

            $requete->execute([
                $agentId,
                $type,
                $ancienneFonction,
                $nouvelleFonction,
                $date,
                $statut,
                $motif !== '' ? $motif : null,
                $id
            ]);

            $carriereModifiee = obtenirCarriere($connexion, $id);

            enregistrerHistorique(
                $connexion,
                $carriereModifiee,
                'modification',
                $ancienneCarriere['statut'],
                $statut
            );

            notifierEvolution($connexion, $carriereModifiee, true);

            $connexion->commit();

            reponseJSON(
                true,
                'Évolution professionnelle modifiée avec succès.'
            );
        }

        /* ---------------------------------------------
           SUPPRIMER UNE EVOLUTION
        --------------------------------------------- */

        if ($action === 'supprimer') {

            $id = filter_var(
                $_POST['id'] ?? null,
                FILTER_VALIDATE_INT
            );

            if (!$id || $id <= 0) {
                reponseJSON(false, 'Identifiant invalide.');
            }

            $connexion->beginTransaction();

            $carriere = obtenirCarriere($connexion, $id);

            if (!$carriere) {
                $connexion->rollBack();
                reponseJSON(false, 'Évolution introuvable.');
            }

            enregistrerHistorique(
                $connexion,
                $carriere,
                'suppression',
                $carriere['statut'],
                null
            );

            $requete = $connexion->prepare("
                DELETE FROM carrieres
                WHERE id = ?
            ");

            $requete->execute([$id]);

            $connexion->commit();

            reponseJSON(
                true,
                'Évolution supprimée. Son historique a été conservé.'
            );
        }

        reponseJSON(false, 'Action inconnue.');

    } catch (Throwable $erreur) {

        if ($connexion->inTransaction()) {
            $connexion->rollBack();
        }

        error_log('Erreur module Carrières : ' . $erreur->getMessage());

        reponseJSON(
            false,
            'Une erreur est survenue. Vérifiez la base de données et réessayez.'
        );
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Gestion des carrières | Gestion Sécurité UASZ</title>

    <link rel="stylesheet" href="../../../public/css/carrieres.css?v=2">
</head>

<body>

<div class="app-container">

    <aside class="sidebar">

        <div class="sidebar-header">
            <h2>Gestion Sécurité</h2>
            <p>Université Assane Seck</p>
        </div>

        <nav class="sidebar-menu">

            <a href="../tableau_de_bord/tableau_de_bord.php">Tableau de bord</a>
            <a href="../utilisateurs/utilisateurs.php">Utilisateurs</a>
            <a href="../agents/agents.php">Agents</a>
            <a href="../recrutement/recrutement.php">Recrutement</a>
            <a href="carrieres.php" class="active">Carrières</a>
            <a href="../affectations/affectations.php">Affectations</a>
            <a href="../agents/presences.php">Présences</a>
            <a href="../agents/plannings.php">Plannings</a>
            <a href="../agents/incidents.php">Incidents</a>
            <a href="../demandes/demandes.php">Demandes</a>
            <a href="../rapports/rapports.php">Rapports et statistiques</a>
            <a href="../profil/profil.php">Mon profil</a>
            <a href="../notifications/notifications.php">Notifications</a>

        </nav>

        <div class="sidebar-footer">
            <a href="../authentification/connexion.php">Déconnexion</a>
        </div>

    </aside>

    <main class="main-content">

        <header class="topbar">
            <div>
                <h1>Gestion des carrières</h1>
                <p>Suivi de l'évolution professionnelle des agents</p>
            </div>

            <div class="admin-info">
                <span>Gestion des évolutions</span>
            </div>
        </header>

        <section class="stats-container">

            <div class="stat-card">
                <h3>Total des évolutions</h3>
                <h2 id="totalCarrieres">0</h2>
            </div>

            <div class="stat-card">
                <h3>Promotions</h3>
                <h2 id="totalPromotions">0</h2>
            </div>

            <div class="stat-card">
                <h3>Changements de fonction</h3>
                <h2 id="totalFonctions">0</h2>
            </div>

            <div class="stat-card">
                <h3>En attente</h3>
                <h2 id="totalEnAttente">0</h2>
            </div>

        </section>

        <section class="content-card">

            <div class="section-header">
                <div>
                    <h2>Historique des carrières</h2>
                    <p>Consultez et gérez les évolutions des agents.</p>
                </div>

                <button id="btnAjouterCarriere" class="btn-primary" type="button">
                    + Nouvelle évolution
                </button>
            </div>

            <div class="filters">

                <input
                    type="text"
                    id="rechercheCarriere"
                    placeholder="Rechercher un agent..."
                >

                <select id="filtreType">
                    <option value="">Tous les types</option>
                    <option value="Promotion">Promotion</option>
                    <option value="Changement de grade">Changement de grade</option>
                    <option value="Changement de fonction">Changement de fonction</option>
                </select>

                <select id="filtreStatut">
                    <option value="">Tous les statuts</option>
                    <option value="En attente">En attente</option>
                    <option value="Validée">Validée</option>
                    <option value="Refusée">Refusée</option>
                </select>

            </div>

            <div class="table-container">

                <table>
                    <thead>
                        <tr>
                            <th>Référence</th>
                            <th>Agent</th>
                            <th>Type d'évolution</th>
                            <th>Ancienne fonction</th>
                            <th>Nouvelle fonction</th>
                            <th>Date</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody id="tableauCarrieres">
                        <tr>
                            <td colspan="8" style="text-align:center;padding:25px;">
                                Chargement des évolutions...
                            </td>
                        </tr>
                    </tbody>
                </table>

            </div>

        </section>

    </main>

</div>

<div id="modalCarriere" class="modal">

    <div class="modal-content">

        <div class="modal-header">
            <h2 id="titreModal">Nouvelle évolution</h2>
            <button type="button" id="fermerModal">&times;</button>
        </div>

        <form id="formCarriere">

            <input type="hidden" id="idCarriere">

            <div class="form-group">
                <label for="agentCarriere">Agent</label>
                <select id="agentCarriere" required>
                    <option value="">Chargement des agents...</option>
                </select>
            </div>

            <div class="form-group">
                <label for="typeEvolution">Type d'évolution</label>
                <select id="typeEvolution" required>
                    <option value="">Choisir un type</option>
                    <option value="Promotion">Promotion</option>
                    <option value="Changement de grade">Changement de grade</option>
                    <option value="Changement de fonction">Changement de fonction</option>
                </select>
            </div>

            <div class="form-group">
                <label for="ancienneFonction">Ancienne fonction / grade</label>
                <input type="text" id="ancienneFonction" maxlength="150" required>
            </div>

            <div class="form-group">
                <label for="nouvelleFonction">Nouvelle fonction / grade</label>
                <input type="text" id="nouvelleFonction" maxlength="150" required>
            </div>

            <div class="form-group">
                <label for="dateEvolution">Date de décision</label>
                <input type="date" id="dateEvolution" required>
            </div>

            <div class="form-group">
                <label for="statutCarriere">Statut</label>
                <select id="statutCarriere" required>
                    <option value="En attente">En attente</option>
                    <option value="Validée">Validée</option>
                    <option value="Refusée">Refusée</option>
                </select>
            </div>

            <div class="form-group">
                <label for="motifCarriere">Motif / Observations</label>
                <textarea id="motifCarriere" rows="4"></textarea>
            </div>

            <div class="modal-actions">

                <button type="button" id="annulerCarriere" class="btn-secondary">
                    Annuler
                </button>

                <button type="submit" id="btnEnregistrerCarriere" class="btn-primary">
                    Enregistrer
                </button>

            </div>

        </form>

    </div>

</div>

<script>
    window.CSRF_CARRIERES = <?= json_encode($csrfToken) ?>;
</script>

<script src="../../../public/js/carrieres.js?v=2"></script>

</body>
</html>

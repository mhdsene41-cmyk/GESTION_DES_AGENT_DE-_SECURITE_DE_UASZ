
<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';
exigerAcces('affectations');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e($valeur) {
    return htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_affectations'])) {
    $_SESSION['csrf_affectations'] = bin2hex(random_bytes(32));
}

$csrf = $_SESSION['csrf_affectations'];
$utilisateurConnecte = (int) ($_SESSION['utilisateur_id'] ?? 0);

$etats = [
    'planifiee' => 'Planifiée',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée'
];

$messageErreur = '';
$messageSucces = '';

$affectation = [
    'id' => '',
    'agent_id' => '',
    'secteur' => '',
    'batiment' => '',
    'photo_batiment' => '',
    'date_affectation' => '',
    'heure_debut' => '',
    'heure_fin' => '',
    'etat' => 'planifiee',
    'observations' => ''
];

$modeEdition = false;

$dossierPhotos = __DIR__ . '/../../../stockage/photos_batiments/';
$urlPhotos = '../../../stockage/photos_batiments/';

/* Enregistrer une copie dans l'historique */
function enregistrerHistorique(
    PDO $connexion,
    array $donnees,
    string $action,
    int $utilisateurId
): void {
    $sql = "
        INSERT INTO historique_affectations (
            affectation_id, agent_id, utilisateur_id,
            matricule_agent, nom_agent, prenom_agent,
            secteur, batiment, photo_batiment,
            date_affectation, heure_debut, heure_fin,
            etat, observations, action
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ";

    $req = $connexion->prepare($sql);

    $req->execute([
        $donnees['id'] ?? null,
        $donnees['agent_id'] ?? null,
        $utilisateurId ?: null,
        $donnees['matricule'] ?? null,
        $donnees['nom'] ?? 'Agent inconnu',
        $donnees['prenom'] ?? '',
        $donnees['secteur'],
        $donnees['batiment'],
        $donnees['photo_batiment'] ?? null,
        $donnees['date_affectation'],
        $donnees['heure_debut'],
        $donnees['heure_fin'],
        $donnees['etat'],
        $donnees['observations'] ?? null,
        $action
    ]);
}

/* Récupérer une affectation avec les informations de son agent */
function obtenirAffectation(PDO $connexion, int $id): ?array {
    $req = $connexion->prepare("
        SELECT a.*, ag.matricule, ag.nom, ag.prenom
        FROM affectations a
        INNER JOIN agents ag ON ag.id = a.agent_id
        WHERE a.id = ?
    ");

    $req->execute([$id]);
    $resultat = $req->fetch();

    return $resultat ?: null;
}

/* Envoyer une notification aux administrateurs et aux utilisateurs autorisés */
function notifierAffectation(
    PDO $connexion,
    int $utilisateurActuel,
    string $titre,
    string $message,
    int $affectationId
): void {
    $sql = "
        SELECT DISTINCT u.id
        FROM utilisateurs u
        LEFT JOIN utilisateur_modules um
            ON um.utilisateur_id = u.id
        LEFT JOIN modules m
            ON m.id = um.module_id
            AND m.code = 'notifications'
        WHERE u.statut = 'actif'
          AND (u.role = 'administrateur' OR m.id IS NOT NULL)
          AND u.id <> ?
    ";

    $req = $connexion->prepare($sql);
    $req->execute([$utilisateurActuel]);
    $destinataires = $req->fetchAll(PDO::FETCH_COLUMN);

    if (!$destinataires) {
        return;
    }

    $insertion = $connexion->prepare("
        INSERT INTO notifications
        (utilisateur_id, titre, message, type, lien)
        VALUES (?, ?, ?, 'Affectation', ?)
    ");

    foreach ($destinataires as $destinataire) {
        $insertion->execute([
            (int) $destinataire,
            $titre,
            $message,
            '../agents/affectations.php'
        ]);
    }
}

/* TRAITEMENT DES FORMULAIRES */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jeton = $_POST['csrf_token'] ?? '';

    if (!hash_equals($csrf, $jeton)) {
        $messageErreur = "Votre session a expiré. Rechargez la page.";
    } else {
        $action = $_POST['action'] ?? 'enregistrer';

        /* SUPPRESSION */
        if ($action === 'supprimer') {
            $idSuppression = (int) ($_POST['id'] ?? 0);
            $anciennePhoto = '';

            try {
                $ancienne = obtenirAffectation($connexion, $idSuppression);

                if (!$ancienne) {
                    throw new RuntimeException("Affectation introuvable.");
                }

                $connexion->beginTransaction();

                enregistrerHistorique(
                    $connexion,
                    $ancienne,
                    'suppression',
                    $utilisateurConnecte
                );

                notifierAffectation(
                    $connexion,
                    $utilisateurConnecte,
                    'Affectation supprimée',
                    'L’affectation de ' . $ancienne['prenom'] . ' '
                    . $ancienne['nom'] . ' au bâtiment '
                    . $ancienne['batiment'] . ' a été supprimée.',
                    $idSuppression
                );

                $req = $connexion->prepare(
                    "DELETE FROM affectations WHERE id = ?"
                );
                $req->execute([$idSuppression]);

                $connexion->commit();

                header('Location: affectations.php?succes=suppression');
                exit;

            } catch (Throwable $erreur) {
                if ($connexion->inTransaction()) {
                    $connexion->rollBack();
                }

                $messageErreur = $erreur instanceof RuntimeException
                    ? $erreur->getMessage()
                    : "Impossible de supprimer cette affectation.";
            }
        }

        /* CRÉATION OU MODIFICATION */
        elseif ($action === 'enregistrer') {
            $id = (int) ($_POST['id'] ?? 0);
            $agentId = (int) ($_POST['agent_id'] ?? 0);
            $secteur = trim($_POST['secteur'] ?? '');
            $batiment = trim($_POST['batiment'] ?? '');
            $date = $_POST['date_affectation'] ?? '';
            $heureDebut = $_POST['heure_debut'] ?? '';
            $heureFin = $_POST['heure_fin'] ?? '';
            $etat = $_POST['etat'] ?? 'planifiee';
            $observations = trim($_POST['observations'] ?? '');

            $ancienne = $id > 0
                ? obtenirAffectation($connexion, $id)
                : null;

            $photoExistante = $ancienne['photo_batiment'] ?? '';

            $affectation = [
                'id' => $id,
                'agent_id' => $agentId,
                'secteur' => $secteur,
                'batiment' => $batiment,
                'photo_batiment' => $photoExistante,
                'date_affectation' => $date,
                'heure_debut' => $heureDebut,
                'heure_fin' => $heureFin,
                'etat' => $etat,
                'observations' => $observations
            ];

            if ($id > 0 && !$ancienne) {
                $messageErreur = "Affectation introuvable.";
            } elseif (
                $agentId <= 0 || $secteur === '' || $batiment === '' ||
                $date === '' || $heureDebut === '' || $heureFin === ''
            ) {
                $messageErreur = "Veuillez remplir tous les champs obligatoires.";
            } elseif ($heureDebut >= $heureFin) {
                $messageErreur = "L'heure de fin doit être après l'heure de début.";
            } elseif (!array_key_exists($etat, $etats)) {
                $messageErreur = "L'état sélectionné est invalide.";
            } elseif (
                !DateTime::createFromFormat('Y-m-d', $date) ||
                DateTime::createFromFormat('Y-m-d', $date)->format('Y-m-d') !== $date
            ) {
                $messageErreur = "La date sélectionnée est invalide.";
            }

            /* Vérifier l'agent */
            if ($messageErreur === '') {
                $reqAgent = $connexion->prepare("
                    SELECT id
                    FROM agents
                    WHERE id = ? AND statut = 'actif'
                ");
                $reqAgent->execute([$agentId]);

                if (!$reqAgent->fetch()) {
                    $messageErreur = "L'agent sélectionné n'existe pas ou n'est pas actif.";
                }
            }

            /* Vérifier les horaires qui se chevauchent */
            if (
                $messageErreur === '' &&
                in_array($etat, ['planifiee', 'en_cours'], true)
            ) {
                $sql = "
                    SELECT COUNT(*)
                    FROM affectations
                    WHERE agent_id = ?
                      AND date_affectation = ?
                      AND etat IN ('planifiee', 'en_cours')
                      AND heure_debut < ?
                      AND heure_fin > ?
                ";

                $parametres = [
                    $agentId, $date, $heureFin, $heureDebut
                ];

                if ($id > 0) {
                    $sql .= " AND id <> ?";
                    $parametres[] = $id;
                }

                $req = $connexion->prepare($sql);
                $req->execute($parametres);

                if ($req->fetchColumn() > 0) {
                    $messageErreur = "Cet agent possède déjà une affectation sur cette plage horaire.";
                }
            }

            /* Gestion de la photo */
            $nouvellePhoto = '';
            $fichierPhoto = $_FILES['photo_batiment'] ?? null;

            if (
                $messageErreur === '' &&
                $fichierPhoto &&
                $fichierPhoto['error'] !== UPLOAD_ERR_NO_FILE
            ) {
                if ($fichierPhoto['error'] !== UPLOAD_ERR_OK) {
                    $messageErreur = "Erreur pendant l'envoi de la photo.";
                } elseif ($fichierPhoto['size'] > 4 * 1024 * 1024) {
                    $messageErreur = "La photo ne doit pas dépasser 4 Mo.";
                } else {
                    $informationsImage = @getimagesize($fichierPhoto['tmp_name']);

                    $typesAutorises = [
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/webp' => 'webp'
                    ];

                    $mime = $informationsImage['mime'] ?? '';

                    if (!$informationsImage || !isset($typesAutorises[$mime])) {
                        $messageErreur = "Format non accepté. Utilisez JPG, PNG ou WEBP.";
                    } else {
                        if (!is_dir($dossierPhotos)) {
                            mkdir($dossierPhotos, 0755, true);
                        }

                        $nomFichier = 'batiment_' . bin2hex(random_bytes(12))
                            . '.' . $typesAutorises[$mime];

                        if (move_uploaded_file(
                            $fichierPhoto['tmp_name'],
                            $dossierPhotos . $nomFichier
                        )) {
                            $nouvellePhoto = $nomFichier;
                        } else {
                            $messageErreur = "Impossible d'enregistrer la photo.";
                        }
                    }
                }
            }

            /* Enregistrement dans la base */
            if ($messageErreur === '') {
                $photoFinale = $nouvellePhoto !== ''
                    ? $nouvellePhoto
                    : $photoExistante;

                try {
                    $connexion->beginTransaction();

                    /* Conserver l'ancienne version avant modification */
                    if ($ancienne) {
                        enregistrerHistorique(
                            $connexion,
                            $ancienne,
                            'modification',
                            $utilisateurConnecte
                        );
                    }

                    if ($id > 0) {
                        $sql = "
                            UPDATE affectations
                            SET agent_id = ?, secteur = ?, batiment = ?,
                                photo_batiment = ?, date_affectation = ?,
                                heure_debut = ?, heure_fin = ?, etat = ?,
                                observations = ?
                            WHERE id = ?
                        ";

                        $req = $connexion->prepare($sql);
                        $req->execute([
                            $agentId, $secteur, $batiment, $photoFinale,
                            $date, $heureDebut, $heureFin, $etat,
                            $observations, $id
                        ]);
                    } else {
                        $sql = "
                            INSERT INTO affectations (
                                agent_id, secteur, batiment, photo_batiment,
                                date_affectation, heure_debut, heure_fin,
                                etat, observations
                            )
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ";

                        $req = $connexion->prepare($sql);
                        $req->execute([
                            $agentId, $secteur, $batiment, $photoFinale,
                            $date, $heureDebut, $heureFin, $etat,
                            $observations
                        ]);

                        $id = (int) $connexion->lastInsertId();

                        $nouvelle = obtenirAffectation($connexion, $id);

                        enregistrerHistorique(
                            $connexion,
                            $nouvelle,
                            'creation',
                            $utilisateurConnecte
                        );
                    }

                    $agent = $connexion->prepare("
                        SELECT nom, prenom FROM agents WHERE id = ?
                    ");
                    $agent->execute([$agentId]);
                    $infosAgent = $agent->fetch();

                    notifierAffectation(
                        $connexion,
                        $utilisateurConnecte,
                        $ancienne ? 'Affectation modifiée' : 'Nouvelle affectation',
                        'Une affectation concernant '
                        . ($infosAgent['prenom'] ?? '')
                        . ' ' . ($infosAgent['nom'] ?? '')
                        . ' au bâtiment ' . $batiment
                        . ' a été ' . ($ancienne ? 'modifiée.' : 'créée.'),
                        $id
                    );

                    $connexion->commit();

                    /*
                     * On conserve les anciennes photos dans le dossier
                     * pour préserver les images de l'historique.
                     */

                    header('Location: affectations.php?succes='
                        . ($ancienne ? 'modification' : 'creation'));
                    exit;

                } catch (Throwable $erreur) {
                    if ($connexion->inTransaction()) {
                        $connexion->rollBack();
                    }

                    if ($nouvellePhoto !== '') {
                        $chemin = $dossierPhotos . basename($nouvellePhoto);
                        if (is_file($chemin)) {
                            unlink($chemin);
                        }
                    }

                    $messageErreur = "Impossible d'enregistrer l'affectation. Vérifiez les informations.";
                }
            }
        }
    }
}

/* Charger une affectation à modifier */
if (
    $_SERVER['REQUEST_METHOD'] !== 'POST' &&
    isset($_GET['modifier'])
) {
    $idEdition = (int) $_GET['modifier'];
    $resultat = obtenirAffectation($connexion, $idEdition);

    if ($resultat) {
        $affectation = $resultat;
        $modeEdition = true;
    } else {
        $messageErreur = "Affectation introuvable.";
    }
}

/* Messages après redirection */
if (isset($_GET['succes'])) {
    $messages = [
        'creation' => "L'affectation a été créée avec succès.",
        'modification' => "L'affectation a été modifiée avec succès.",
        'suppression' => "L'affectation a été supprimée avec succès."
    ];

    $messageSucces = $messages[$_GET['succes']] ?? '';
}

/* Agents actifs et agent actuel */
$sqlAgents = "
    SELECT id, matricule, nom, prenom, statut
    FROM agents
    WHERE statut = 'actif'
";

$paramAgents = [];

if (!empty($affectation['agent_id'])) {
    $sqlAgents .= " OR id = ?";
    $paramAgents[] = $affectation['agent_id'];
}

$sqlAgents .= " ORDER BY nom, prenom";

$reqAgents = $connexion->prepare($sqlAgents);
$reqAgents->execute($paramAgents);
$agents = $reqAgents->fetchAll();

/* Liste actuelle */
$affectations = $connexion->query("
    SELECT a.*, ag.matricule, ag.nom, ag.prenom
    FROM affectations a
    INNER JOIN agents ag ON ag.id = a.agent_id
    ORDER BY a.date_affectation DESC, a.heure_debut DESC
")->fetchAll();

/* Historique récent */
$historique = $connexion->query("
    SELECT *
    FROM historique_affectations
    ORDER BY date_action DESC, id DESC
    LIMIT 100
")->fetchAll();

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des affectations | UASZ</title>
    <link rel="stylesheet" href="../../../public/css/affectations.css?v=2">
</head>
<body>

<div class="page-container">

    <header class="page-header">
        <div>
            <span class="sur-titre">GESTION DE LA SÉCURITÉ UASZ</span>
            <h1>Gestion des affectations</h1>
            <p>Organisez les missions des agents sur les différents bâtiments.</p>
        </div>

        <a class="bouton-retour" href="../tableau_de_bord/tableau_de_bord.php">
            ← Tableau de bord
        </a>
    </header>

    <?php if ($messageErreur): ?>
        <div class="message erreur"><?= e($messageErreur) ?></div>
    <?php endif; ?>

    <?php if ($messageSucces): ?>
        <div class="message succes"><?= e($messageSucces) ?></div>
    <?php endif; ?>

    <section class="formulaire-section">
        <div class="section-titre">
            <div>
                <h2>
                    <?= $modeEdition || !empty($affectation['id'])
                        ? 'Modifier une affectation'
                        : 'Nouvelle affectation' ?>
                </h2>
                <p>Les champs marqués d'un * sont obligatoires.</p>
            </div>
        </div>

        <?php if (count($agents) === 0): ?>
            <div class="message information">
                Aucun agent actif n'est disponible. Ajoutez d'abord un agent dans le module Agents.
            </div>
        <?php else: ?>

        <form method="POST" enctype="multipart/form-data" class="form-affectation">
            <input type="hidden" name="csrf_token" value="<?= e($csrf) ?>">
            <input type="hidden" name="action" value="enregistrer">
            <input type="hidden" name="id" value="<?= e($affectation['id']) ?>">

            <div class="form-grid">

                <div class="champ">
                    <label for="agent_id">Agent à affecter *</label>
                    <select name="agent_id" id="agent_id" required>
                        <option value="">-- Choisir un agent --</option>

                        <?php foreach ($agents as $agent): ?>
                            <option value="<?= e($agent['id']) ?>"
                                <?= (string)$affectation['agent_id'] === (string)$agent['id'] ? 'selected' : '' ?>>
                                <?= e($agent['matricule'] . ' - ' . $agent['prenom'] . ' ' . $agent['nom']) ?>
                                <?= $agent['statut'] !== 'actif' ? ' (Inactif)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="champ">
                    <label for="secteur">Secteur *</label>
                    <input type="text" name="secteur" id="secteur"
                        value="<?= e($affectation['secteur']) ?>"
                        placeholder="Ex. : Secteur Nord" required>
                </div>

                <div class="champ">
                    <label for="batiment">Nom du bâtiment *</label>
                    <input type="text" name="batiment" id="batiment"
                        value="<?= e($affectation['batiment']) ?>"
                        placeholder="Ex. : Bâtiment UFR Sciences" required>
                </div>

                <div class="champ">
                    <label for="photo_batiment">Photo du bâtiment</label>
                    <input type="file" name="photo_batiment" id="photo_batiment"
                        accept="image/jpeg,image/png,image/webp">
                    <small>Formats JPG, PNG ou WEBP — 4 Mo maximum.</small>

                    <div class="apercu-conteneur">
                        <img id="apercu-photo"
                            src="<?= !empty($affectation['photo_batiment'])
                                ? e($urlPhotos . basename($affectation['photo_batiment']))
                                : '' ?>"
                            alt="Aperçu du bâtiment"
                            class="<?= !empty($affectation['photo_batiment']) ? 'visible' : '' ?>">

                        <span id="texte-apercu"
                            <?= !empty($affectation['photo_batiment']) ? 'hidden' : '' ?>>
                            Aperçu de la photo
                        </span>
                    </div>
                </div>

                <div class="champ">
                    <label for="date_affectation">Date d'affectation *</label>
                    <input type="date" name="date_affectation" id="date_affectation"
                        value="<?= e($affectation['date_affectation']) ?>" required>
                </div>

                <div class="champ">
                    <label for="heure_debut">Heure de début *</label>
                    <input type="time" name="heure_debut" id="heure_debut"
                        value="<?= e($affectation['heure_debut']) ?>" required>
                </div>

                <div class="champ">
                    <label for="heure_fin">Heure de fin *</label>
                    <input type="time" name="heure_fin" id="heure_fin"
                        value="<?= e($affectation['heure_fin']) ?>" required>
                </div>

                <div class="champ">
                    <label for="etat">État de l'affectation</label>
                    <select name="etat" id="etat">
                        <?php foreach ($etats as $cle => $libelle): ?>
                            <option value="<?= e($cle) ?>"
                                <?= $affectation['etat'] === $cle ? 'selected' : '' ?>>
                                <?= e($libelle) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="champ champ-large">
                    <label for="observations">Observations</label>
                    <textarea name="observations" id="observations" rows="3"
                        placeholder="Informations complémentaires..."><?= e($affectation['observations']) ?></textarea>
                </div>

            </div>

            <div class="form-actions">
                <?php if ($modeEdition || !empty($affectation['id'])): ?>
                    <a href="affectations.php" class="bouton-annuler">Annuler</a>
                <?php endif; ?>

                <button type="submit" class="bouton-principal">
                    <?= $modeEdition || !empty($affectation['id'])
                        ? 'Enregistrer les modifications'
                        : 'Créer l’affectation' ?>
                </button>
            </div>
        </form>
        <?php endif; ?>
    </section>

    <section class="liste-section">
        <div class="section-titre">
            <div>
                <h2>Liste des affectations</h2>
                <p>Consultez les missions programmées et leur état.</p>
            </div>
            <span class="compteur"><?= count($affectations) ?> affectation(s)</span>
        </div>

        <?php if (count($affectations) === 0): ?>
            <div class="vide">
                <div class="vide-icone">📋</div>
                <h3>Aucune affectation enregistrée</h3>
                <p>Les affectations créées apparaîtront ici.</p>
            </div>
        <?php else: ?>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Bâtiment</th>
                        <th>Agent</th>
                        <th>Secteur</th>
                        <th>Date</th>
                        <th>Horaires</th>
                        <th>État</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                <?php foreach ($affectations as $item): ?>
                    <tr>
                        <td>
                            <div class="batiment-cellule">
                                <?php if (!empty($item['photo_batiment'])): ?>
                                    <img src="<?= e($urlPhotos . basename($item['photo_batiment'])) ?>"
                                        alt="Photo du bâtiment">
                                <?php else: ?>
                                    <div class="photo-manquante">🏢</div>
                                <?php endif; ?>

                                <strong><?= e($item['batiment']) ?></strong>
                            </div>
                        </td>

                        <td>
                            <?= e($item['prenom'] . ' ' . $item['nom']) ?>
                            <small class="matricule"><?= e($item['matricule']) ?></small>
                        </td>

                        <td><?= e($item['secteur']) ?></td>
                        <td><?= e(date('d/m/Y', strtotime($item['date_affectation']))) ?></td>

                        <td>
                            <?= e(substr($item['heure_debut'], 0, 5)) ?>
                            – <?= e(substr($item['heure_fin'], 0, 5)) ?>
                        </td>

                        <td>
                            <span class="etat etat-<?= e($item['etat']) ?>">
                                <?= e($etats[$item['etat']] ?? $item['etat']) ?>
                            </span>
                        </td>

                        <td>
                            <a class="bouton-modifier"
                                href="affectations.php?modifier=<?= e($item['id']) ?>">
                                Modifier
                            </a>

                            <form method="POST" class="form-suppression">
                                <input type="hidden" name="csrf_token" value="<?= e($csrf) ?>">
                                <input type="hidden" name="action" value="supprimer">
                                <input type="hidden" name="id" value="<?= e($item['id']) ?>">

                                <button type="submit" class="bouton-supprimer">
                                    Supprimer
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </section>

    <section class="liste-section">
        <div class="section-titre">
            <div>
                <h2>Historique des affectations</h2>
                <p>Retrouvez les créations, modifications et suppressions.</p>
            </div>
            <span class="compteur"><?= count($historique) ?> opération(s)</span>
        </div>

        <?php if (count($historique) === 0): ?>
            <div class="vide">
                <div class="vide-icone">🕘</div>
                <h3>Aucun historique disponible</h3>
                <p>Les opérations futures seront enregistrées ici.</p>
            </div>
        <?php else: ?>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Date de l'opération</th>
                        <th>Agent</th>
                        <th>Bâtiment</th>
                        <th>Secteur</th>
                        <th>Mission</th>
                        <th>État</th>
                        <th>Opération</th>
                    </tr>
                </thead>

                <tbody>
                <?php foreach ($historique as $ligne): ?>
                    <tr>
                        <td><?= e(date('d/m/Y H:i', strtotime($ligne['date_action']))) ?></td>

                        <td>
                            <?= e($ligne['prenom_agent'] . ' ' . $ligne['nom_agent']) ?>
                            <small class="matricule"><?= e($ligne['matricule_agent']) ?></small>
                        </td>

                        <td>
                            <strong><?= e($ligne['batiment']) ?></strong>
                            <?php if (!empty($ligne['photo_batiment'])): ?>
                                <small>
                                    <a href="<?= e($urlPhotos . basename($ligne['photo_batiment'])) ?>"
                                        target="_blank" rel="noopener">Voir la photo</a>
                                </small>
                            <?php endif; ?>
                        </td>

                        <td><?= e($ligne['secteur']) ?></td>

                        <td>
                            <?= e(date('d/m/Y', strtotime($ligne['date_affectation']))) ?>
                            <small class="matricule">
                                <?= e(substr($ligne['heure_debut'], 0, 5)) ?>
                                – <?= e(substr($ligne['heure_fin'], 0, 5)) ?>
                            </small>
                        </td>

                        <td>
                            <?= e($etats[$ligne['etat']] ?? $ligne['etat']) ?>
                        </td>

                        <td>
                            <?php
                            $libellesActions = [
                                'creation' => 'Création',
                                'modification' => 'Modification',
                                'suppression' => 'Suppression'
                            ];
                            ?>
                            <?= e($libellesActions[$ligne['action']] ?? $ligne['action']) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </section>

</div>

<script src="../../../public/js/affectations.js?v=2"></script>
</body>
</html>

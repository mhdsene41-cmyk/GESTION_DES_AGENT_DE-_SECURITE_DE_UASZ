<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';

exigerAcces('rapports');
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Rapports et statistiques | Gestion Sécurité UASZ</title>

    <link rel="stylesheet" href="../../../public/css/rapports.css">
</head>

<body>

<div class="app-container">

    <!-- BARRE LATERALE -->
    <aside class="sidebar">

        <div class="sidebar-header">
            <h2>Gestion Sécurité</h2>
            <p>Université Assane Seck</p>
        </div>

        <nav class="sidebar-menu">

            <a href="../tableau_de_bord/tableau_de_bord.php">Tableau de bord</a>
            <a href="../utilisateurs/utilisateurs.php">Utilisateurs</a>
            <a href="../agents/agents.php">Agents</a>
            <a href="../recrutement/recrutement.php">Recrutement</a>
            <a href="../carrieres/carrieres.php">Carrières</a>
            <a href="../affectations/affectations.php">Affectations</a>
            <a href="../agents/presences.php">Présences</a>
            <a href="../agents/plannings.php">Plannings</a>
            <a href="../agents/incidents.php">Incidents</a>
            <a href="../demandes/demandes.php">Demandes</a>
            <a href="rapports.php" class="active">Rapports et statistiques</a>
            <a href="../profil/profil.php">Mon profil</a>
            <a href="../notifications/notifications.php">Notifications</a>

        </nav>

        <div class="sidebar-footer">
            <a href="../authentification/connexion.php">Déconnexion</a>
        </div>

    </aside>

    <!-- CONTENU PRINCIPAL -->
    <main class="main-content">

        <header class="topbar">
            <div>
                <h1>Rapports et statistiques</h1>
                <p>Analyse et suivi des activités du service de sécurité</p>
            </div>

            <div class="topbar-actions">
                <span class="admin-info">Administrateur</span>
                <button id="btnImprimer" class="btn-print">
                    Imprimer le rapport
                </button>
            </div>
        </header>

        <!-- PERIODE -->
        <section class="period-card">
            <div>
                <h2>Période d'analyse</h2>
                <p>Sélectionnez une période pour consulter les indicateurs.</p>
            </div>

            <div class="period-filters">
                <div>
                    <label for="dateDebut">Date de début</label>
                    <input type="date" id="dateDebut">
                </div>

                <div>
                    <label for="dateFin">Date de fin</label>
                    <input type="date" id="dateFin">
                </div>

                <button id="btnFiltrer" class="btn-primary">Appliquer</button>
                <button id="btnReinitialiser" class="btn-secondary">Réinitialiser</button>
            </div>
        </section>

        <!-- INDICATEURS -->
        <section class="stats-container">

            <div class="stat-card">
                <div class="stat-icon icon-blue">AG</div>
                <div>
                    <p>Total des agents</p>
                    <h2 id="statAgents">0</h2>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon icon-green">PR</div>
                <div>
                    <p>Présences</p>
                    <h2 id="statPresences">0</h2>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon icon-red">IN</div>
                <div>
                    <p>Incidents</p>
                    <h2 id="statIncidents">0</h2>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon icon-orange">DM</div>
                <div>
                    <p>Demandes</p>
                    <h2 id="statDemandes">0</h2>
                </div>
            </div>

        </section>

        <!-- GRAPHIQUES -->
        <section class="charts-grid">

            <div class="chart-card">
                <div class="chart-header">
                    <div>
                        <h2>État des présences</h2>
                        <p>Répartition des enregistrements</p>
                    </div>
                </div>

                <div class="chart-body">
                    <canvas id="graphiquePresences"></canvas>
                </div>

                <div id="legendePresences" class="chart-legend"></div>
            </div>

            <div class="chart-card">
                <div class="chart-header">
                    <div>
                        <h2>État des incidents</h2>
                        <p>Répartition par statut</p>
                    </div>
                </div>

                <div class="chart-body">
                    <canvas id="graphiqueIncidents"></canvas>
                </div>

                <div id="legendeIncidents" class="chart-legend"></div>
            </div>

        </section>

        <!-- REPARTITION DES DEMANDES -->
        <section class="chart-card">
            <div class="chart-header">
                <div>
                    <h2>Suivi des demandes</h2>
                    <p>Nombre de demandes selon leur état</p>
                </div>
            </div>

            <div class="bar-chart" id="graphiqueDemandes"></div>
        </section>

        <!-- TABLEAU RECAPITULATIF -->
        <section class="content-card">

            <div class="section-header">
                <div>
                    <h2>Rapport récapitulatif</h2>
                    <p>Synthèse des activités enregistrées pendant la période.</p>
                </div>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Indicateur</th>
                            <th>Nombre</th>
                            <th>Observations</th>
                        </tr>
                    </thead>

                    <tbody id="tableauRapport"></tbody>
                </table>
            </div>

        </section>

        <footer class="page-footer">
            <p>Gestion Sécurité UASZ — Rapport généré le <span id="dateGeneration"></span></p>
        </footer>

    </main>

</div>

<script src="../../../public/js/rapports.js"></script>

</body>
</html>

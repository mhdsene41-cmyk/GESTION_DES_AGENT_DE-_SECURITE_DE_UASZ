
<?php

session_start();

require_once __DIR__ . '/../../../configuration/connexion_bd.php';

$message_erreur = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $identifiant = trim($_POST["identifiant"] ?? "");
    $mot_de_passe = $_POST["mot_de_passe"] ?? "";

    if ($identifiant === "" || $mot_de_passe === "") {

        $message_erreur = "Veuillez remplir tous les champs.";

    } else {

        $requete = $connexion->prepare("
            SELECT id, nom, prenom, identifiant,
                   mot_de_passe, role, statut
            FROM utilisateurs
            WHERE identifiant = ?
            LIMIT 1
        ");

        $requete->execute([$identifiant]);

        $utilisateur = $requete->fetch();

        if (
            $utilisateur &&
            password_verify($mot_de_passe, $utilisateur["mot_de_passe"])
        ) {

            if ($utilisateur["statut"] === "en_attente") {

                $message_erreur = "Votre demande d'inscription est en attente de validation par l'administrateur.";

            } elseif ($utilisateur["statut"] === "refuse") {

                $message_erreur = "Votre demande d'inscription a été refusée. Veuillez contacter l'administrateur.";

            } elseif ($utilisateur["statut"] === "inactif") {

                $message_erreur = "Votre compte est désactivé. Veuillez contacter l'administrateur.";

            } elseif ($utilisateur["statut"] === "actif") {

                session_regenerate_id(true);

                $_SESSION["utilisateur_id"] = $utilisateur["id"];
                $_SESSION["nom"] = $utilisateur["nom"];
                $_SESSION["prenom"] = $utilisateur["prenom"];
                $_SESSION["identifiant"] = $utilisateur["identifiant"];
                $_SESSION["role"] = $utilisateur["role"];

                header("Location: ../tableau_de_bord/tableau_de_bord.php");
                exit;

            } else {

                $message_erreur = "Votre compte ne peut pas être utilisé actuellement.";
            }

        } else {

            $message_erreur = "Identifiant ou mot de passe incorrect.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Connexion | Gestion Sécurité UASZ</title>

    <link rel="stylesheet" href="../../../public/css/connexion.css">
</head>

<body>

    <main class="page-connexion">

        <!-- Partie gauche : présentation -->
        <section class="presentation">

            <div class="contenu-presentation">
                <h1>Gestion Sécurité UASZ</h1>
            </div>

            <div class="description-bas">
                <p>
                    Une plateforme dédiée à la gestion et au suivi
                    des activités du service de sécurité universitaire.
                </p>
            </div>

        </section>

        <!-- Partie droite : formulaire -->
        <section class="zone-connexion">

            <div class="carte-connexion">

                <h2>Bienvenue !</h2>

                <p class="sous-titre">
                    Connectez-vous à votre espace personnel.
                </p>

                <!-- Message d'erreur -->
                <?php if (!empty($message_erreur)): ?>
                    <div class="message-erreur">
                        <?= htmlspecialchars($message_erreur, ENT_QUOTES, 'UTF-8') ?>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">

                    <!-- Identifiant -->
                    <div class="champ">

                        <label for="identifiant">
                            Identifiant
                        </label>

                        <input
                            type="text"
                            id="identifiant"
                            name="identifiant"
                            placeholder="Entrez votre identifiant"
                            autocomplete="username"
                            required
                        >

                    </div>

                    <!-- Mot de passe -->
                    <div class="champ">

                        <label for="mot_de_passe">
                            Mot de passe
                        </label>

                        <div class="champ-mot-de-passe">

                            <input
                                type="password"
                                id="mot_de_passe"
                                name="mot_de_passe"
                                placeholder="Entrez votre mot de passe"
                                autocomplete="current-password"
                                required
                            >

                            <button
                                type="button"
                                id="afficherMotDePasse"
                                class="bouton-oeil"
                                aria-label="Afficher le mot de passe"
                                title="Afficher le mot de passe"
                                aria-pressed="false"
                            >

                                <svg
                                    id="iconeOeil"
                                    xmlns="http://www.w3.org/2000/svg"
                                    width="22"
                                    height="22"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                >
                                    <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                </svg>

                            </button>

                        </div>

                    </div>

                    <!-- Bouton de connexion -->
                    <button type="submit" class="bouton-connexion">
                        Se connecter
                    </button>

                </form>

                <!-- Zone de création de compte -->
                <div class="lien-inscription">

                    <span>Vous n'avez pas encore de compte ?</span></br>

                    <a href="inscription.php">
                        Créer un compte
                    </a>

                </div>

                <!-- Pied de page -->
                <p class="pied-connexion">
                    Université Assane Seck de Ziguinchor
                </p>

            </div>

        </section>

    </main>

    <script src="../../../public/js/connexion.js"></script>

</body>

</html>

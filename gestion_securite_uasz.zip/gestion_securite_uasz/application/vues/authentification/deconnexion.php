
<?php

// Démarrer la session
session_start();

// Vider toutes les données de session
$_SESSION = [];

// Supprimer le cookie de session
if (ini_get("session.use_cookies")) {

    $parametres = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $parametres["path"],
        $parametres["domain"],
        $parametres["secure"],
        $parametres["httponly"]
    );
}

// Détruire la session
session_destroy();

// Rediriger vers la page de connexion
header("Location: connexion.php");
exit;

?>

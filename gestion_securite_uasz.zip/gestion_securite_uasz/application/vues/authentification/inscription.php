
<?php
session_start();

require_once __DIR__ . '/../../../configuration/connexion_bd.php';

$message_erreur = "";

// Profils proposés lors de l'inscription
$rolesDisponibles = [
    'utilisateur' => 'Utilisateur',
    'chef_securite' => 'Chef de sécurité',
    'agent_securite' => 'Agent de sécurité',
    'enseignant' => 'Enseignant',
    'responsable_domaine' => 'Responsable de domaine'
];

// Création du jeton CSRF
if (empty($_SESSION['jeton_inscription'])) {
    $_SESSION['jeton_inscription'] = bin2hex(random_bytes(32));
}

// Vérifier si l'inscription vient d'être effectuée
$inscription_reussie = isset($_GET['inscription'])
    && $_GET['inscription'] === 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$inscription_reussie) {

    // Vérification du jeton CSRF
    $jeton = $_POST['jeton_csrf'] ?? '';

    if (
        empty($_SESSION['jeton_inscription']) ||
        !hash_equals($_SESSION['jeton_inscription'], $jeton)
    ) {
        $message_erreur = "La demande est invalide. Veuillez réessayer.";

    } else {

        $nom = trim($_POST['nom'] ?? '');
        $prenom = trim($_POST['prenom'] ?? '');
        $identifiant = trim($_POST['identifiant'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $role = trim($_POST['role'] ?? '');
        $mot_de_passe = $_POST['mot_de_passe'] ?? '';
        $confirmation = $_POST['confirmation'] ?? '';

        if (
            $nom === '' ||
            $prenom === '' ||
            $identifiant === '' ||
            $role === '' ||
            $mot_de_passe === '' ||
            $confirmation === ''
        ) {
            $message_erreur = "Veuillez remplir tous les champs obligatoires.";

        } elseif (!array_key_exists($role, $rolesDisponibles)) {
            $message_erreur = "Veuillez sélectionner un profil valide.";

        } elseif (strlen($mot_de_passe) < 8) {
            $message_erreur = "Le mot de passe doit contenir au moins 8 caractères.";

        } elseif ($mot_de_passe !== $confirmation) {
            $message_erreur = "Les deux mots de passe ne correspondent pas.";

        } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message_erreur = "Veuillez saisir une adresse e-mail valide.";

        } else {

            $transactionOuverte = false;

            try {
                $connexion->beginTransaction();
                $transactionOuverte = true;

                // Vérifier si l'identifiant existe déjà
                $verification = $connexion->prepare(
                    "SELECT id
                     FROM utilisateurs
                     WHERE identifiant = ?
                     LIMIT 1"
                );

                $verification->execute([$identifiant]);

                if ($verification->fetchColumn()) {
                    throw new RuntimeException("Cet identifiant est déjà utilisé.");
                }

                // Récupérer les administrateurs actifs
                $requeteAdmins = $connexion->prepare(
                    "SELECT id
                     FROM utilisateurs
                     WHERE role = 'administrateur'
                       AND statut = 'actif'"
                );

                $requeteAdmins->execute();
                $administrateurs = $requeteAdmins->fetchAll(PDO::FETCH_COLUMN);

                if (empty($administrateurs)) {
                    throw new RuntimeException(
                        "Aucun administrateur actif n'est disponible pour recevoir votre demande. Veuillez réessayer ultérieurement."
                    );
                }

                // Chiffrer le mot de passe
                $mot_de_passe_hash = password_hash(
                    $mot_de_passe,
                    PASSWORD_DEFAULT
                );

                // Créer le compte en attente de validation
                // Le rôle choisi est enregistré comme rôle demandé.
                // Aucun module n'est attribué automatiquement.
                $requete = $connexion->prepare(
                    "INSERT INTO utilisateurs
                    (nom, prenom, identifiant, mot_de_passe, role, statut, email, telephone)
                    VALUES (?, ?, ?, ?, ?, 'en_attente', ?, ?)"
                );

                $requete->execute([
                    $nom,
                    $prenom,
                    $identifiant,
                    $mot_de_passe_hash,
                    $role,
                    $email !== '' ? $email : null,
                    $telephone !== '' ? $telephone : null
                ]);

                $nouvelUtilisateurId = (int) $connexion->lastInsertId();

                // Préparer la notification destinée aux administrateurs
                $titreNotification = "Nouvelle demande de création de compte";

                $messageNotification =
                    "Une nouvelle demande de création de compte a été reçue.\n\n" .
                    "Nom : " . $prenom . " " . $nom . "\n" .
                    "Identifiant : " . $identifiant . "\n" .
                    "Profil demandé : " . $rolesDisponibles[$role] . "\n\n" .
                    "Veuillez examiner cette demande et décider de son acceptation ou de son refus.";

                $lienNotification = "../utilisateurs/utilisateurs.php";

                $requeteNotification = $connexion->prepare(
                    "INSERT INTO notifications
                    (utilisateur_id, titre, message, type, lien, est_lue)
                    VALUES (?, ?, ?, 'Système', ?, 0)"
                );

                // Envoyer une notification à chaque administrateur actif
                foreach ($administrateurs as $adminId) {
                    $requeteNotification->execute([
                        (int) $adminId,
                        $titreNotification,
                        $messageNotification,
                        $lienNotification
                    ]);
                }

                // Valider l'inscription et les notifications
                $connexion->commit();
                $transactionOuverte = false;

                // Renouveler le jeton de sécurité
                $_SESSION['jeton_inscription'] = bin2hex(random_bytes(32));

                header('Location: inscription.php?inscription=success');
                exit;

            } catch (RuntimeException $erreur) {

                if ($transactionOuverte && $connexion->inTransaction()) {
                    $connexion->rollBack();
                }

                $message_erreur = $erreur->getMessage();

            } catch (Throwable $erreur) {

                if ($transactionOuverte && $connexion->inTransaction()) {
                    $connexion->rollBack();
                }

                $message_erreur =
                    "Une erreur est survenue lors de l'inscription. Veuillez réessayer.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Inscription | Gestion Sécurité UASZ</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #eaf0f8;
            background-image:
                linear-gradient(
                    rgba(234, 240, 248, 0.45),
                    rgba(234, 240, 248, 0.45)
                ),
                url('../../../public/images/fond_securite_uasz.png');
            background-position: center, left center;
            background-size: cover, 430px auto;
            background-repeat: no-repeat;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 25px;
        }

        .conteneur {
            width: 100%;
            max-width: 520px;
            background: white;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.08);
        }

        .entete {
            text-align: center;
            margin-bottom: 25px;
        }

        .entete h1 {
            color: #142b4a;
            font-size: 25px;
            margin-bottom: 8px;
        }

        .entete p {
            color: #687386;
            font-size: 14px;
        }

        .champ {
            margin-bottom: 16px;
        }

        .champ label {
            display: block;
            margin-bottom: 7px;
            color: #26364a;
            font-weight: bold;
            font-size: 14px;
        }

        .champ input,
        .champ select {
            width: 100%;
            padding: 12px;
            border: 1px solid #d5dce5;
            border-radius: 7px;
            font-size: 15px;
            outline: none;
            background: #fff;
        }

        .champ input:focus,
        .champ select:focus {
            border-color: #c49a42;
            box-shadow: 0 0 0 2px rgba(196, 154, 66, 0.12);
        }

        .obligatoire {
            color: #c0392b;
        }

        .information-role {
            background: #f1f5fa;
            color: #52647b;
            padding: 11px;
            border-radius: 7px;
            font-size: 12px;
            line-height: 1.5;
            margin-top: -5px;
            margin-bottom: 16px;
        }

        .bouton {
            width: 100%;
            padding: 13px;
            background: #142b4a;
            color: white;
            border: none;
            border-radius: 7px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 8px;
        }

        .bouton:hover {
            background: #203e65;
        }

        .message {
            padding: 12px;
            border-radius: 7px;
            margin-bottom: 18px;
            font-size: 14px;
            line-height: 1.5;
        }

        .erreur {
            background: #fdecea;
            color: #a93226;
        }

        .succes {
            background: #e8f6ed;
            color: #216e39;
        }

        .retour {
            text-align: center;
            margin-top: 22px;
            font-size: 14px;
        }

        .retour a {
            color: #142b4a;
            font-weight: bold;
            text-decoration: none;
        }

        .retour a:hover {
            text-decoration: underline;
        }

        .note {
            color: #687386;
            font-size: 12px;
            margin-top: 12px;
            text-align: center;
        }

        @media (max-width: 550px) {
            body {
                padding: 15px;
            }

            .conteneur {
                padding: 25px 20px;
            }
        }
    </style>
</head>

<body>

<div class="conteneur">

    <div class="entete">
        <h1>Créer un compte</h1>
        <p>Gestion Sécurité UASZ</p>
    </div>

    <?php if ($inscription_reussie): ?>

        <div class="message succes">
            Votre demande d'inscription a été envoyée avec succès.

            Votre compte est en attente de validation par l'administrateur.

            Vous pourrez vous connecter après son acceptation.
        </div>

    <?php endif; ?>

    <?php if ($message_erreur !== ''): ?>

        <div class="message erreur">
            <?= htmlspecialchars($message_erreur, ENT_QUOTES, 'UTF-8') ?>
        </div>

    <?php endif; ?>

    <?php if (!$inscription_reussie): ?>

        <form method="POST" action="">

            <input
                type="hidden"
                name="jeton_csrf"
                value="<?= htmlspecialchars($_SESSION['jeton_inscription'], ENT_QUOTES, 'UTF-8') ?>"
            >

            <div class="champ">
                <label for="nom">
                    Nom <span class="obligatoire">*</span>
                </label>

                <input
                    type="text"
                    id="nom"
                    name="nom"
                    required
                    value="<?= htmlspecialchars($_POST['nom'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                >
            </div>

            <div class="champ">
                <label for="prenom">
                    Prénom <span class="obligatoire">*</span>
                </label>

                <input
                    type="text"
                    id="prenom"
                    name="prenom"
                    required
                    value="<?= htmlspecialchars($_POST['prenom'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                >
            </div>

            <div class="champ">
                <label for="identifiant">
                    Identifiant <span class="obligatoire">*</span>
                </label>

                <input
                    type="text"
                    id="identifiant"
                    name="identifiant"
                    required
                    value="<?= htmlspecialchars($_POST['identifiant'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                >
            </div>

            <div class="champ">
                <label for="email">Adresse e-mail</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                >
            </div>

            <div class="champ">
                <label for="telephone">Téléphone</label>

                <input
                    type="tel"
                    id="telephone"
                    name="telephone"
                    value="<?= htmlspecialchars($_POST['telephone'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                >
            </div>

            <div class="champ">
                <label for="role">
                    Profil souhaité <span class="obligatoire">*</span>
                </label>

                <select id="role" name="role" required>
                    <option value="">-- Choisir votre profil --</option>

                    <?php foreach ($rolesDisponibles as $code => $libelle): ?>
                        <option
                            value="<?= htmlspecialchars($code, ENT_QUOTES, 'UTF-8') ?>"
                            <?= (($_POST['role'] ?? '') === $code) ? 'selected' : '' ?>
                        >
                            <?= htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>

                </select>
            </div>

            <div class="information-role">
                ℹ️ Le profil sélectionné sera soumis à l'approbation de l'administrateur.
                Les accès à la plateforme seront définis par celui-ci après vérification.
            </div>

            <div class="champ">
                <label for="mot_de_passe">
                    Mot de passe <span class="obligatoire">*</span>
                </label>

                <input
                    type="password"
                    id="mot_de_passe"
                    name="mot_de_passe"
                    minlength="8"
                    required
                >
            </div>

            <div class="champ">
                <label for="confirmation">
                    Confirmer le mot de passe <span class="obligatoire">*</span>
                </label>

                <input
                    type="password"
                    id="confirmation"
                    name="confirmation"
                    minlength="8"
                    required
                >
            </div>

            <button type="submit" class="bouton">
                Envoyer ma demande
            </button>

            <p class="note">
                Les champs marqués d'un * sont obligatoires.
            </p>

        </form>

    <?php endif; ?>

    <div class="retour">
        Déjà inscrit ?
        <a href="connexion.php">Se connecter</a>
    </div>

</div>

</body>
</html>

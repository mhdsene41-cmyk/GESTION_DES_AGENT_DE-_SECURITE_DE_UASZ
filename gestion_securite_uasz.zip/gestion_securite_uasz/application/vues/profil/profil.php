
<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';

exigerAcces('profil');

if (empty($_SESSION['csrf_profil'])) {
    $_SESSION['csrf_profil'] = bin2hex(random_bytes(32));
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon profil | Gestion Sécurité UASZ</title>

    <link rel="stylesheet" href="../../../public/css/profil.css">
</head>

<body>

<div class="page-container">

    <aside class="sidebar">

        <div class="logo">
            <h2>UASZ</h2>
            <p>Gestion de la sécurité</p>
        </div>

        <nav class="menu">
            <a href="../tableau_de_bord/tableau_de_bord.php">Tableau de bord</a>
            <a href="../agents/agents.php">Agents</a>
            <a href="../agents/presences.php">Présences</a>
            <a href="../agents/plannings.php">Plannings</a>
            <a href="../agents/incidents.php">Incidents</a>
            <a href="../notifications/notifications.php">Notifications</a>
            <a href="../demandes/demandes.php">Demandes</a>
            <a href="../affectations/affectations.php">Affectations</a>
            <a href="../recrutement/recrutement.php">Recrutement</a>
            <a href="../carrieres/carrieres.php">Carrières</a>
            <a href="../rapports/rapports.php">Rapports</a>
            <a href="profil.php" class="active">Mon profil</a>
        </nav>

        <a href="../authentification/deconnexion.php" class="logout">
            Déconnexion
        </a>

    </aside>

    <main class="main-content">

        <header class="topbar">

            <div>
                <h1>Mon profil</h1>
                <p>Gérez vos informations personnelles et la sécurité de votre compte.</p>
            </div>

            <div class="user-info">
                <div class="avatar" id="avatarUtilisateur">?</div>
                <span id="nomUtilisateur">Chargement...</span>
            </div>

        </header>

        <!-- CARTE PRINCIPALE DU PROFIL -->

        <section class="profile-card">

            <div class="profile-header">

                <div class="profile-avatar" id="grandAvatar">?</div>

                <div>
                    <h2 id="nomAffiche">Chargement...</h2>
                    <p id="roleAffiche">Chargement...</p>
                </div>

            </div>

            <div class="profile-form-container">

                <h3>Informations personnelles</h3>

                <form id="formProfil">

                    <input type="hidden" id="csrfProfil"
                           value="<?= htmlspecialchars($_SESSION['csrf_profil'], ENT_QUOTES, 'UTF-8') ?>">

                    <div class="form-grid">

                        <div class="form-group">
                            <label for="nom">Nom</label>
                            <input type="text" id="nom" name="nom"
                                   maxlength="100" required>
                        </div>

                        <div class="form-group">
                            <label for="prenom">Prénom</label>
                            <input type="text" id="prenom" name="prenom"
                                   maxlength="100" required>
                        </div>

                        <div class="form-group">
                            <label for="identifiant">Identifiant</label>
                            <input type="text" id="identifiant" readonly>
                        </div>

                        <div class="form-group">
                            <label for="email">Adresse e-mail</label>
                            <input type="email" id="email" name="email"
                                   maxlength="150" placeholder="Exemple : nom@exemple.com">
                        </div>

                        <div class="form-group">
                            <label for="telephone">Téléphone</label>
                            <input type="tel" id="telephone" name="telephone"
                                   maxlength="30" placeholder="Votre numéro de téléphone">
                        </div>

                        <div class="form-group">
                            <label for="role">Rôle</label>
                            <input type="text" id="role" readonly>
                        </div>

                        <div class="form-group">
                            <label for="statut">Statut du compte</label>
                            <input type="text" id="statut" readonly>
                        </div>

                    </div>

                    <button type="submit" class="btn-primary">
                        Enregistrer les modifications
                    </button>

                    <p id="messageProfil" class="message" role="status"></p>

                </form>

                <div class="separator"></div>

                <h3>Modifier le mot de passe</h3>

                <form id="formMotDePasse">

                    <div class="form-grid">

                        <div class="form-group">
                            <label for="ancienMotDePasse">Ancien mot de passe</label>
                            <input type="password" id="ancienMotDePasse"
                                   required autocomplete="current-password">
                        </div>

                        <div class="form-group">
                            <label for="nouveauMotDePasse">Nouveau mot de passe</label>
                            <input type="password" id="nouveauMotDePasse"
                                   minlength="8" required autocomplete="new-password">
                        </div>

                        <div class="form-group">
                            <label for="confirmationMotDePasse">
                                Confirmer le nouveau mot de passe
                            </label>
                            <input type="password" id="confirmationMotDePasse"
                                   minlength="8" required autocomplete="new-password">
                        </div>

                    </div>

                    <button type="submit" class="btn-secondary">
                        Modifier le mot de passe
                    </button>

                    <p id="messageMotDePasse" class="message" role="status"></p>

                </form>

            </div>

        </section>

        <footer>
            © <?= date('Y') ?> Université Assane Seck de Ziguinchor -
            Gestion Sécurité UASZ
        </footer>

    </main>

</div>

<script src="../../../public/js/profil.js"></script>

</body>
</html>

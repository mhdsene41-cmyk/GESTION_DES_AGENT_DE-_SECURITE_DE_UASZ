
<?php

session_start();

require_once __DIR__ . '/../../outils/verifier_acces.php';

exigerAcces('utilisateurs');

// Réserver la gestion des comptes à l'administrateur
if (($_SESSION['role'] ?? '') !== 'administrateur') {
    http_response_code(403);
    exit("Accès réservé à l'administrateur.");
}

function e($valeur): string
{
    return htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
}

// Rôles autorisés
$rolesDisponibles = [
    'utilisateur' => 'Utilisateur',
    'chef_securite' => 'Chef de sécurité',
    'agent_securite' => 'Agent de sécurité',
    'enseignant' => 'Enseignant',
    'responsable_domaine' => 'Responsable de domaine'
];

// Protection CSRF
if (empty($_SESSION['jeton_csrf'])) {
    $_SESSION['jeton_csrf'] = bin2hex(random_bytes(32));
}

$message = "";
$type_message = "succes";

// Charger les modules disponibles
$requeteModules = $connexion->query("
    SELECT id, nom, code, description
    FROM modules
    ORDER BY nom
");

$modules = $requeteModules->fetchAll(PDO::FETCH_ASSOC);

// Récupérer l'identifiant du tableau de bord
$requeteDashboard = $connexion->prepare("
    SELECT id
    FROM modules
    WHERE code = ?
    LIMIT 1
");

$requeteDashboard->execute(['tableau_de_bord']);
$idDashboard = (int) $requeteDashboard->fetchColumn();

// Normaliser et vérifier les modules sélectionnés
$normaliserModules = function ($selection) use ($modules, $idDashboard) {

    if (!is_array($selection)) {
        $selection = [];
    }

    $modulesAutorises = array_map(
        'intval',
        array_column($modules, 'id')
    );

    $selection = array_unique(
        array_filter(
            array_map('intval', $selection),
            function ($id) use ($modulesAutorises) {
                return $id > 0 && in_array($id, $modulesAutorises, true);
            }
        )
    );

    // Tableau de bord attribué automatiquement
    if ($idDashboard > 0) {
        $selection[] = $idDashboard;
    }

    return array_values(array_unique($selection));
};

try {

    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        $jeton = $_POST["jeton_csrf"] ?? "";

        if (!hash_equals($_SESSION['jeton_csrf'], $jeton)) {
            throw new Exception("Votre session a expiré. Rechargez la page.");
        }

        $action = $_POST["action"] ?? "";

        /*
        ==========================================
        CRÉATION D'UN UTILISATEUR
        ==========================================
        */

        if ($action === "creer") {

            $nom = trim($_POST["nom"] ?? "");
            $prenom = trim($_POST["prenom"] ?? "");
            $identifiant = trim($_POST["identifiant"] ?? "");
            $motDePasse = $_POST["mot_de_passe"] ?? "";
            $role = $_POST["role"] ?? "utilisateur";
            $modulesSelectionnes = $normaliserModules($_POST["modules"] ?? []);

            if (
                $nom === "" ||
                $prenom === "" ||
                $identifiant === "" ||
                $motDePasse === ""
            ) {
                throw new Exception("Veuillez remplir tous les champs obligatoires.");
            }

            if (!array_key_exists($role, $rolesDisponibles)) {
                throw new Exception("Le profil sélectionné est invalide.");
            }

            if (strlen($motDePasse) < 8) {
                throw new Exception("Le mot de passe doit contenir au moins 8 caractères.");
            }

            $connexion->beginTransaction();

            $requete = $connexion->prepare("
                INSERT INTO utilisateurs
                (nom, prenom, identifiant, mot_de_passe, role, statut)
                VALUES (?, ?, ?, ?, ?, 'actif')
            ");

            $requete->execute([
                $nom,
                $prenom,
                $identifiant,
                password_hash($motDePasse, PASSWORD_DEFAULT),
                $role
            ]);

            $nouvelUtilisateurId = (int) $connexion->lastInsertId();

            $requetePermission = $connexion->prepare("
                INSERT INTO utilisateur_modules
                (utilisateur_id, module_id)
                VALUES (?, ?)
            ");

            foreach ($modulesSelectionnes as $moduleId) {
                $requetePermission->execute([
                    $nouvelUtilisateurId,
                    $moduleId
                ]);
            }

            $connexion->commit();

            header("Location: utilisateurs.php?message=cree");
            exit;
        }

        /*
        ==========================================
        VALIDATION D'UNE DEMANDE D'INSCRIPTION
        ==========================================
        */

        elseif ($action === "valider_demande") {

            $id = (int) ($_POST["id"] ?? 0);
            $role = $_POST["role"] ?? "";
            $modulesSelectionnes = $normaliserModules($_POST["modules"] ?? []);

            if ($id <= 0) {
                throw new Exception("Demande d'inscription invalide.");
            }

            if (!array_key_exists($role, $rolesDisponibles)) {
                throw new Exception("Le profil définitif sélectionné est invalide.");
            }

            $connexion->beginTransaction();

            // Vérifier que le compte est toujours en attente
            $verification = $connexion->prepare("
                SELECT id, nom, prenom
                FROM utilisateurs
                WHERE id = ?
                  AND statut = 'en_attente'
                LIMIT 1
            ");

            $verification->execute([$id]);
            $demande = $verification->fetch(PDO::FETCH_ASSOC);

            if (!$demande) {
                throw new Exception("Cette demande n'existe plus ou a déjà été traitée.");
            }

            // Attribuer le rôle définitif et activer le compte
            $requeteActivation = $connexion->prepare("
                UPDATE utilisateurs
                SET role = ?, statut = 'actif'
                WHERE id = ?
                  AND statut = 'en_attente'
            ");

            $requeteActivation->execute([$role, $id]);

            // Supprimer d'éventuelles anciennes permissions
            $suppressionPermissions = $connexion->prepare("
                DELETE FROM utilisateur_modules
                WHERE utilisateur_id = ?
            ");

            $suppressionPermissions->execute([$id]);

            // Attribuer les modules autorisés
            $ajoutPermission = $connexion->prepare("
                INSERT INTO utilisateur_modules
                (utilisateur_id, module_id)
                VALUES (?, ?)
            ");

            foreach ($modulesSelectionnes as $moduleId) {
                $ajoutPermission->execute([$id, $moduleId]);
            }

            // Informer le nouvel utilisateur
            $notification = $connexion->prepare("
                INSERT INTO notifications
                (utilisateur_id, titre, message, type, lien, est_lue)
                VALUES (?, ?, ?, 'Système', ?, 0)
            ");

            $notification->execute([
                $id,
                "Votre compte a été accepté",
                "Bonne nouvelle ! Votre demande de création de compte a été acceptée par l'administrateur. Vous pouvez maintenant vous connecter à la plateforme.",
                "../authentification/connexion.php"
            ]);

            $connexion->commit();

            header("Location: utilisateurs.php?message=demande_acceptee");
            exit;
        }

        /*
        ==========================================
        REFUS D'UNE DEMANDE D'INSCRIPTION
        ==========================================
        */

        elseif ($action === "refuser_demande") {

            $id = (int) ($_POST["id"] ?? 0);

            if ($id <= 0) {
                throw new Exception("Demande d'inscription invalide.");
            }

            $connexion->beginTransaction();

            // Vérifier que le compte est toujours en attente
            $verification = $connexion->prepare("
                SELECT id
                FROM utilisateurs
                WHERE id = ?
                  AND statut = 'en_attente'
                LIMIT 1
            ");

            $verification->execute([$id]);

            if (!$verification->fetchColumn()) {
                throw new Exception("Cette demande n'existe plus ou a déjà été traitée.");
            }

            // Refuser la demande
            $requeteRefus = $connexion->prepare("
                UPDATE utilisateurs
                SET statut = 'refuse'
                WHERE id = ?
            ");

            $requeteRefus->execute([$id]);

            // S'assurer qu'aucun module ne soit attribué
            $suppressionPermissions = $connexion->prepare("
                DELETE FROM utilisateur_modules
                WHERE utilisateur_id = ?
            ");

            $suppressionPermissions->execute([$id]);

            // Informer le demandeur
            $notification = $connexion->prepare("
                INSERT INTO notifications
                (utilisateur_id, titre, message, type, lien, est_lue)
                VALUES (?, ?, ?, 'Système', ?, 0)
            ");

            $notification->execute([
                $id,
                "Demande de compte refusée",
                "Votre demande de création de compte n'a malheureusement pas été acceptée par l'administrateur. Pour plus d'informations, veuillez contacter l'administration.",
                "../authentification/connexion.php"
            ]);

            $connexion->commit();

            header("Location: utilisateurs.php?message=demande_refusee");
            exit;
        }

        /*
        ==========================================
        MODIFICATION D'UN UTILISATEUR
        ==========================================
        */

        elseif ($action === "modifier") {

            $id = (int) ($_POST["id"] ?? 0);
            $nom = trim($_POST["nom"] ?? "");
            $prenom = trim($_POST["prenom"] ?? "");
            $identifiant = trim($_POST["identifiant"] ?? "");
            $motDePasse = $_POST["mot_de_passe"] ?? "";
            $role = $_POST["role"] ?? "";
            $modulesSelectionnes = $normaliserModules($_POST["modules"] ?? []);

            if (
                $id <= 0 ||
                $nom === "" ||
                $prenom === "" ||
                $identifiant === ""
            ) {
                throw new Exception("Informations de modification invalides.");
            }

            if (!array_key_exists($role, $rolesDisponibles)) {
                throw new Exception("Le profil sélectionné est invalide.");
            }

            if ($id === (int) $_SESSION["utilisateur_id"]) {
                throw new Exception("Vous ne pouvez pas modifier votre propre compte depuis cette page.");
            }

            if ($motDePasse !== "" && strlen($motDePasse) < 8) {
                throw new Exception("Le nouveau mot de passe doit contenir au moins 8 caractères.");
            }

            $connexion->beginTransaction();

            if ($motDePasse !== "") {

                $requete = $connexion->prepare("
                    UPDATE utilisateurs
                    SET nom = ?, prenom = ?, identifiant = ?,
                        mot_de_passe = ?, role = ?
                    WHERE id = ?
                ");

                $requete->execute([
                    $nom,
                    $prenom,
                    $identifiant,
                    password_hash($motDePasse, PASSWORD_DEFAULT),
                    $role,
                    $id
                ]);

            } else {

                $requete = $connexion->prepare("
                    UPDATE utilisateurs
                    SET nom = ?, prenom = ?, identifiant = ?, role = ?
                    WHERE id = ?
                ");

                $requete->execute([
                    $nom,
                    $prenom,
                    $identifiant,
                    $role,
                    $id
                ]);
            }

            // Remplacer les anciennes autorisations
            $suppression = $connexion->prepare("
                DELETE FROM utilisateur_modules
                WHERE utilisateur_id = ?
            ");

            $suppression->execute([$id]);

            $ajoutPermission = $connexion->prepare("
                INSERT INTO utilisateur_modules
                (utilisateur_id, module_id)
                VALUES (?, ?)
            ");

            foreach ($modulesSelectionnes as $moduleId) {
                $ajoutPermission->execute([$id, $moduleId]);
            }

            $connexion->commit();

            header("Location: utilisateurs.php?message=modifie");
            exit;
        }

        /*
        ==========================================
        ACTIVATION / DESACTIVATION
        ==========================================
        */

        elseif ($action === "statut") {

            $id = (int) ($_POST["id"] ?? 0);
            $nouveauStatut = $_POST["statut"] ?? "";

            if (
                $id <= 0 ||
                !in_array($nouveauStatut, ['actif', 'inactif'], true)
            ) {
                throw new Exception("Action de statut invalide.");
            }

            if ($id === (int) $_SESSION["utilisateur_id"]) {
                throw new Exception("Vous ne pouvez pas désactiver votre propre compte.");
            }

            // Ne pas permettre de contourner la validation d'inscription
            $verification = $connexion->prepare("
                SELECT statut
                FROM utilisateurs
                WHERE id = ?
                LIMIT 1
            ");

            $verification->execute([$id]);
            $statutActuel = $verification->fetchColumn();

            if (!in_array($statutActuel, ['actif', 'inactif'], true)) {
                throw new Exception("Cette demande doit d'abord être traitée dans la section des inscriptions en attente.");
            }

            $requete = $connexion->prepare("
                UPDATE utilisateurs
                SET statut = ?
                WHERE id = ?
            ");

            $requete->execute([$nouveauStatut, $id]);

            header("Location: utilisateurs.php?message=statut");
            exit;
        }

        /*
        ==========================================
        SUPPRESSION D'UN UTILISATEUR
        ==========================================
        */

        elseif ($action === "supprimer") {

            $id = (int) ($_POST["id"] ?? 0);

            if ($id <= 0) {
                throw new Exception("Utilisateur invalide.");
            }

            if ($id === (int) $_SESSION["utilisateur_id"]) {
                throw new Exception("Vous ne pouvez pas supprimer votre propre compte.");
            }

            $connexion->beginTransaction();

            $verification = $connexion->prepare("
                SELECT id
                FROM utilisateurs
                WHERE id = ?
                LIMIT 1
            ");

            $verification->execute([$id]);

            if (!$verification->fetchColumn()) {
                throw new Exception("Cet utilisateur n'existe plus.");
            }

            $requetePermissions = $connexion->prepare("
                DELETE FROM utilisateur_modules
                WHERE utilisateur_id = ?
            ");

            $requetePermissions->execute([$id]);

            $requeteSuppression = $connexion->prepare("
                DELETE FROM utilisateurs
                WHERE id = ?
            ");

            $requeteSuppression->execute([$id]);

            if ($requeteSuppression->rowCount() === 0) {
                throw new Exception("La suppression du compte a échoué.");
            }

            $connexion->commit();

            header("Location: utilisateurs.php?message=supprime");
            exit;
        }

        else {
            throw new Exception("Action inconnue.");
        }
    }

} catch (PDOException $erreur) {

    if ($connexion->inTransaction()) {
        $connexion->rollBack();
    }

    if ($erreur->getCode() === '23000') {
        $message = "Impossible de terminer cette opération : cet identifiant est déjà utilisé ou ce compte est lié à d'autres données.";
    } else {
        $message = "Une erreur est survenue lors de l'opération.";
    }

    $type_message = "erreur";

} catch (Throwable $erreur) {

    if ($connexion->inTransaction()) {
        $connexion->rollBack();
    }

    $message = $erreur->getMessage();
    $type_message = "erreur";
}

// Messages après redirection
if (isset($_GET["message"])) {

    $messages = [
        "cree" => "Le compte utilisateur a été créé avec succès.",
        "modifie" => "Les informations et autorisations ont été mises à jour.",
        "statut" => "Le statut du compte a été modifié.",
        "supprime" => "Le compte utilisateur a été supprimé avec succès.",
        "demande_acceptee" => "La demande a été acceptée. Le compte est maintenant actif.",
        "demande_refusee" => "La demande d'inscription a été refusée."
    ];

    if (isset($messages[$_GET["message"]])) {
        $message = $messages[$_GET["message"]];
        $type_message = "succes";
    }
}

/*
==========================================
UTILISATEURS À MODIFIER
==========================================
*/

$utilisateurAModifier = null;
$modulesUtilisateur = [];

if (isset($_GET["modifier"])) {

    $idModification = (int) $_GET["modifier"];

    $requete = $connexion->prepare("
        SELECT id, nom, prenom, identifiant, role, statut
        FROM utilisateurs
        WHERE id = ?
          AND statut IN ('actif', 'inactif')
        LIMIT 1
    ");

    $requete->execute([$idModification]);
    $utilisateurAModifier = $requete->fetch(PDO::FETCH_ASSOC);

    if ($utilisateurAModifier) {

        $requetePermissions = $connexion->prepare("
            SELECT module_id
            FROM utilisateur_modules
            WHERE utilisateur_id = ?
        ");

        $requetePermissions->execute([$idModification]);

        $modulesUtilisateur = array_map(
            'intval',
            $requetePermissions->fetchAll(PDO::FETCH_COLUMN)
        );
    }
}

/*
==========================================
DEMANDES D'INSCRIPTION EN ATTENTE
==========================================
*/

$requeteDemandes = $connexion->query("
    SELECT
        id,
        nom,
        prenom,
        identifiant,
        email,
        telephone,
        role,
        date_creation
    FROM utilisateurs
    WHERE statut = 'en_attente'
    ORDER BY date_creation ASC
");

$demandesEnAttente = $requeteDemandes->fetchAll(PDO::FETCH_ASSOC);

/*
==========================================
LISTE DES UTILISATEURS
==========================================
*/

$requeteUtilisateurs = $connexion->query("
    SELECT
        u.id,
        u.nom,
        u.prenom,
        u.identifiant,
        u.role,
        u.statut,
        u.date_creation,
        COUNT(um.module_id) AS nombre_modules
    FROM utilisateurs u
    LEFT JOIN utilisateur_modules um
        ON um.utilisateur_id = u.id
    WHERE u.statut IN ('actif', 'inactif')
    GROUP BY
        u.id,
        u.nom,
        u.prenom,
        u.identifiant,
        u.role,
        u.statut,
        u.date_creation
    ORDER BY u.id DESC
");

$utilisateurs = $requeteUtilisateurs->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Gestion des utilisateurs | Gestion Sécurité UASZ</title>

    <link rel="stylesheet" href="../../../public/css/utilisateurs.css">

    <style>
        .section-demandes {
            margin-bottom: 30px;
            padding: 25px;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 18px rgba(20, 43, 74, 0.07);
        }

        .entete-demandes {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .entete-demandes h2 {
            color: #142b4a;
            margin-bottom: 6px;
        }

        .entete-demandes p {
            color: #687386;
            font-size: 14px;
        }

        .compteur-demandes {
            background: #fff3dc;
            color: #9a6410;
            padding: 8px 13px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 13px;
        }

        .demande-carte {
            border: 1px solid #e1e7ef;
            border-left: 4px solid #c49a42;
            border-radius: 9px;
            padding: 20px;
            margin-bottom: 17px;
        }

        .demande-identite {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 15px;
        }

        .demande-identite h3 {
            color: #142b4a;
            margin-bottom: 6px;
        }

        .demande-identite p,
        .demande-infos p {
            color: #687386;
            font-size: 13px;
            margin: 5px 0;
        }

        .badge-attente {
            display: inline-block;
            padding: 6px 11px;
            background: #fff3dc;
            color: #94620e;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .demande-infos {
            display: flex;
            flex-wrap: wrap;
            gap: 10px 25px;
            margin-bottom: 17px;
        }

        .demande-formulaire {
            border-top: 1px solid #e8edf3;
            padding-top: 17px;
        }

        .demande-formulaire h4 {
            color: #142b4a;
            margin-bottom: 12px;
        }

        .demande-formulaire select {
            width: 100%;
            max-width: 350px;
            padding: 10px;
            border: 1px solid #d5dce5;
            border-radius: 7px;
            margin-bottom: 15px;
            background: white;
        }

        .demande-modules {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 10px;
            margin-bottom: 17px;
        }

        .demande-module {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 9px;
            background: #f5f7fa;
            border-radius: 6px;
            color: #26364a;
            font-size: 13px;
        }

        .demande-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn-accepter-demande,
        .btn-refuser-demande {
            border: none;
            border-radius: 6px;
            padding: 10px 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .btn-accepter-demande {
            background: #198754;
            color: white;
        }

        .btn-accepter-demande:hover {
            background: #146c43;
        }

        .btn-refuser-demande {
            background: #fdecea;
            color: #b02a37;
        }

        .btn-refuser-demande:hover {
            background: #f8d7da;
        }

        .aucune-demande {
            padding: 22px;
            text-align: center;
            color: #687386;
            background: #f5f7fa;
            border-radius: 8px;
        }

        .note-validation {
            color: #687386;
            font-size: 12px;
            margin: 8px 0 15px;
        }
    </style>
</head>

<body>

<div class="page-utilisateurs">

    <header class="entete-page">

        <div>
            <p class="sur-titre">ADMINISTRATION</p>
            <h1>Gestion des utilisateurs</h1>
            <p class="description">
                Créez les comptes et gérez les autorisations d'accès aux modules.
            </p>
        </div>

        <a href="../tableau_de_bord/tableau_de_bord.php" class="lien-retour">
            ← Tableau de bord
        </a>

    </header>

    <?php if ($message !== ""): ?>
        <div class="message <?= e($type_message) ?>">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <!-- STATISTIQUES -->

    <section class="statistiques">

        <div class="carte-statistique">
            <span>Total utilisateurs</span>
            <strong><?= count($utilisateurs) + count($demandesEnAttente) ?></strong>
        </div>

        <div class="carte-statistique">
            <span>Comptes actifs</span>
            <strong>
                <?= count(array_filter($utilisateurs, fn($u) => $u["statut"] === "actif")) ?>
            </strong>
        </div>

        <div class="carte-statistique">
            <span>Comptes inactifs</span>
            <strong>
                <?= count(array_filter($utilisateurs, fn($u) => $u["statut"] === "inactif")) ?>
            </strong>
        </div>

        <div class="carte-statistique">
            <span>Demandes en attente</span>
            <strong><?= count($demandesEnAttente) ?></strong>
        </div>

    </section>

    <!-- DEMANDES D'INSCRIPTION -->

    <section class="section-demandes">

        <div class="entete-demandes">

            <div>
                <h2>Demandes de création de compte</h2>
                <p>
                    Examinez les demandes et attribuez les autorisations avant activation.
                </p>
            </div>

            <span class="compteur-demandes">
                <?= count($demandesEnAttente) ?> demande(s) en attente
            </span>

        </div>

        <?php if (empty($demandesEnAttente)): ?>

            <div class="aucune-demande">
                <strong>✓ Aucune demande en attente</strong>
                <p>Les nouvelles demandes d'inscription apparaîtront ici.</p>
            </div>

        <?php else: ?>

            <?php foreach ($demandesEnAttente as $demande): ?>

                <article class="demande-carte">

                    <div class="demande-identite">

                        <div>
                            <h3>
                                <?= e($demande['prenom'] . ' ' . $demande['nom']) ?>
                            </h3>

                            <p>
                                Identifiant : <strong><?= e($demande['identifiant']) ?></strong>
                            </p>
                        </div>

                        <span class="badge-attente">
                            En attente de validation
                        </span>

                    </div>

                    <div class="demande-infos">

                        <p>
                            <strong>Profil demandé :</strong>
                            <?= e($rolesDisponibles[$demande['role']] ?? $demande['role']) ?>
                        </p>

                        <p>
                            <strong>E-mail :</strong>
                            <?= e($demande['email'] ?: 'Non renseigné') ?>
                        </p>

                        <p>
                            <strong>Téléphone :</strong>
                            <?= e($demande['telephone'] ?: 'Non renseigné') ?>
                        </p>

                        <p>
                            <strong>Date de demande :</strong>
                            <?= e(date('d/m/Y à H:i', strtotime($demande['date_creation']))) ?>
                        </p>

                    </div>

                    <!-- FORMULAIRE D'ACCEPTATION ET D'ATTRIBUTION DES MODULES -->

                    <form
                        method="POST"
                        action="utilisateurs.php"
                        class="demande-formulaire"
                        onsubmit="return confirm('Confirmer l’acceptation de cette demande et l’activation du compte ?');"
                    >

                        <input
                            type="hidden"
                            name="jeton_csrf"
                            value="<?= e($_SESSION['jeton_csrf']) ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="valider_demande"
                        >

                        <input
                            type="hidden"
                            name="id"
                            value="<?= (int) $demande['id'] ?>"
                        >

                        <h4>1. Choisir le profil définitif</h4>

                        <select name="role" required>

                            <?php foreach ($rolesDisponibles as $valeur => $libelle): ?>

                                <option
                                    value="<?= e($valeur) ?>"
                                    <?= $demande['role'] === $valeur ? 'selected' : '' ?>
                                >
                                    <?= e($libelle) ?>
                                    <?= $demande['role'] === $valeur ? '(profil demandé)' : '' ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                        <h4>2. Attribuer les modules autorisés</h4>

                        <p class="note-validation">
                            Le tableau de bord est attribué automatiquement.
                            Cochez uniquement les modules que cette personne pourra utiliser.
                        </p>

                        <div class="demande-modules">

                            <?php foreach ($modules as $module): ?>

                                <?php $estDashboard = $module['code'] === 'tableau_de_bord'; ?>

                                <label class="demande-module">

                                    <input
                                        type="checkbox"
                                        name="modules[]"
                                        value="<?= (int) $module['id'] ?>"
                                        <?= $estDashboard ? 'checked disabled' : '' ?>
                                    >

                                    <?php if ($estDashboard): ?>
                                        <input
                                            type="hidden"
                                            name="modules[]"
                                            value="<?= (int) $module['id'] ?>"
                                        >
                                    <?php endif; ?>

                                    <span>
                                        <?= e($module['nom']) ?>
                                        <?= $estDashboard ? '(automatique)' : '' ?>
                                    </span>

                                </label>

                            <?php endforeach; ?>

                        </div>

                        <div class="demande-actions">

                            <button
                                type="submit"
                                class="btn-accepter-demande"
                            >
                                ✓ Accepter et activer le compte
                            </button>

                        </div>

                    </form>

                    <!-- FORMULAIRE DE REFUS -->

                    <form
                        method="POST"
                        action="utilisateurs.php"
                        style="margin-top: 12px;"
                        onsubmit="return confirm('Voulez-vous vraiment refuser cette demande ?');"
                    >

                        <input
                            type="hidden"
                            name="jeton_csrf"
                            value="<?= e($_SESSION['jeton_csrf']) ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="refuser_demande"
                        >

                        <input
                            type="hidden"
                            name="id"
                            value="<?= (int) $demande['id'] ?>"
                        >

                        <button
                            type="submit"
                            class="btn-refuser-demande"
                        >
                            ✕ Refuser la demande
                        </button>

                    </form>

                </article>

            <?php endforeach; ?>

        <?php endif; ?>

    </section>

    <!-- FORMULAIRE DE CRÉATION / MODIFICATION -->

    <section class="bloc-formulaire">

        <div class="titre-section">
            <div>
                <h2>
                    <?= $utilisateurAModifier ? "Modifier un utilisateur" : "Créer un utilisateur" ?>
                </h2>

                <p>
                    <?= $utilisateurAModifier
                        ? "Modifiez les informations, le profil et les modules autorisés."
                        : "Renseignez les informations du nouvel utilisateur." ?>
                </p>
            </div>
        </div>

        <form method="POST" action="utilisateurs.php" id="formulaireUtilisateur">

            <input
                type="hidden"
                name="jeton_csrf"
                value="<?= e($_SESSION['jeton_csrf']) ?>"
            >

            <input
                type="hidden"
                name="action"
                value="<?= $utilisateurAModifier ? 'modifier' : 'creer' ?>"
            >

            <?php if ($utilisateurAModifier): ?>
                <input
                    type="hidden"
                    name="id"
                    value="<?= (int) $utilisateurAModifier['id'] ?>"
                >
            <?php endif; ?>

            <div class="grille-champs">

                <div class="champ">
                    <label for="nom">Nom</label>
                    <input
                        type="text"
                        id="nom"
                        name="nom"
                        value="<?= e($utilisateurAModifier['nom'] ?? '') ?>"
                        placeholder="Nom de l'utilisateur"
                        required
                    >
                </div>

                <div class="champ">
                    <label for="prenom">Prénom</label>
                    <input
                        type="text"
                        id="prenom"
                        name="prenom"
                        value="<?= e($utilisateurAModifier['prenom'] ?? '') ?>"
                        placeholder="Prénom de l'utilisateur"
                        required
                    >
                </div>

                <div class="champ">
                    <label for="identifiant">Identifiant</label>
                    <input
                        type="text"
                        id="identifiant"
                        name="identifiant"
                        value="<?= e($utilisateurAModifier['identifiant'] ?? '') ?>"
                        placeholder="Identifiant de connexion"
                        required
                    >
                </div>

                <div class="champ">
                    <label for="role">Profil de l'utilisateur</label>

                    <select name="role" id="role" required>

                        <?php
                        $roleActuel = $utilisateurAModifier['role'] ?? 'utilisateur';
                        ?>

                        <?php foreach ($rolesDisponibles as $valeur => $libelle): ?>

                            <option
                                value="<?= e($valeur) ?>"
                                <?= $roleActuel === $valeur ? 'selected' : '' ?>
                            >
                                <?= e($libelle) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>
                </div>

                <div class="champ">
                    <label for="mot_de_passe">
                        Mot de passe

                        <?php if ($utilisateurAModifier): ?>
                            <span class="indication">
                                (laisser vide pour conserver l'ancien)
                            </span>
                        <?php endif; ?>
                    </label>

                    <input
                        type="password"
                        id="mot_de_passe"
                        name="mot_de_passe"
                        placeholder="<?= $utilisateurAModifier ? 'Nouveau mot de passe facultatif' : '8 caractères minimum' ?>"
                        <?= $utilisateurAModifier ? '' : 'required' ?>
                        minlength="8"
                    >
                </div>

            </div>

            <div class="bloc-modules">

                <h3>Autorisations d'accès</h3>

                <p>
                    Cochez les modules auxquels cet utilisateur pourra accéder.
                    Le tableau de bord est attribué automatiquement.
                </p>

                <div class="grille-modules">

                    <?php foreach ($modules as $module): ?>

                        <?php
                        $estDashboard = $module["code"] === "tableau_de_bord";

                        $estSelectionne = $estDashboard ||
                            in_array((int) $module["id"], $modulesUtilisateur, true);
                        ?>

                        <label class="option-module">

                            <input
                                type="checkbox"
                                name="modules[]"
                                value="<?= (int) $module["id"] ?>"
                                <?= $estSelectionne ? 'checked' : '' ?>
                                <?= $estDashboard ? 'disabled' : '' ?>
                            >

                            <?php if ($estDashboard): ?>
                                <input
                                    type="hidden"
                                    name="modules[]"
                                    value="<?= (int) $module["id"] ?>"
                                >
                            <?php endif; ?>

                            <span><?= e($module["nom"]) ?></span>

                        </label>

                    <?php endforeach; ?>

                </div>

            </div>

            <div class="actions-formulaire">

                <?php if ($utilisateurAModifier): ?>

                    <a href="utilisateurs.php" class="bouton-annuler">
                        Annuler
                    </a>

                <?php endif; ?>

                <button type="submit" class="bouton-principal">
                    <?= $utilisateurAModifier ? "Enregistrer les modifications" : "Créer le compte" ?>
                </button>

            </div>

        </form>

    </section>

    <!-- LISTE DES UTILISATEURS -->

    <section class="bloc-liste">

        <div class="titre-section">

            <div>
                <h2>Liste des utilisateurs</h2>
                <p>Comptes actifs et inactifs de la plateforme.</p>
            </div>

            <input
                type="search"
                id="rechercheUtilisateur"
                placeholder="Rechercher un utilisateur..."
                class="recherche"
            >

        </div>

        <div class="tableau-conteneur">

            <table>

                <thead>
                    <tr>
                        <th>Utilisateur</th>
                        <th>Identifiant</th>
                        <th>Rôle</th>
                        <th>Modules</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody id="listeUtilisateurs">

                    <?php foreach ($utilisateurs as $utilisateur): ?>

                        <tr>

                            <td>
                                <strong>
                                    <?= e($utilisateur["prenom"] . " " . $utilisateur["nom"]) ?>
                                </strong>
                            </td>

                            <td><?= e($utilisateur["identifiant"]) ?></td>

                            <td>
                                <?= e($rolesDisponibles[$utilisateur["role"]] ?? $utilisateur["role"]) ?>
                            </td>

                            <td>
                                <?= (int) $utilisateur["nombre_modules"] ?> module(s)
                            </td>

                            <td>
                                <span class="statut <?= e($utilisateur["statut"]) ?>">
                                    <?= e(ucfirst($utilisateur["statut"])) ?>
                                </span>
                            </td>

                            <td class="actions-tableau">

                                <a
                                    href="utilisateurs.php?modifier=<?= (int) $utilisateur['id'] ?>"
                                    class="action-modifier"
                                >
                                    Modifier
                                </a>

                                <?php if ((int) $utilisateur["id"] !== (int) $_SESSION["utilisateur_id"]): ?>

                                    <!-- Activation / désactivation -->

                                    <form
                                        method="POST"
                                        action="utilisateurs.php"
                                        class="form-statut"
                                    >

                                        <input
                                            type="hidden"
                                            name="jeton_csrf"
                                            value="<?= e($_SESSION['jeton_csrf']) ?>"
                                        >

                                        <input type="hidden" name="action" value="statut">

                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int) $utilisateur['id'] ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="statut"
                                            value="<?= $utilisateur['statut'] === 'actif' ? 'inactif' : 'actif' ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="<?= $utilisateur['statut'] === 'actif' ? 'action-desactiver' : 'action-activer' ?>"
                                        >
                                            <?= $utilisateur['statut'] === 'actif' ? 'Désactiver' : 'Activer' ?>
                                        </button>

                                    </form>

                                    <!-- Suppression -->

                                    <form
                                        method="POST"
                                        action="utilisateurs.php"
                                        class="form-suppression"
                                        onsubmit="return confirm('Voulez-vous vraiment supprimer définitivement cet utilisateur ? Cette action est irréversible.');"
                                    >

                                        <input
                                            type="hidden"
                                            name="jeton_csrf"
                                            value="<?= e($_SESSION['jeton_csrf']) ?>"
                                        >

                                        <input type="hidden" name="action" value="supprimer">

                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int) $utilisateur['id'] ?>"
                                        >

                                        <button type="submit" class="action-supprimer">
                                            Supprimer
                                        </button>

                                    </form>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    <?php if (empty($utilisateurs)): ?>

                        <tr>
                            <td colspan="6" class="aucun-resultat">
                                Aucun utilisateur enregistré.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

    <footer>
        Gestion Sécurité UASZ — Administration des utilisateurs
    </footer>

</div>

<script src="../../../public/js/utilisateurs.js"></script>

</body>
</html>


<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';
exigerAcces('plannings');

function e($valeur) {
    return htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_plannings'])) {
    $_SESSION['csrf_plannings'] = bin2hex(random_bytes(32));
}

$messageErreur = '';
$messageSucces = '';

$statuts = [
    'planifie' => 'Planifié',
    'en_cours' => 'En cours',
    'termine' => 'Terminé',
    'annule' => 'Annulé'
];

$planning = [
    'id' => '',
    'agent_id' => '',
    'date_planning' => date('Y-m-d'),
    'heure_debut' => '',
    'heure_fin' => '',
    'secteur' => '',
    'mission' => '',
    'statut' => 'planifie',
    'observations' => ''
];

$modeEdition = false;

/* Vérification d'une date au format AAAA-MM-JJ */
function dateValide($date) {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return false;
    }

    $parties = explode('-', $date);

    return checkdate(
        (int) $parties[1],
        (int) $parties[2],
        (int) $parties[0]
    );
}

/* Traitement du formulaire */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jeton = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_plannings'], $jeton)) {
        $messageErreur = "Votre session a expiré. Rechargez la page.";
    } else {
        $id = (int) ($_POST['id'] ?? 0);
        $agentId = (int) ($_POST['agent_id'] ?? 0);
        $date = trim($_POST['date_planning'] ?? '');
        $heureDebut = trim($_POST['heure_debut'] ?? '');
        $heureFin = trim($_POST['heure_fin'] ?? '');
        $secteur = trim($_POST['secteur'] ?? '');
        $mission = trim($_POST['mission'] ?? '');
        $statut = $_POST['statut'] ?? 'planifie';
        $observations = trim($_POST['observations'] ?? '');

        $planning = [
            'id' => $id,
            'agent_id' => $agentId,
            'date_planning' => $date,
            'heure_debut' => $heureDebut,
            'heure_fin' => $heureFin,
            'secteur' => $secteur,
            'mission' => $mission,
            'statut' => $statut,
            'observations' => $observations
        ];

        /* Vérifier les champs obligatoires */
        if ($agentId <= 0 || $secteur === '' || $mission === '' ||
            $date === '' || $heureDebut === '' || $heureFin === '') {
            $messageErreur = "Veuillez remplir tous les champs obligatoires.";
        } elseif (!dateValide($date)) {
            $messageErreur = "La date du planning est invalide.";
        } elseif (
            !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $heureDebut) ||
            !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $heureFin)
        ) {
            $messageErreur = "Veuillez saisir des horaires valides.";
        } elseif ($heureDebut >= $heureFin) {
            $messageErreur = "L'heure de fin doit être après l'heure de début.";
        } elseif (!array_key_exists($statut, $statuts)) {
            $messageErreur = "Le statut sélectionné est invalide.";
        }

        /* Vérifier que l'agent existe et qu'il est actif */
        if ($messageErreur === '') {
            $reqAgent = $connexion->prepare(
                "SELECT COUNT(*) FROM agents WHERE id = ? AND statut = 'actif'"
            );
            $reqAgent->execute([$agentId]);

            if (!$reqAgent->fetchColumn()) {
                $messageErreur = "L'agent sélectionné n'existe pas ou n'est pas actif.";
            }
        }

        /* Vérifier les chevauchements d'horaires */
        if (
            $messageErreur === '' &&
            in_array($statut, ['planifie', 'en_cours'], true)
        ) {
            $sqlChevauchement = "
                SELECT COUNT(*)
                FROM plannings
                WHERE agent_id = ?
                  AND date_planning = ?
                  AND statut IN ('planifie', 'en_cours')
                  AND heure_debut < ?
                  AND heure_fin > ?
            ";

            $parametres = [
                $agentId,
                $date,
                $heureFin,
                $heureDebut
            ];

            if ($id > 0) {
                $sqlChevauchement .= " AND id <> ?";
                $parametres[] = $id;
            }

            $reqChevauchement = $connexion->prepare($sqlChevauchement);
            $reqChevauchement->execute($parametres);

            if ($reqChevauchement->fetchColumn() > 0) {
                $messageErreur = "Cet agent possède déjà un planning sur cette plage horaire.";
            }
        }

        /* Enregistrer le planning */
        if ($messageErreur === '') {
            try {
                if ($id > 0) {
                    $reqExistence = $connexion->prepare(
                        "SELECT COUNT(*) FROM plannings WHERE id = ?"
                    );
                    $reqExistence->execute([$id]);

                    if (!$reqExistence->fetchColumn()) {
                        throw new RuntimeException("Planning introuvable.");
                    }

                    $sql = "
                        UPDATE plannings
                        SET agent_id = ?,
                            date_planning = ?,
                            heure_debut = ?,
                            heure_fin = ?,
                            secteur = ?,
                            mission = ?,
                            statut = ?,
                            observations = ?
                        WHERE id = ?
                    ";

                    $req = $connexion->prepare($sql);
                    $req->execute([
                        $agentId,
                        $date,
                        $heureDebut,
                        $heureFin,
                        $secteur,
                        $mission,
                        $statut,
                        $observations,
                        $id
                    ]);
                } else {
                    $sql = "
                        INSERT INTO plannings
                        (
                            agent_id,
                            date_planning,
                            heure_debut,
                            heure_fin,
                            secteur,
                            mission,
                            statut,
                            observations
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ";

                    $req = $connexion->prepare($sql);
                    $req->execute([
                        $agentId,
                        $date,
                        $heureDebut,
                        $heureFin,
                        $secteur,
                        $mission,
                        $statut,
                        $observations
                    ]);
                }

                header('Location: plannings.php?succes=1');
                exit;

            } catch (RuntimeException $erreur) {
                $messageErreur = $erreur->getMessage();
            } catch (PDOException $erreur) {
                $messageErreur = "Une erreur est survenue lors de l'enregistrement du planning.";
            }
        }
    }
}

/* Charger un planning à modifier */
if (
    $_SERVER['REQUEST_METHOD'] !== 'POST' &&
    isset($_GET['modifier'])
) {
    $idEdition = (int) $_GET['modifier'];

    $req = $connexion->prepare(
        "SELECT * FROM plannings WHERE id = ?"
    );
    $req->execute([$idEdition]);
    $resultat = $req->fetch();

    if ($resultat) {
        $planning = $resultat;
        $modeEdition = true;
    } else {
        $messageErreur = "Planning introuvable.";
    }
}

if (isset($_GET['succes'])) {
    $messageSucces = "Le planning a été enregistré avec succès.";
}

/* Charger les agents actifs et conserver l'agent sélectionné en édition */
$sqlAgents = "
    SELECT id, matricule, nom, prenom, statut
    FROM agents
    WHERE statut = 'actif'
";

$paramAgents = [];

if (!empty($planning['agent_id'])) {
    $sqlAgents .= " OR id = ?";
    $paramAgents[] = $planning['agent_id'];
}

$sqlAgents .= " ORDER BY nom, prenom";

$reqAgents = $connexion->prepare($sqlAgents);
$reqAgents->execute($paramAgents);
$agents = $reqAgents->fetchAll();

/* Filtres de recherche */
$filtreDate = trim($_GET['date'] ?? '');
$filtreAgent = (int) ($_GET['agent'] ?? 0);

$sqlListe = "
    SELECT p.*, a.matricule, a.nom, a.prenom
    FROM plannings p
    INNER JOIN agents a ON a.id = p.agent_id
    WHERE 1 = 1
";

$paramListe = [];

if ($filtreDate !== '' && dateValide($filtreDate)) {
    $sqlListe .= " AND p.date_planning = ?";
    $paramListe[] = $filtreDate;
}

if ($filtreAgent > 0) {
    $sqlListe .= " AND p.agent_id = ?";
    $paramListe[] = $filtreAgent;
}

$sqlListe .= " ORDER BY p.date_planning DESC, p.heure_debut ASC";

$reqListe = $connexion->prepare($sqlListe);
$reqListe->execute($paramListe);
$plannings = $reqListe->fetchAll();

/* Calcul des statistiques sur les résultats affichés */
$totalPlannings = count($plannings);
$totalPlanifies = 0;
$totalEnCours = 0;
$totalTermines = 0;
$totalAnnules = 0;

foreach ($plannings as $item) {
    switch ($item['statut']) {
        case 'planifie':
            $totalPlanifies++;
            break;
        case 'en_cours':
            $totalEnCours++;
            break;
        case 'termine':
            $totalTermines++;
            break;
        case 'annule':
            $totalAnnules++;
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planning des agents | UASZ</title>
    <link rel="stylesheet" href="/gestion_securite_uasz/public/css/plannings.css?v=1">
</head>
<body>

<div class="page-container">

    <header class="page-header">
        <div>
            <span class="sur-titre">GESTION DE LA SÉCURITÉ UASZ</span>
            <h1>Planning des agents</h1>
            <p>Organisez les missions et les horaires de travail des agents.</p>
        </div>

        <a href="../tableau_de_bord/tableau_de_bord.php" class="bouton-retour">
            ← Tableau de bord
        </a>
    </header>

    <?php if ($messageErreur !== ''): ?>
        <div class="message erreur"><?= e($messageErreur) ?></div>
    <?php endif; ?>

    <?php if ($messageSucces !== ''): ?>
        <div class="message succes"><?= e($messageSucces) ?></div>
    <?php endif; ?>

    <section class="statistiques">
        <div class="stat-card">
            <span class="stat-icone">📋</span>
            <div>
                <p>Total des plannings</p>
                <strong><?= $totalPlannings ?></strong>
            </div>
        </div>

        <div class="stat-card">
            <span class="stat-icone">📅</span>
            <div>
                <p>Planifiés</p>
                <strong><?= $totalPlanifies ?></strong>
            </div>
        </div>

        <div class="stat-card">
            <span class="stat-icone">⏳</span>
            <div>
                <p>En cours</p>
                <strong><?= $totalEnCours ?></strong>
            </div>
        </div>

        <div class="stat-card">
            <span class="stat-icone">✅</span>
            <div>
                <p>Terminés</p>
                <strong><?= $totalTermines ?></strong>
            </div>
        </div>
    </section>

    <section class="formulaire-section">
        <div class="section-titre">
            <div>
                <h2>
                    <?= $modeEdition || !empty($planning['id'])
                        ? 'Modifier un planning'
                        : 'Créer un planning' ?>
                </h2>
                <p>Attribuez une mission à un agent.</p>
            </div>
        </div>

        <?php if (count($agents) === 0): ?>
            <div class="message information">
                Aucun agent actif n'est disponible. Ajoutez d'abord un agent dans le module Agents.
            </div>
        <?php else: ?>

        <form method="POST" class="form-planning">
            <input type="hidden" name="csrf_token"
                   value="<?= e($_SESSION['csrf_plannings']) ?>">
            <input type="hidden" name="id" value="<?= e($planning['id']) ?>">

            <div class="form-grid">

                <div class="champ">
                    <label for="agent_id">Agent concerné *</label>
                    <select name="agent_id" id="agent_id" required>
                        <option value="">-- Choisir un agent --</option>

                        <?php foreach ($agents as $agent): ?>
                            <option value="<?= e($agent['id']) ?>"
                                <?= (string)$planning['agent_id'] === (string)$agent['id']
                                    ? 'selected' : '' ?>>
                                <?= e(
                                    $agent['matricule'] . ' - ' .
                                    $agent['prenom'] . ' ' . $agent['nom']
                                ) ?>
                                <?= $agent['statut'] !== 'actif' ? ' (Inactif)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="champ">
                    <label for="date_planning">Date de la mission *</label>
                    <input type="date" name="date_planning" id="date_planning"
                           value="<?= e($planning['date_planning']) ?>" required>
                </div>

                <div class="champ">
                    <label for="heure_debut">Heure de début *</label>
                    <input type="time" name="heure_debut" id="heure_debut"
                           value="<?= e($planning['heure_debut']) ?>" required>
                </div>

                <div class="champ">
                    <label for="heure_fin">Heure de fin *</label>
                    <input type="time" name="heure_fin" id="heure_fin"
                           value="<?= e($planning['heure_fin']) ?>" required>
                </div>

                <div class="champ">
                    <label for="secteur">Secteur *</label>
                    <input type="text" name="secteur" id="secteur"
                           value="<?= e($planning['secteur']) ?>"
                           placeholder="Ex. : Secteur Nord" maxlength="150" required>
                </div>

                <div class="champ">
                    <label for="statut">État du planning *</label>
                    <select name="statut" id="statut" required>
                        <?php foreach ($statuts as $cle => $libelle): ?>
                            <option value="<?= e($cle) ?>"
                                <?= $planning['statut'] === $cle ? 'selected' : '' ?>>
                                <?= e($libelle) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="champ champ-large">
                    <label for="mission">Mission à effectuer *</label>
                    <input type="text" name="mission" id="mission"
                           value="<?= e($planning['mission']) ?>"
                           placeholder="Ex. : Surveillance du bâtiment"
                           maxlength="255" required>
                </div>

                <div class="champ champ-large">
                    <label for="observations">Observations</label>
                    <textarea name="observations" id="observations" rows="3"
                              placeholder="Informations complémentaires..."><?= e($planning['observations']) ?></textarea>
                </div>

            </div>

            <div class="form-actions">
                <?php if ($modeEdition || !empty($planning['id'])): ?>
                    <a href="plannings.php" class="bouton-annuler">Annuler</a>
                <?php endif; ?>

                <button type="submit" class="bouton-principal">
                    <?= $modeEdition || !empty($planning['id'])
                        ? 'Enregistrer les modifications'
                        : 'Créer le planning' ?>
                </button>
            </div>
        </form>
        <?php endif; ?>
    </section>

    <section class="liste-section">
        <div class="section-titre">
            <div>
                <h2>Liste des plannings</h2>
                <p>Consultez les missions attribuées aux agents.</p>
            </div>
            <span class="compteur"><?= $totalPlannings ?> planning(s)</span>
        </div>

        <form method="GET" class="filtres">
            <div class="champ">
                <label for="filtre_date">Rechercher par date</label>
                <input type="date" name="date" id="filtre_date"
                       value="<?= e($filtreDate) ?>">
            </div>

            <div class="champ">
                <label for="filtre_agent">Rechercher par agent</label>
                <select name="agent" id="filtre_agent">
                    <option value="0">Tous les agents</option>
                    <?php foreach ($agents as $agent): ?>
                        <option value="<?= e($agent['id']) ?>"
                            <?= $filtreAgent === (int)$agent['id'] ? 'selected' : '' ?>>
                            <?= e($agent['prenom'] . ' ' . $agent['nom']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="bouton-filtrer">Filtrer</button>
            <a href="plannings.php" class="bouton-reinitialiser">Réinitialiser</a>
        </form>

        <?php if (count($plannings) === 0): ?>
            <div class="vide">
                <div class="vide-icone">📅</div>
                <h3>Aucun planning trouvé</h3>
                <p>Les missions programmées apparaîtront ici.</p>
            </div>
        <?php else: ?>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Agent</th>
                        <th>Date</th>
                        <th>Horaires</th>
                        <th>Secteur</th>
                        <th>Mission</th>
                        <th>État</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                <?php foreach ($plannings as $item): ?>
                    <tr>
                        <td>
                            <strong><?= e($item['prenom'] . ' ' . $item['nom']) ?></strong>
                            <small class="matricule"><?= e($item['matricule']) ?></small>
                        </td>

                        <td><?= e(date('d/m/Y', strtotime($item['date_planning']))) ?></td>

                        <td>
                            <?= e(substr($item['heure_debut'], 0, 5)) ?>
                            – <?= e(substr($item['heure_fin'], 0, 5)) ?>
                        </td>

                        <td><?= e($item['secteur']) ?></td>

                        <td><?= e($item['mission']) ?></td>

                        <td>
                            <span class="etat etat-<?= e($item['statut']) ?>">
                                <?= e($statuts[$item['statut']] ?? $item['statut']) ?>
                            </span>
                        </td>

                        <td>
                            <a class="bouton-modifier"
                               href="plannings.php?modifier=<?= e($item['id']) ?>">
                                Modifier
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </section>

</div>

<script src="/gestion_securite_uasz/public/js/plannings.js?v=1"></script>
</body>
</html>


<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';
exigerAcces('presences');

function e($valeur) {
    return htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_presences'])) {
    $_SESSION['csrf_presences'] = bin2hex(random_bytes(32));
}

$messageErreur = '';
$messageSucces = '';

$statuts = [
    'present' => 'Présent',
    'absent' => 'Absent',
    'retard' => 'En retard'
];

$presence = [
    'id' => '',
    'agent_id' => '',
    'date_presence' => date('Y-m-d'),
    'heure_arrivee' => '',
    'heure_depart' => '',
    'statut' => 'present',
    'observations' => ''
];

$modeEdition = false;

/* Enregistrement d'une présence */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jeton = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_presences'], $jeton)) {
        $messageErreur = "Votre session a expiré. Rechargez la page.";
    } else {
        $id = (int) ($_POST['id'] ?? 0);
        $agentId = (int) ($_POST['agent_id'] ?? 0);
        $date = trim($_POST['date_presence'] ?? '');
        $heureArrivee = trim($_POST['heure_arrivee'] ?? '');
        $heureDepart = trim($_POST['heure_depart'] ?? '');
        $statut = $_POST['statut'] ?? '';
        $observations = trim($_POST['observations'] ?? '');

        $presence = [
            'id' => $id,
            'agent_id' => $agentId,
            'date_presence' => $date,
            'heure_arrivee' => $heureArrivee,
            'heure_depart' => $heureDepart,
            'statut' => $statut,
            'observations' => $observations
        ];

        /* Vérification des champs */
        if ($agentId <= 0 || $date === '' || !checkdate(
            (int) substr($date, 5, 2),
            (int) substr($date, 8, 2),
            (int) substr($date, 0, 4)
        )) {
            $messageErreur = "Veuillez sélectionner un agent et une date valide.";
        } elseif (!array_key_exists($statut, $statuts)) {
            $messageErreur = "Le statut sélectionné est invalide.";
        } elseif ($heureArrivee !== '' &&
            !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $heureArrivee)) {
            $messageErreur = "L'heure d'arrivée est invalide.";
        } elseif ($heureDepart !== '' &&
            !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $heureDepart)) {
            $messageErreur = "L'heure de départ est invalide.";
        } elseif ($heureArrivee !== '' && $heureDepart !== '' &&
            $heureDepart <= $heureArrivee) {
            $messageErreur = "L'heure de départ doit être après l'heure d'arrivée.";
        } elseif ($statut !== 'absent' && $heureArrivee === '') {
            $messageErreur = "Veuillez renseigner l'heure d'arrivée.";
        }

        /* Vérifier l'existence de l'agent */
        if ($messageErreur === '') {
            $reqAgent = $connexion->prepare(
                "SELECT COUNT(*) FROM agents WHERE id = ?"
            );
            $reqAgent->execute([$agentId]);

            if (!$reqAgent->fetchColumn()) {
                $messageErreur = "L'agent sélectionné est introuvable.";
            }
        }

        /* Enregistrer la fiche */
        if ($messageErreur === '') {
            $heureArriveeFinale = $statut === 'absent' ? null :
                ($heureArrivee !== '' ? $heureArrivee : null);

            $heureDepartFinale = $statut === 'absent' ? null :
                ($heureDepart !== '' ? $heureDepart : null);

            try {
                if ($id > 0) {
                    $sql = "
                        UPDATE presences
                        SET agent_id = ?,
                            date_presence = ?,
                            heure_arrivee = ?,
                            heure_depart = ?,
                            statut = ?,
                            observations = ?
                        WHERE id = ?
                    ";

                    $req = $connexion->prepare($sql);
                    $req->execute([
                        $agentId,
                        $date,
                        $heureArriveeFinale,
                        $heureDepartFinale,
                        $statut,
                        $observations,
                        $id
                    ]);
                } else {
                    $sql = "
                        INSERT INTO presences
                        (agent_id, date_presence, heure_arrivee,
                         heure_depart, statut, observations)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ";

                    $req = $connexion->prepare($sql);
                    $req->execute([
                        $agentId,
                        $date,
                        $heureArriveeFinale,
                        $heureDepartFinale,
                        $statut,
                        $observations
                    ]);
                }

                header('Location: presences.php?succes=1');
                exit;

            } catch (PDOException $erreur) {
                if ($erreur->getCode() === '23000') {
                    $messageErreur = "Une fiche de présence existe déjà pour cet agent à cette date.";
                } else {
                    $messageErreur = "Une erreur est survenue lors de l'enregistrement.";
                }
            }
        }
    }
}

/* Charger une fiche à modifier */
if ($_SERVER['REQUEST_METHOD'] !== 'POST' && isset($_GET['modifier'])) {
    $idEdition = (int) $_GET['modifier'];

    $req = $connexion->prepare(
        "SELECT * FROM presences WHERE id = ?"
    );
    $req->execute([$idEdition]);
    $resultat = $req->fetch();

    if ($resultat) {
        $presence = $resultat;
        $modeEdition = true;
    } else {
        $messageErreur = "Fiche de présence introuvable.";
    }
}

if (isset($_GET['succes'])) {
    $messageSucces = "La fiche de présence a été enregistrée avec succès.";
}

/* Liste des agents */
$sqlAgents = "
    SELECT id, matricule, nom, prenom, statut
    FROM agents
";

$paramAgents = [];

if (!empty($presence['agent_id'])) {
    $sqlAgents .= " WHERE statut = 'actif' OR id = ?";
    $paramAgents[] = $presence['agent_id'];
} else {
    $sqlAgents .= " WHERE statut = 'actif'";
}

$sqlAgents .= " ORDER BY nom, prenom";

$reqAgents = $connexion->prepare($sqlAgents);
$reqAgents->execute($paramAgents);
$agents = $reqAgents->fetchAll();

/* Filtres */
$filtreDate = $_GET['date'] ?? '';
$filtreAgent = (int) ($_GET['agent'] ?? 0);

$sqlListe = "
    SELECT p.*, a.matricule, a.nom, a.prenom
    FROM presences p
    INNER JOIN agents a ON a.id = p.agent_id
    WHERE 1 = 1
";

$paramListe = [];

if ($filtreDate !== '' &&
    preg_match('/^\d{4}-\d{2}-\d{2}$/', $filtreDate)) {
    $sqlListe .= " AND p.date_presence = ?";
    $paramListe[] = $filtreDate;
}

if ($filtreAgent > 0) {
    $sqlListe .= " AND p.agent_id = ?";
    $paramListe[] = $filtreAgent;
}

$sqlListe .= " ORDER BY p.date_presence DESC, p.id DESC";

$reqListe = $connexion->prepare($sqlListe);
$reqListe->execute($paramListe);
$presences = $reqListe->fetchAll();

$totalPresences = count($presences);
$totalPresents = 0;
$totalAbsents = 0;
$totalRetards = 0;

foreach ($presences as $item) {
    if ($item['statut'] === 'present') {
        $totalPresents++;
    } elseif ($item['statut'] === 'absent') {
        $totalAbsents++;
    } elseif ($item['statut'] === 'retard') {
        $totalRetards++;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des présences | UASZ</title>
    <link rel="stylesheet" href="/gestion_securite_uasz/public/css/presences.css?v=2">
</head>
<body>

<div class="page-container">

    <header class="page-header">
        <div>
            <span class="sur-titre">GESTION DE LA SÉCURITÉ UASZ</span>
            <h1>Gestion des présences</h1>
            <p>Suivez les arrivées, les départs et les absences des agents.</p>
        </div>

        <a href="../tableau_de_bord/tableau_de_bord.php" class="bouton-retour">
            ← Tableau de bord
        </a>
    </header>

    <?php if ($messageErreur): ?>
        <div class="message erreur"><?= e($messageErreur) ?></div>
    <?php endif; ?>

    <?php if ($messageSucces): ?>
        <div class="message succes"><?= e($messageSucces) ?></div>
    <?php endif; ?>

    <section class="statistiques">
        <div class="stat-card">
            <span class="stat-icone">📋</span>
            <div>
                <p>Total des fiches</p>
                <strong><?= $totalPresences ?></strong>
            </div>
        </div>

        <div class="stat-card">
            <span class="stat-icone">✅</span>
            <div>
                <p>Présents</p>
                <strong><?= $totalPresents ?></strong>
            </div>
        </div>

        <div class="stat-card">
            <span class="stat-icone">⏰</span>
            <div>
                <p>En retard</p>
                <strong><?= $totalRetards ?></strong>
            </div>
        </div>

        <div class="stat-card">
            <span class="stat-icone">❌</span>
            <div>
                <p>Absents</p>
                <strong><?= $totalAbsents ?></strong>
            </div>
        </div>
    </section>

    <section class="formulaire-section">
        <div class="section-titre">
            <div>
                <h2>
                    <?= $modeEdition || !empty($presence['id'])
                        ? 'Modifier une présence'
                        : 'Enregistrer une présence' ?>
                </h2>
                <p>Renseignez les informations de présence de l'agent.</p>
            </div>
        </div>

        <?php if (count($agents) === 0): ?>
            <div class="message information">
                Aucun agent n'est enregistré. Ajoutez d'abord des agents dans le module Agents.
            </div>
        <?php else: ?>

        <form method="POST" class="form-presence">
            <input type="hidden" name="csrf_token"
                   value="<?= e($_SESSION['csrf_presences']) ?>">
            <input type="hidden" name="id" value="<?= e($presence['id']) ?>">

            <div class="form-grid">

                <div class="champ">
                    <label for="agent_id">Agent *</label>
                    <select name="agent_id" id="agent_id" required>
                        <option value="">-- Choisir un agent --</option>
                        <?php foreach ($agents as $agent): ?>
                            <option value="<?= e($agent['id']) ?>"
                                <?= (string)$presence['agent_id'] === (string)$agent['id']
                                    ? 'selected' : '' ?>>
                                <?= e($agent['matricule'] . ' - ' .
                                    $agent['prenom'] . ' ' . $agent['nom']) ?>
                                <?= $agent['statut'] !== 'actif' ? ' (Inactif)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="champ">
                    <label for="date_presence">Date de présence *</label>
                    <input type="date" name="date_presence" id="date_presence"
                           value="<?= e($presence['date_presence']) ?>" required>
                </div>

                <div class="champ">
                    <label for="statut">Statut *</label>
                    <select name="statut" id="statut" required>
                        <?php foreach ($statuts as $cle => $libelle): ?>
                            <option value="<?= e($cle) ?>"
                                <?= $presence['statut'] === $cle ? 'selected' : '' ?>>
                                <?= e($libelle) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="champ">
                    <label for="heure_arrivee">Heure d'arrivée</label>
                    <input type="time" name="heure_arrivee" id="heure_arrivee"
                           value="<?= e($presence['heure_arrivee']) ?>">
                </div>

                <div class="champ">
                    <label for="heure_depart">Heure de départ</label>
                    <input type="time" name="heure_depart" id="heure_depart"
                           value="<?= e($presence['heure_depart']) ?>">
                </div>

                <div class="champ champ-large">
                    <label for="observations">Observations</label>
                    <textarea name="observations" id="observations" rows="3"
                              placeholder="Remarques éventuelles..."><?= e($presence['observations']) ?></textarea>
                </div>

            </div>

            <div class="form-actions">
                <?php if ($modeEdition || !empty($presence['id'])): ?>
                    <a href="presences.php" class="bouton-annuler">Annuler</a>
                <?php endif; ?>

                <button type="submit" class="bouton-principal">
                    <?= $modeEdition || !empty($presence['id'])
                        ? 'Enregistrer les modifications'
                        : 'Enregistrer la présence' ?>
                </button>
            </div>
        </form>
        <?php endif; ?>
    </section>

    <section class="liste-section">

        <div class="section-titre">
            <div>
                <h2>Historique des présences</h2>
                <p>Consultez et filtrez les fiches enregistrées.</p>
            </div>
            <span class="compteur"><?= $totalPresences ?> fiche(s)</span>
        </div>

        <form method="GET" class="filtres">
            <div class="champ">
                <label for="filtre_date">Filtrer par date</label>
                <input type="date" name="date" id="filtre_date"
                       value="<?= e($filtreDate) ?>">
            </div>

            <div class="champ">
                <label for="filtre_agent">Filtrer par agent</label>
                <select name="agent" id="filtre_agent">
                    <option value="0">Tous les agents</option>
                    <?php foreach ($agents as $agent): ?>
                        <option value="<?= e($agent['id']) ?>"
                            <?= $filtreAgent === (int)$agent['id'] ? 'selected' : '' ?>>
                            <?= e($agent['prenom'] . ' ' . $agent['nom']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="bouton-filtrer">Filtrer</button>
            <a href="presences.php" class="bouton-reinitialiser">Réinitialiser</a>
        </form>

        <?php if (count($presences) === 0): ?>
            <div class="vide">
                <div class="vide-icone">📋</div>
                <h3>Aucune présence trouvée</h3>
                <p>Les fiches enregistrées apparaîtront ici.</p>
            </div>
        <?php else: ?>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Agent</th>
                        <th>Date</th>
                        <th>Arrivée</th>
                        <th>Départ</th>
                        <th>Statut</th>
                        <th>Observations</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                <?php foreach ($presences as $item): ?>
                    <tr>
                        <td>
                            <strong><?= e($item['prenom'] . ' ' . $item['nom']) ?></strong>
                            <small class="matricule"><?= e($item['matricule']) ?></small>
                        </td>

                        <td><?= e(date('d/m/Y', strtotime($item['date_presence']))) ?></td>

                        <td>
                            <?= $item['heure_arrivee']
                                ? e(substr($item['heure_arrivee'], 0, 5))
                                : '—' ?>
                        </td>

                        <td>
                            <?= $item['heure_depart']
                                ? e(substr($item['heure_depart'], 0, 5))
                                : '—' ?>
                        </td>

                        <td>
                            <span class="statut statut-<?= e($item['statut']) ?>">
                                <?= e($statuts[$item['statut']] ?? $item['statut']) ?>
                            </span>
                        </td>

                        <td><?= e($item['observations'] ?: '—') ?></td>

                        <td>
                            <a class="bouton-modifier"
                               href="presences.php?modifier=<?= e($item['id']) ?>">
                                Modifier
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

    </section>

</div>

<script src="../../../public/js/presences.js"></script>
</body>
</html>

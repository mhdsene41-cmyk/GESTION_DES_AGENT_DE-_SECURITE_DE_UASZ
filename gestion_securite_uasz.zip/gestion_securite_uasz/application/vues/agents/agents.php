
<?php

require_once __DIR__ . '/../../outils/verifier_acces.php';

// Vérifier l'autorisation d'accès au module
exigerAcces('agents');

// La gestion des agents est réservée à l'administrateur
exigerRole('administrateur');

function e($valeur) {
    return htmlspecialchars((string)$valeur, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_agents'])) {
    $_SESSION['csrf_agents'] = bin2hex(random_bytes(32));
}

$message = '';
$erreur = '';

$dossierPhotos = __DIR__ . '/../../../stockage/photos_agents/';
$urlPhotos = '../../../stockage/photos_agents/';

if (!is_dir($dossierPhotos)) {
    mkdir($dossierPhotos, 0755, true);
}

/* Enregistrement et modification */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($_SESSION['csrf_agents'], $_POST['csrf'] ?? '')) {
            throw new Exception("Session de sécurité invalide. Recharge la page.");
        }

        $action = $_POST['action'] ?? '';

        if ($action === 'desactiver') {
            $id = (int)($_POST['id'] ?? 0);

            $req = $connexion->prepare(
                "UPDATE agents SET statut = 'inactif' WHERE id = ?"
            );
            $req->execute([$id]);

            $message = "L'agent a été désactivé.";

        } elseif (in_array($action, ['ajouter', 'modifier'], true)) {

            $id = (int)($_POST['id'] ?? 0);

            $matricule = trim($_POST['matricule'] ?? '');
            $nom = trim($_POST['nom'] ?? '');
            $prenom = trim($_POST['prenom'] ?? '');
            $dateNaissance = !empty($_POST['date_naissance']) ? $_POST['date_naissance'] : null;
            $sexe = !empty($_POST['sexe']) ? $_POST['sexe'] : null;
            $telephone = trim($_POST['telephone'] ?? '');
            $adresse = trim($_POST['adresse'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $poste = trim($_POST['poste'] ?? '');
            $grade = trim($_POST['grade'] ?? '');
            $dateRecrutement = !empty($_POST['date_recrutement']) ? $_POST['date_recrutement'] : null;
            $statut = $_POST['statut'] ?? 'actif';
            $statutPaiement = $_POST['statut_paiement'] ?? 'non_renseigne';
            $contactUrgence = trim($_POST['contact_urgence'] ?? '');
            $telephoneUrgence = trim($_POST['telephone_urgence'] ?? '');
            $observations = trim($_POST['observations'] ?? '');

            if ($matricule === '' || $nom === '' || $prenom === '') {
                throw new Exception("Le matricule, le nom et le prénom sont obligatoires.");
            }

            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("L'adresse e-mail n'est pas valide.");
            }

            if (!in_array($sexe, [null, 'Masculin', 'Feminin'], true)) {
                throw new Exception("Le sexe sélectionné est invalide.");
            }

            if (!in_array($statut, ['actif', 'inactif'], true)) {
                throw new Exception("Le statut sélectionné est invalide.");
            }

            if (!in_array($statutPaiement, ['paye', 'non_paye', 'non_renseigne'], true)) {
                throw new Exception("Le statut de paiement est invalide.");
            }

            /* Récupérer l'ancienne photo en cas de modification */
            $photo = null;

            if ($action === 'modifier') {
                $reqPhoto = $connexion->prepare("SELECT photo FROM agents WHERE id = ?");
                $reqPhoto->execute([$id]);
                $ancienAgent = $reqPhoto->fetch();

                if (!$ancienAgent) {
                    throw new Exception("Agent introuvable.");
                }

                $photo = $ancienAgent['photo'];
            }

            /* Vérifier et enregistrer la nouvelle photo */
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {

                if ($_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
                    throw new Exception("Erreur lors de l'envoi de la photo.");
                }

                if ($_FILES['photo']['size'] > 3 * 1024 * 1024) {
                    throw new Exception("La photo ne doit pas dépasser 3 Mo.");
                }

                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($_FILES['photo']['tmp_name']);

                $extensions = [
                    'image/jpeg' => 'jpg',
                    'image/png' => 'png',
                    'image/webp' => 'webp'
                ];

                if (!isset($extensions[$mime])) {
                    throw new Exception("Format accepté : JPG, PNG ou WEBP.");
                }

                $nomPhoto = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
                $destination = $dossierPhotos . $nomPhoto;

                if (!move_uploaded_file($_FILES['photo']['tmp_name'], $destination)) {
                    throw new Exception("Impossible d'enregistrer la photo.");
                }

                $photo = 'stockage/photos_agents/' . $nomPhoto;
            }

            $donnees = [
                $matricule, $nom, $prenom, $photo,
                $dateNaissance, $sexe, $telephone, $adresse,
                $email, $poste, $grade, $dateRecrutement,
                $statut, $statutPaiement, $contactUrgence,
                $telephoneUrgence, $observations
            ];

            if ($action === 'ajouter') {

                $sql = "INSERT INTO agents (
                    matricule, nom, prenom, photo, date_naissance, sexe,
                    telephone, adresse, email, poste, grade,
                    date_recrutement, statut, statut_paiement,
                    contact_urgence, telephone_urgence, observations
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )";

                $connexion->prepare($sql)->execute($donnees);

                $message = "Agent enregistré avec succès.";

            } else {

                $sql = "UPDATE agents SET
                    matricule=?, nom=?, prenom=?, photo=?, date_naissance=?,
                    sexe=?, telephone=?, adresse=?, email=?, poste=?, grade=?,
                    date_recrutement=?, statut=?, statut_paiement=?,
                    contact_urgence=?, telephone_urgence=?, observations=?
                    WHERE id=?";

                $donnees[] = $id;

                $connexion->prepare($sql)->execute($donnees);

                $message = "Informations de l'agent mises à jour.";
            }
        }

    } catch (PDOException $ex) {
        $erreur = "Une erreur est survenue. Vérifie notamment que le matricule n'existe pas déjà.";

    } catch (Exception $ex) {
        $erreur = $ex->getMessage();
    }
}

/* Agent à modifier */
$agentAModifier = null;

if (isset($_GET['modifier'])) {

    $req = $connexion->prepare("SELECT * FROM agents WHERE id = ?");
    $req->execute([(int)$_GET['modifier']]);

    $agentAModifier = $req->fetch();

    if (!$agentAModifier) {
        $erreur = "Agent introuvable.";
    }
}

/* Recherche */
$recherche = trim($_GET['recherche'] ?? '');

if ($recherche !== '') {

    $req = $connexion->prepare("
        SELECT * FROM agents
        WHERE matricule LIKE ?
        OR nom LIKE ?
        OR prenom LIKE ?
        OR telephone LIKE ?
        ORDER BY date_creation DESC
    ");

    $mot = "%$recherche%";
    $req->execute([$mot, $mot, $mot, $mot]);

} else {

    $req = $connexion->query("
        SELECT * FROM agents
        ORDER BY date_creation DESC
    ");
}

$agents = $req->fetchAll();

$totalAgents = count($agents);
$totalActifs = 0;
$totalInactifs = 0;

foreach ($agents as $agent) {
    if ($agent['statut'] === 'actif') {
        $totalActifs++;
    } else {
        $totalInactifs++;
    }
}

$val = function($champ) use ($agentAModifier) {
    return $agentAModifier[$champ] ?? '';
};

$modeModification = $agentAModifier !== null;
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Gestion des agents | UASZ</title>

    <link rel="stylesheet" href="../../../public/css/agents.css">
</head>

<body>

<div class="page-agents">

    <header class="entete">
        <div>
            <span class="sous-titre">GESTION DU PERSONNEL</span>
            <h1>Gestion des agents</h1>
            <p>Administration des dossiers des agents de sécurité de l'UASZ.</p>
        </div>

        <a href="../tableau_de_bord/tableau_de_bord.php" class="retour">
            ← Tableau de bord
        </a>
    </header>

    <?php if ($message): ?>
        <div class="alerte succes"><?= e($message) ?></div>
    <?php endif; ?>

    <?php if ($erreur): ?>
        <div class="alerte erreur"><?= e($erreur) ?></div>
    <?php endif; ?>

    <section class="statistiques">

        <div class="statistique">
            <span>Total affiché</span>
            <strong><?= $totalAgents ?></strong>
        </div>

        <div class="statistique">
            <span>Agents actifs</span>
            <strong><?= $totalActifs ?></strong>
        </div>

        <div class="statistique">
            <span>Agents inactifs</span>
            <strong><?= $totalInactifs ?></strong>
        </div>

    </section>

    <section class="bloc">

        <div class="titre-bloc">
            <div>
                <h2><?= $modeModification ? 'Modifier un agent' : 'Enregistrer un nouvel agent' ?></h2>
                <p>Les champs marqués d'un * sont obligatoires.</p>
            </div>

            <?php if ($modeModification): ?>
                <a class="bouton-secondaire" href="agents.php">Annuler</a>
            <?php endif; ?>
        </div>

        <form method="POST" enctype="multipart/form-data" class="formulaire">

            <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf_agents']) ?>">

            <input type="hidden" name="action" value="<?= $modeModification ? 'modifier' : 'ajouter' ?>">

            <?php if ($modeModification): ?>
                <input type="hidden" name="id" value="<?= (int)$agentAModifier['id'] ?>">
            <?php endif; ?>

            <h3>Identification</h3>

            <div class="grille-formulaire">

                <label>Matricule *
                    <input type="text" name="matricule" required value="<?= e($val('matricule')) ?>">
                </label>

                <label>Nom *
                    <input type="text" name="nom" required value="<?= e($val('nom')) ?>">
                </label>

                <label>Prénom *
                    <input type="text" name="prenom" required value="<?= e($val('prenom')) ?>">
                </label>

                <label>Date de naissance
                    <input type="date" name="date_naissance" value="<?= e($val('date_naissance')) ?>">
                </label>

                <label>Sexe
                    <select name="sexe">
                        <option value="">Non renseigné</option>
                        <option value="Masculin" <?= $val('sexe') === 'Masculin' ? 'selected' : '' ?>>Masculin</option>
                        <option value="Feminin" <?= $val('sexe') === 'Feminin' ? 'selected' : '' ?>>Féminin</option>
                    </select>
                </label>

                <label>Téléphone
                    <input type="tel" name="telephone" value="<?= e($val('telephone')) ?>">
                </label>

                <label>Email
                    <input type="email" name="email" value="<?= e($val('email')) ?>">
                </label>

                <label>Adresse
                    <input type="text" name="adresse" value="<?= e($val('adresse')) ?>">
                </label>

            </div>

            <h3>Photo de l'agent</h3>

            <div class="zone-photo">

                <div class="apercu-photo">

                    <?php if ($modeModification && $val('photo')): ?>

                        <img
                            id="apercuPhoto"
                            src="<?= e($urlPhotos . basename($val('photo'))) ?>"
                            alt="Photo actuelle"
                        >

                    <?php else: ?>

                        <img
                            id="apercuPhoto"
                            src=""
                            alt="Aperçu de la photo"
                            hidden
                        >

                        <span id="textePhoto">Aucune photo sélectionnée</span>

                    <?php endif; ?>

                </div>

                <label class="choisir-photo">
                    Choisir une photo
                    <input
                        type="file"
                        name="photo"
                        id="photoAgent"
                        accept="image/jpeg,image/png,image/webp"
                    >
                </label>

                <small>Formats JPG, PNG ou WEBP — 3 Mo maximum.</small>

            </div>

            <h3>Informations professionnelles</h3>

            <div class="grille-formulaire">

                <label>Poste
                    <input type="text" name="poste" value="<?= e($val('poste')) ?>">
                </label>

                <label>Grade
                    <input type="text" name="grade" value="<?= e($val('grade')) ?>">
                </label>

                <label>Date de recrutement
                    <input type="date" name="date_recrutement" value="<?= e($val('date_recrutement')) ?>">
                </label>

                <label>Statut de l'agent
                    <select name="statut">
                        <option value="actif" <?= $val('statut') !== 'inactif' ? 'selected' : '' ?>>Actif</option>
                        <option value="inactif" <?= $val('statut') === 'inactif' ? 'selected' : '' ?>>Inactif</option>
                    </select>
                </label>

                <label>Statut de paiement
                    <select name="statut_paiement">
                        <option value="non_renseigne" <?= $val('statut_paiement') === 'non_renseigne' || !$val('statut_paiement') ? 'selected' : '' ?>>Non renseigné</option>
                        <option value="paye" <?= $val('statut_paiement') === 'paye' ? 'selected' : '' ?>>Payé</option>
                        <option value="non_paye" <?= $val('statut_paiement') === 'non_paye' ? 'selected' : '' ?>>Non payé</option>
                    </select>
                </label>

            </div>

            <h3>Contact d'urgence</h3>

            <div class="grille-formulaire">

                <label>Nom du contact
                    <input type="text" name="contact_urgence" value="<?= e($val('contact_urgence')) ?>">
                </label>

                <label>Téléphone du contact
                    <input type="tel" name="telephone_urgence" value="<?= e($val('telephone_urgence')) ?>">
                </label>

            </div>

            <h3>Informations supplémentaires</h3>

            <label class="champ-large">
                Observations
                <textarea name="observations" rows="3"><?= e($val('observations')) ?></textarea>
            </label>

            <div class="actions-formulaire">

                <button type="submit" class="bouton-principal">
                    <?= $modeModification ? 'Enregistrer les modifications' : 'Enregistrer l’agent' ?>
                </button>

                <button type="reset" class="bouton-secondaire">
                    Réinitialiser
                </button>

            </div>

        </form>

    </section>

    <section class="bloc">

        <div class="titre-bloc">
            <div>
                <h2>Liste des agents</h2>
                <p>Consulte et recherche les dossiers enregistrés.</p>
            </div>
        </div>

        <form method="GET" class="recherche">

            <input
                type="search"
                name="recherche"
                placeholder="Matricule, nom, prénom ou téléphone..."
                value="<?= e($recherche) ?>"
            >

            <button type="submit" class="bouton-principal">
                Rechercher
            </button>

            <?php if ($recherche !== ''): ?>
                <a href="agents.php" class="bouton-secondaire">Effacer</a>
            <?php endif; ?>

        </form>

        <div class="tableau-responsive">

            <table>

                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Matricule</th>
                        <th>Nom et prénom</th>
                        <th>Téléphone</th>
                        <th>Poste</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (!$agents): ?>

                    <tr>
                        <td colspan="7" class="vide">Aucun agent trouvé.</td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($agents as $agent): ?>

                        <tr>

                            <td>
                                <?php if ($agent['photo']): ?>

                                    <img
                                        class="photo-tableau"
                                        src="<?= e($urlPhotos . basename($agent['photo'])) ?>"
                                        alt="Photo"
                                    >

                                <?php else: ?>

                                    <span class="photo-vide">—</span>

                                <?php endif; ?>
                            </td>

                            <td><?= e($agent['matricule']) ?></td>

                            <td>
                                <strong><?= e($agent['nom'] . ' ' . $agent['prenom']) ?></strong>
                            </td>

                            <td><?= e($agent['telephone'] ?: '—') ?></td>

                            <td><?= e($agent['poste'] ?: '—') ?></td>

                            <td>
                                <span class="statut <?= e($agent['statut']) ?>">
                                    <?= $agent['statut'] === 'actif' ? 'Actif' : 'Inactif' ?>
                                </span>
                            </td>

                            <td class="actions-tableau">

                                <a
                                    href="agents.php?modifier=<?= (int)$agent['id'] ?>"
                                    class="action-modifier"
                                >
                                    Modifier
                                </a>

                                <?php if ($agent['statut'] === 'actif'): ?>

                                    <form
                                        method="POST"
                                        class="form-desactivation"
                                        data-confirmation="Désactiver cet agent ?"
                                    >

                                        <input
                                            type="hidden"
                                            name="csrf"
                                            value="<?= e($_SESSION['csrf_agents']) ?>"
                                        >

                                        <input type="hidden" name="action" value="desactiver">

                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int)$agent['id'] ?>"
                                        >

                                        <button type="submit" class="action-desactiver">
                                            Désactiver
                                        </button>

                                    </form>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</div>

<script src="../../../public/js/agents.js"></script>

</body>
</html>

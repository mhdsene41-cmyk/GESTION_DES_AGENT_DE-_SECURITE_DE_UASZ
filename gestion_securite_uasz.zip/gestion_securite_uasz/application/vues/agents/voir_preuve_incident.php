
<?php

require_once __DIR__ . '/../../outils/verifier_acces.php';

/*
|--------------------------------------------------------------------------
| CONSULTATION DES PREUVES
|--------------------------------------------------------------------------
| Tous les utilisateurs connectés peuvent consulter les preuves.
| Aucun droit de gestion des incidents n'est nécessaire.
*/

// Vérifier que les paramètres sont corrects.
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$type = $_GET['type'] ?? '';

if (!$id || !in_array($type, ['photo', 'video'], true)) {
    http_response_code(400);
    exit("Demande invalide.");
}

// Sélectionner la preuve demandée.
$colonne = $type === 'photo'
    ? 'photo_incident'
    : 'video_incident';

try {

    $req = $connexion->prepare(
        "SELECT `$colonne` AS fichier
         FROM incidents
         WHERE id = ?"
    );

    $req->execute([$id]);
    $incident = $req->fetch();

    if (!$incident || empty($incident['fichier'])) {
        http_response_code(404);
        exit("Preuve introuvable.");
    }

    // Vérifier le nom du fichier.
    $nomFichier = basename($incident['fichier']);

    if ($nomFichier !== $incident['fichier']) {
        http_response_code(400);
        exit("Nom de fichier invalide.");
    }

    // Vérifier le chemin réel du dossier.
    $dossier = realpath(
        __DIR__ . '/../../../stockage/incidents/'
    );

    if ($dossier === false) {
        http_response_code(404);
        exit("Dossier des preuves introuvable.");
    }

    $chemin = realpath($dossier . DIRECTORY_SEPARATOR . $nomFichier);

    if (
        $chemin === false ||
        !is_file($chemin) ||
        strpos(
            $chemin,
            $dossier . DIRECTORY_SEPARATOR
        ) !== 0
    ) {
        http_response_code(404);
        exit("Fichier introuvable.");
    }

    // Déterminer le type MIME réel du fichier.
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($chemin);

    $typesPhotos = [
        'image/jpeg',
        'image/png',
        'image/webp'
    ];

    $typesVideos = [
        'video/mp4',
        'video/webm'
    ];

    if (
        ($type === 'photo' && !in_array($mime, $typesPhotos, true)) ||
        ($type === 'video' && !in_array($mime, $typesVideos, true))
    ) {
        http_response_code(415);
        exit("Format de fichier non autorisé.");
    }

    // Envoyer les en-têtes de sécurité.
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($chemin));
    header('Content-Disposition: inline');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');

    // Afficher la preuve dans le navigateur.
    readfile($chemin);
    exit;

} catch (PDOException $erreur) {

    http_response_code(500);
    exit("Impossible de consulter cette preuve.");
}

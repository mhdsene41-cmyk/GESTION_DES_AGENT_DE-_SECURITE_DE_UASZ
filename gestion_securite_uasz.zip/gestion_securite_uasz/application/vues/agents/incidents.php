<?php

require_once __DIR__ . '/../../outils/verifier_acces.php';

/*
|--------------------------------------------------------------------------
| AUTORISATIONS
|--------------------------------------------------------------------------
*/

$peutGerer = verifierAcces('incidents');

function e($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_incidents'])) {
    $_SESSION['csrf_incidents'] = bin2hex(random_bytes(32));
}

$dossierPreuves = __DIR__ . '/../../../stockage/incidents/';

if (!is_dir($dossierPreuves)) {
    mkdir($dossierPreuves, 0750, true);
}

$messageErreur = '';
$messageSucces = '';
$edition = false;

$gravites = [
    'faible' => 'Faible',
    'moyenne' => 'Moyenne',
    'elevee' => 'Élevée',
    'critique' => 'Critique'
];

$statuts = [
    'nouveau' => 'Nouveau',
    'en_cours' => 'En cours',
    'resolu' => 'Résolu',
    'cloture' => 'Clôturé'
];

$incident = [
    'id' => '',
    'agent_id' => '',
    'date_incident' => date('Y-m-d\TH:i'),
    'lieu' => '',
    'description' => '',
    'gravite' => 'moyenne',
    'statut' => 'nouveau',
    'observations' => '',
    'photo_incident' => null,
    'video_incident' => null
];

/*
|--------------------------------------------------------------------------
| ENREGISTREMENT SÉCURISÉ DES PHOTOS ET VIDÉOS
|--------------------------------------------------------------------------
*/

function enregistrerPreuve($fichier, $type, $dossier) {

    if (!$fichier || $fichier['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($fichier['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException("Le transfert du fichier a échoué.");
    }

    $limite = $type === 'photo'
        ? 5 * 1024 * 1024
        : 30 * 1024 * 1024;

    if ($fichier['size'] <= 0 || $fichier['size'] > $limite) {
        throw new RuntimeException(
            $type === 'photo'
                ? "La photo ne doit pas dépasser 5 Mo."
                : "La vidéo ne doit pas dépasser 30 Mo."
        );
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($fichier['tmp_name']);

    $typesAutorises = $type === 'photo'
        ? [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp'
        ]
        : [
            'video/mp4' => 'mp4',
            'video/webm' => 'webm'
        ];

    if (!isset($typesAutorises[$mime])) {
        throw new RuntimeException(
            $type === 'photo'
                ? "Format de photo non autorisé. Utilisez JPG, PNG ou WEBP."
                : "Format vidéo non autorisé. Utilisez MP4 ou WEBM."
        );
    }

    if (
        $type === 'photo' &&
        getimagesize($fichier['tmp_name']) === false
    ) {
        throw new RuntimeException("Le fichier photo est invalide.");
    }

    $nom = bin2hex(random_bytes(20)) . '.' . $typesAutorises[$mime];
    $destination = $dossier . $nom;

    if (!move_uploaded_file($fichier['tmp_name'], $destination)) {
        throw new RuntimeException("Impossible de sauvegarder le fichier.");
    }

    chmod($destination, 0640);

    return $nom;
}

/*
|--------------------------------------------------------------------------
| RÉCUPÉRATION D'UN INCIDENT À MODIFIER
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] !== 'POST' &&
    isset($_GET['modifier'])
) {

    if (!$peutGerer) {
        http_response_code(403);
        exit("Vous n'avez pas l'autorisation de modifier les incidents.");
    }

    $id = (int)$_GET['modifier'];

    $req = $connexion->prepare(
        "SELECT * FROM incidents WHERE id = ?"
    );

    $req->execute([$id]);
    $resultat = $req->fetch();

    if ($resultat) {

        $incident = $resultat;

        $incident['date_incident'] = date(
            'Y-m-d\TH:i',
            strtotime($resultat['date_incident'])
        );

        $edition = true;

    } else {

        $messageErreur = "Incident introuvable.";
    }
}

/*
|--------------------------------------------------------------------------
| ENREGISTREMENT D'UN INCIDENT
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals(
        $_SESSION['csrf_incidents'],
        $_POST['csrf_token'] ?? ''
    )) {

        $messageErreur = "Session expirée. Rechargez la page.";

    } else {

        $id = (int)($_POST['id'] ?? 0);

        if ($id > 0 && !$peutGerer) {
            http_response_code(403);
            exit("Vous n'avez pas l'autorisation de modifier cet incident.");
        }

        $agentId = ($_POST['agent_id'] ?? '') !== ''
            ? (int)$_POST['agent_id']
            : null;

        $date = trim($_POST['date_incident'] ?? '');
        $lieu = trim($_POST['lieu'] ?? '');
        $description = trim($_POST['description'] ?? '');

        $gravite = $_POST['gravite'] ?? 'moyenne';

        $statut = $peutGerer
            ? ($_POST['statut'] ?? 'nouveau')
            : 'nouveau';

        $observations = $peutGerer
            ? trim($_POST['observations'] ?? '')
            : '';

        $anciennePhoto = null;
        $ancienneVideo = null;

        /*
         * Récupération des anciennes preuves.
         */

        if ($messageErreur === '' && $id > 0) {

            $reqAncien = $connexion->prepare(
                "SELECT photo_incident, video_incident
                 FROM incidents
                 WHERE id = ?"
            );

            $reqAncien->execute([$id]);
            $ancien = $reqAncien->fetch();

            if (!$ancien) {

                $messageErreur = "Incident introuvable.";

            } else {

                $anciennePhoto = $ancien['photo_incident'];
                $ancienneVideo = $ancien['video_incident'];
            }
        }

        $incident = [
            'id' => $id,
            'agent_id' => $agentId,
            'date_incident' => $date,
            'lieu' => $lieu,
            'description' => $description,
            'gravite' => $gravite,
            'statut' => $statut,
            'observations' => $observations,
            'photo_incident' => $anciennePhoto,
            'video_incident' => $ancienneVideo
        ];

        /*
         * Vérification de la date.
         */

        $dateValide = false;

        if (
            preg_match(
                '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/',
                $date
            )
        ) {

            $dateObjet = DateTime::createFromFormat('Y-m-d\TH:i', $date);

            $dateValide = $dateObjet !== false &&
                $dateObjet->format('Y-m-d\TH:i') === $date;
        }

        if (
            $messageErreur === '' &&
            (!$dateValide || $lieu === '' || $description === '')
        ) {
            $messageErreur =
                "Veuillez renseigner une date, un lieu et une description valides.";
        }

        if (
            $messageErreur === '' &&
            !array_key_exists($gravite, $gravites)
        ) {
            $messageErreur = "Gravité invalide.";
        }

        if (
            $messageErreur === '' &&
            !array_key_exists($statut, $statuts)
        ) {
            $messageErreur = "Statut invalide.";
        }

        /*
         * Vérification de l'agent sélectionné.
         */

        if ($messageErreur === '' && $agentId !== null) {

            $reqAgent = $connexion->prepare(
                "SELECT COUNT(*) FROM agents WHERE id = ?"
            );

            $reqAgent->execute([$agentId]);

            if (!$reqAgent->fetchColumn()) {
                $messageErreur = "L'agent sélectionné est introuvable.";
            }
        }

        /*
         * Enregistrement des preuves et des informations.
         */

        $nouvellePhoto = null;
        $nouvelleVideo = null;

        if ($messageErreur === '') {

            try {

                $nouvellePhoto = enregistrerPreuve(
                    $_FILES['photo_incident'] ?? null,
                    'photo',
                    $dossierPreuves
                );

                $nouvelleVideo = enregistrerPreuve(
                    $_FILES['video_incident'] ?? null,
                    'video',
                    $dossierPreuves
                );

                $photo = $nouvellePhoto ?? $anciennePhoto;
                $video = $nouvelleVideo ?? $ancienneVideo;

                $connexion->beginTransaction();

                if ($id > 0) {

                    /*
                     * MODIFICATION D'UN INCIDENT
                     */

                    $sql = "UPDATE incidents SET
                        agent_id = ?,
                        date_incident = ?,
                        lieu = ?,
                        description = ?,
                        gravite = ?,
                        statut = ?,
                        observations = ?,
                        photo_incident = ?,
                        video_incident = ?
                        WHERE id = ?";

                    $req = $connexion->prepare($sql);

                    $req->execute([
                        $agentId,
                        date('Y-m-d H:i:s', strtotime($date)),
                        $lieu,
                        $description,
                        $gravite,
                        $statut,
                        $observations,
                        $photo,
                        $video,
                        $id
                    ]);

                } else {

                    /*
                     * NOUVEL INCIDENT
                     */

                    $numero = 'INC-' . date('Ymd') . '-' .
                        strtoupper(bin2hex(random_bytes(3)));

                    $utilisateurConnecte = (int)$_SESSION['utilisateur_id'];

                    $sql = "INSERT INTO incidents (
                        numero,
                        agent_id,
                        utilisateur_id,
                        date_incident,
                        lieu,
                        description,
                        gravite,
                        statut,
                        observations,
                        photo_incident,
                        video_incident
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                    $req = $connexion->prepare($sql);

                    $req->execute([
                        $numero,
                        $agentId,
                        $utilisateurConnecte,
                        date('Y-m-d H:i:s', strtotime($date)),
                        $lieu,
                        $description,
                        $gravite,
                        $statut,
                        $observations,
                        $photo,
                        $video
                    ]);

                    /*
                     * NOTIFICATIONS AUTOMATIQUES
                     */

                    $titreNotification = "Nouvel incident signalé";

                    $messageNotification =
                        "Un nouvel incident a été déclaré. " .
                        "Référence : " . $numero .
                        " | Lieu : " . $lieu .
                        " | Gravité : " . $gravites[$gravite] . ".";

                    $lienNotification = "../agents/incidents.php";

                    // Récupérer les autres utilisateurs actifs.
                    $reqUtilisateurs = $connexion->prepare(
                        "SELECT id
                         FROM utilisateurs
                         WHERE statut = 'actif'
                         AND id <> ?"
                    );

                    $reqUtilisateurs->execute([$utilisateurConnecte]);

                    $utilisateurs = $reqUtilisateurs->fetchAll();

                    // Préparer l'insertion des notifications.
                    $reqNotification = $connexion->prepare(
                        "INSERT INTO notifications (
                            utilisateur_id,
                            titre,
                            message,
                            type,
                            lien,
                            est_lue
                        ) VALUES (?, ?, ?, 'Incident', ?, 0)"
                    );

                    foreach ($utilisateurs as $destinataire) {

                        $reqNotification->execute([
                            $destinataire['id'],
                            $titreNotification,
                            $messageNotification,
                            $lienNotification
                        ]);
                    }
                }

                $connexion->commit();

                header('Location: incidents.php?succes=1');
                exit;

            } catch (Throwable $erreur) {

                if ($connexion->inTransaction()) {
                    $connexion->rollBack();
                }

                // Supprimer les nouvelles preuves si l'enregistrement échoue.
                if (
                    $nouvellePhoto &&
                    is_file($dossierPreuves . $nouvellePhoto)
                ) {
                    unlink($dossierPreuves . $nouvellePhoto);
                }

                if (
                    $nouvelleVideo &&
                    is_file($dossierPreuves . $nouvelleVideo)
                ) {
                    unlink($dossierPreuves . $nouvelleVideo);
                }

                $messageErreur = $erreur instanceof RuntimeException
                    ? $erreur->getMessage()
                    : "Une erreur est survenue lors de l'enregistrement.";
            }
        }
    }
}

if (isset($_GET['succes'])) {
    $messageSucces = "L'incident a été enregistré avec succès.";
}

/*
|--------------------------------------------------------------------------
| LISTE DES AGENTS
|--------------------------------------------------------------------------
*/

$reqAgents = $connexion->query(
    "SELECT id, matricule, nom, prenom
     FROM agents
     ORDER BY nom, prenom"
);

$agents = $reqAgents->fetchAll();

/*
|--------------------------------------------------------------------------
| FILTRES DES INCIDENTS
|--------------------------------------------------------------------------
*/

$filtreStatut = (string)($_GET['statut'] ?? '');
$filtreGravite = (string)($_GET['gravite'] ?? '');

$sql = "SELECT
            i.*,
            a.nom AS nom_agent,
            a.prenom AS prenom_agent,
            a.matricule,
            u.nom AS nom_declarant,
            u.prenom AS prenom_declarant
        FROM incidents i
        LEFT JOIN agents a ON a.id = i.agent_id
        LEFT JOIN utilisateurs u ON u.id = i.utilisateur_id
        WHERE 1 = 1";

$params = [];

if (array_key_exists($filtreStatut, $statuts)) {
    $sql .= " AND i.statut = ?";
    $params[] = $filtreStatut;
}

if (array_key_exists($filtreGravite, $gravites)) {
    $sql .= " AND i.gravite = ?";
    $params[] = $filtreGravite;
}

$sql .= " ORDER BY i.date_incident DESC";

$req = $connexion->prepare($sql);
$req->execute($params);

$incidents = $req->fetchAll();

/*
|--------------------------------------------------------------------------
| STATISTIQUES
|--------------------------------------------------------------------------
*/

$total = count($incidents);
$totalNouveaux = 0;
$totalEnCours = 0;
$totalResolus = 0;
$totalCritiques = 0;

foreach ($incidents as $item) {

    if ($item['statut'] === 'nouveau') {
        $totalNouveaux++;
    }

    if ($item['statut'] === 'en_cours') {
        $totalEnCours++;
    }

    if (
        $item['statut'] === 'resolu' ||
        $item['statut'] === 'cloture'
    ) {
        $totalResolus++;
    }

    if ($item['gravite'] === 'critique') {
        $totalCritiques++;
    }
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Gestion des incidents | UASZ</title>

    <link rel="stylesheet"
          href="/gestion_securite_uasz/public/css/incidents.css?v=4">
</head>

<body>

<div class="page-container">

    <header class="page-header">

        <div>
            <span class="sur-titre">GESTION DE LA SÉCURITÉ UASZ</span>

            <h1>Gestion des incidents</h1>

            <p>
                Consultez les incidents signalés sur le campus
                et restez vigilant.
            </p>
        </div>

        <a href="../tableau_de_bord/tableau_de_bord.php"
           class="bouton-retour">
            ← Tableau de bord
        </a>

    </header>

    <?php if ($messageErreur): ?>
        <div class="message erreur">
            <?= e($messageErreur) ?>
        </div>
    <?php endif; ?>

    <?php if ($messageSucces): ?>
        <div class="message succes">
            <?= e($messageSucces) ?>
        </div>
    <?php endif; ?>

    <section class="statistiques">

        <div class="stat-card">
            <span>📋</span>
            <div>
                <p>Total</p>
                <strong><?= $total ?></strong>
            </div>
        </div>

        <div class="stat-card">
            <span>🆕</span>
            <div>
                <p>Nouveaux</p>
                <strong><?= $totalNouveaux ?></strong>
            </div>
        </div>

        <div class="stat-card">
            <span>⏳</span>
            <div>
                <p>En cours</p>
                <strong><?= $totalEnCours ?></strong>
            </div>
        </div>

        <div class="stat-card">
            <span>🚨</span>
            <div>
                <p>Critiques</p>
                <strong><?= $totalCritiques ?></strong>
            </div>
        </div>

    </section>

    <section class="formulaire-section">

        <div class="section-titre">
            <div>

                <h2>
                    <?= $edition ? 'Modifier un incident' : 'Déclarer un incident' ?>
                </h2>

                <p>
                    Renseignez les informations et ajoutez des preuves si disponibles.
                </p>

            </div>
        </div>

        <form method="POST"
              enctype="multipart/form-data"
              class="form-incident">

            <input type="hidden"
                   name="csrf_token"
                   value="<?= e($_SESSION['csrf_incidents']) ?>">

            <input type="hidden"
                   name="id"
                   value="<?= e($incident['id']) ?>">

            <div class="form-grid">

                <div class="champ">

                    <label for="date_incident">Date et heure *</label>

                    <input type="datetime-local"
                           id="date_incident"
                           name="date_incident"
                           value="<?= e($incident['date_incident']) ?>"
                           required>

                </div>

                <div class="champ">

                    <label for="lieu">Lieu de l'incident *</label>

                    <input type="text"
                           id="lieu"
                           name="lieu"
                           maxlength="150"
                           value="<?= e($incident['lieu']) ?>"
                           placeholder="Ex. : Bâtiment pédagogique"
                           required>

                </div>

                <div class="champ">

                    <label for="agent_id">Agent concerné (facultatif)</label>

                    <select id="agent_id" name="agent_id">

                        <option value="">Non renseigné</option>

                        <?php foreach ($agents as $agent): ?>

                            <option value="<?= e($agent['id']) ?>"
                                <?= (string)$incident['agent_id'] === (string)$agent['id'] ? 'selected' : '' ?>>

                                <?= e(
                                    $agent['matricule'] . ' - ' .
                                    $agent['prenom'] . ' ' .
                                    $agent['nom']
                                ) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="champ">

                    <label for="gravite">Niveau de gravité *</label>

                    <select id="gravite" name="gravite" required>

                        <?php foreach ($gravites as $cle => $libelle): ?>

                            <option value="<?= e($cle) ?>"
                                <?= $incident['gravite'] === $cle ? 'selected' : '' ?>>

                                <?= e($libelle) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="champ champ-large">

                    <label for="description">Description de l'incident *</label>

                    <textarea id="description"
                              name="description"
                              rows="4"
                              placeholder="Décrivez précisément les faits..."
                              required><?= e($incident['description']) ?></textarea>

                </div>

                <?php if ($peutGerer): ?>

                    <div class="champ">

                        <label for="statut">État de traitement</label>

                        <select id="statut" name="statut">

                            <?php foreach ($statuts as $cle => $libelle): ?>

                                <option value="<?= e($cle) ?>"
                                    <?= $incident['statut'] === $cle ? 'selected' : '' ?>>

                                    <?= e($libelle) ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <div class="champ">

                        <label for="observations">Observations</label>

                        <textarea id="observations"
                                  name="observations"
                                  rows="3"
                                  placeholder="Informations complémentaires..."><?= e($incident['observations']) ?></textarea>

                    </div>

                <?php endif; ?>

                <div class="champ">

                    <label for="photo_incident">
                        📷 Photo (5 Mo maximum)
                    </label>

                    <input type="file"
                           id="photo_incident"
                           name="photo_incident"
                           accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">

                    <div id="apercu_photo" class="apercu-fichier">

                        <?php if (!empty($incident['photo_incident'])): ?>

                            <a href="voir_preuve_incident.php?id=<?= e($incident['id']) ?>&type=photo"
                               target="_blank"
                               rel="noopener">

                                Voir la photo actuelle

                            </a>

                        <?php endif; ?>

                    </div>

                </div>

                <div class="champ">

                    <label for="video_incident">
                        🎥 Vidéo (30 Mo maximum)
                    </label>

                    <input type="file"
                           id="video_incident"
                           name="video_incident"
                           accept=".mp4,.webm,video/mp4,video/webm">

                    <div id="apercu_video" class="apercu-fichier">

                        <?php if (!empty($incident['video_incident'])): ?>

                            <a href="voir_preuve_incident.php?id=<?= e($incident['id']) ?>&type=video"
                               target="_blank"
                               rel="noopener">

                                Voir la vidéo actuelle

                            </a>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

            <div class="form-actions">

                <?php if ($edition): ?>

                    <a href="incidents.php" class="bouton-annuler">
                        Annuler
                    </a>

                <?php endif; ?>

                <button type="submit" class="bouton-principal">

                    <?= $edition
                        ? 'Enregistrer les modifications'
                        : 'Déclarer l’incident' ?>

                </button>

            </div>

        </form>

    </section>

    <section class="liste-section">

        <div class="section-titre">

            <div>

                <h2>Historique des incidents</h2>

                <p>
                    Tous les utilisateurs connectés peuvent consulter
                    les déclarations et leurs preuves.
                </p>

            </div>

            <span class="compteur">
                <?= $total ?> incident(s)
            </span>

        </div>

        <form method="GET" class="filtres">

            <div class="champ">

                <label for="filtre_statut">État</label>

                <select name="statut" id="filtre_statut">

                    <option value="">Tous les états</option>

                    <?php foreach ($statuts as $cle => $libelle): ?>

                        <option value="<?= e($cle) ?>"
                            <?= $filtreStatut === $cle ? 'selected' : '' ?>>

                            <?= e($libelle) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div class="champ">

                <label for="filtre_gravite">Gravité</label>

                <select name="gravite" id="filtre_gravite">

                    <option value="">Toutes les gravités</option>

                    <?php foreach ($gravites as $cle => $libelle): ?>

                        <option value="<?= e($cle) ?>"
                            <?= $filtreGravite === $cle ? 'selected' : '' ?>>

                            <?= e($libelle) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <button class="bouton-filtrer" type="submit">
                Filtrer
            </button>

            <a href="incidents.php" class="bouton-reinitialiser">
                Réinitialiser
            </a>

        </form>

        <?php if (!$incidents): ?>

            <div class="vide">

                <div>🛡️</div>

                <h3>Aucun incident enregistré</h3>

                <p>Les déclarations apparaîtront ici.</p>

            </div>

        <?php else: ?>

            <div class="table-responsive">

                <table>

                    <thead>

                        <tr>
                            <th>Référence</th>
                            <th>Date</th>
                            <th>Lieu</th>
                            <th>Déclarant / Agent</th>
                            <th>Gravité</th>
                            <th>État</th>
                            <th>Preuves</th>

                            <?php if ($peutGerer): ?>
                                <th>Action</th>
                            <?php endif; ?>
                        </tr>

                    </thead>

                    <tbody>

                    <?php foreach ($incidents as $item): ?>

                        <tr>

                            <td>
                                <strong><?= e($item['numero']) ?></strong>
                            </td>

                            <td>
                                <?= e(date(
                                    'd/m/Y H:i',
                                    strtotime($item['date_incident'])
                                )) ?>
                            </td>

                            <td>
                                <?= e($item['lieu']) ?>
                            </td>

                            <td>

                                <?= e(
                                    trim(
                                        ($item['prenom_declarant'] ?? '') . ' ' .
                                        ($item['nom_declarant'] ?? '')
                                    ) ?: 'Déclarant inconnu'
                                ) ?>

                                <br>

                                <small>
                                    Agent :
                                    <?= $item['nom_agent']
                                        ? e($item['prenom_agent'] . ' ' . $item['nom_agent'])
                                        : 'Non renseigné' ?>
                                </small>

                            </td>

                            <td>

                                <span class="badge-gravite gravite-<?= e($item['gravite']) ?>">

                                    <?= e($gravites[$item['gravite']]) ?>

                                </span>

                            </td>

                            <td>

                                <span class="badge-statut statut-<?= e($item['statut']) ?>">

                                    <?= e($statuts[$item['statut']]) ?>

                                </span>

                            </td>

                            <td class="preuves">

                                <?php if ($item['photo_incident']): ?>

                                    <a target="_blank"
                                       rel="noopener"
                                       href="voir_preuve_incident.php?id=<?= e($item['id']) ?>&type=photo">

                                        📷 Photo

                                    </a>

                                <?php endif; ?>

                                <?php if ($item['video_incident']): ?>

                                    <a target="_blank"
                                       rel="noopener"
                                       href="voir_preuve_incident.php?id=<?= e($item['id']) ?>&type=video">

                                        🎥 Vidéo

                                    </a>

                                <?php endif; ?>

                                <?php if (
                                    !$item['photo_incident'] &&
                                    !$item['video_incident']
                                ): ?>

                                    —

                                <?php endif; ?>

                            </td>

                            <?php if ($peutGerer): ?>

                                <td>

                                    <a class="bouton-modifier"
                                       href="incidents.php?modifier=<?= e($item['id']) ?>">

                                        Modifier

                                    </a>

                                </td>

                            <?php endif; ?>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </section>

</div>

<script src="/gestion_securite_uasz/public/js/incidents.js?v=4"></script>

</body>
</html>
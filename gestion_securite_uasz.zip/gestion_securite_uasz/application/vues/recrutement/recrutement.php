
<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';

exigerAcces('recrutement');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$jetonCSRF = $_SESSION['jeton_recrutement'] ?? bin2hex(random_bytes(32));
$_SESSION['jeton_recrutement'] = $jetonCSRF;

$racineProjet = dirname(__DIR__, 3);
$dossierRecrutement = $racineProjet . '/stockage/recrutement';

if (!is_dir($dossierRecrutement)) {
    mkdir($dossierRecrutement, 0755, true);
}

function reponseRecrutement($succes, $message, $donnees = [])
{
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'succes' => $succes,
        'message' => $message,
        'donnees' => $donnees
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

function nettoyerRecrutement($valeur)
{
    return trim((string)($valeur ?? ''));
}

function televerserDocument($champ, $type, $dossier)
{
    if (!isset($_FILES[$champ]) || $_FILES[$champ]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    $fichier = $_FILES[$champ];

    if ($fichier['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException("Erreur lors de l'envoi du fichier.");
    }

    $limite = ($type === 'cv') ? 5 * 1024 * 1024 : 3 * 1024 * 1024;

    if ($fichier['size'] > $limite) {
        throw new RuntimeException(
            $type === 'cv'
                ? 'Le CV ne doit pas dépasser 5 Mo.'
                : 'La photo ne doit pas dépasser 3 Mo.'
        );
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($fichier['tmp_name']);

    $extensionsAutorisees = $type === 'cv'
        ? ['application/pdf' => 'pdf']
        : [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp'
        ];

    if (!isset($extensionsAutorisees[$mime])) {
        throw new RuntimeException(
            $type === 'cv'
                ? 'Le CV doit être au format PDF.'
                : 'La photo doit être au format JPG, PNG ou WEBP.'
        );
    }

    $nomFichier = $type . '_' . bin2hex(random_bytes(12))
        . '.' . $extensionsAutorisees[$mime];

    $destination = $dossier . '/' . $nomFichier;

    if (!move_uploaded_file($fichier['tmp_name'], $destination)) {
        throw new RuntimeException("Impossible d'enregistrer le fichier.");
    }

    return 'stockage/recrutement/' . $nomFichier;
}

function enregistrerHistoriqueCandidature(
    PDO $connexion,
    array $candidat,
    $action,
    $ancienStatut = null,
    $nouveauStatut = null
) {
    $requete = $connexion->prepare("
        INSERT INTO historique_candidatures (
            candidature_id,
            utilisateur_id,
            reference,
            nom,
            prenom,
            telephone,
            email,
            poste,
            date_candidature,
            ancien_statut,
            nouveau_statut,
            observation,
            action
        ) VALUES (
            :candidature_id,
            :utilisateur_id,
            :reference,
            :nom,
            :prenom,
            :telephone,
            :email,
            :poste,
            :date_candidature,
            :ancien_statut,
            :nouveau_statut,
            :observation,
            :action
        )
    ");

    $requete->execute([
        ':candidature_id' => $candidat['id'] ?? null,
        ':utilisateur_id' => $_SESSION['utilisateur_id'] ?? null,
        ':reference' => $candidat['reference'],
        ':nom' => $candidat['nom'],
        ':prenom' => $candidat['prenom'],
        ':telephone' => $candidat['telephone'],
        ':email' => $candidat['email'],
        ':poste' => $candidat['poste'],
        ':date_candidature' => $candidat['date_candidature'],
        ':ancien_statut' => $ancienStatut,
        ':nouveau_statut' => $nouveauStatut,
        ':observation' => $candidat['observation'],
        ':action' => $action
    ]);
}

function notifierNouvelleCandidature(PDO $connexion, array $candidat)
{
    $requete = $connexion->query("
        SELECT DISTINCT u.id
        FROM utilisateurs u
        LEFT JOIN utilisateur_modules um
            ON um.utilisateur_id = u.id
        LEFT JOIN modules m
            ON m.id = um.module_id
        WHERE u.statut = 'actif'
        AND (
            u.role = 'administrateur'
            OR m.code = 'notifications'
        )
    ");

    $destinataires = $requete->fetchAll(PDO::FETCH_COLUMN);

    $notification = $connexion->prepare("
        INSERT INTO notifications (
            utilisateur_id,
            titre,
            message,
            type,
            lien
        ) VALUES (
            :utilisateur_id,
            :titre,
            :message,
            'Recrutement',
            :lien
        )
    ");

    foreach ($destinataires as $destinataire) {
        if ((int)$destinataire === (int)($_SESSION['utilisateur_id'] ?? 0)) {
            continue;
        }

        $notification->execute([
            ':utilisateur_id' => $destinataire,
            ':titre' => 'Nouvelle candidature',
            ':message' => 'Une nouvelle candidature a été enregistrée : '
                . $candidat['reference'] . ' - '
                . $candidat['prenom'] . ' ' . $candidat['nom'],
            ':lien' => '../recrutement/recrutement.php'
        ]);
    }
}

/* =========================================
   TRAITEMENT DES REQUÊTES AJAX
========================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $jetonRecu = $_POST['jeton_csrf'] ?? '';

    if (!hash_equals($jetonCSRF, $jetonRecu)) {
        reponseRecrutement(false, 'Votre session a expiré. Actualisez la page.');
    }

    $action = $_POST['action'] ?? '';

    try {

        /* LISTE DES CANDIDATURES */
        if ($action === 'lister') {

            $requete = $connexion->query("
                SELECT *
                FROM candidatures
                ORDER BY date_creation DESC, id DESC
            ");

            reponseRecrutement(
                true,
                'Candidatures récupérées.',
                $requete->fetchAll()
            );
        }

        /* AJOUTER UNE CANDIDATURE */
        if ($action === 'ajouter') {

            $nom = nettoyerRecrutement($_POST['nom'] ?? '');
            $prenom = nettoyerRecrutement($_POST['prenom'] ?? '');
            $telephone = nettoyerRecrutement($_POST['telephone'] ?? '');
            $email = nettoyerRecrutement($_POST['email'] ?? '');
            $poste = nettoyerRecrutement($_POST['poste'] ?? '');
            $date = nettoyerRecrutement($_POST['date'] ?? '');
            $statut = nettoyerRecrutement($_POST['statut'] ?? 'En attente');
            $observation = nettoyerRecrutement($_POST['observation'] ?? '');

            if (!$nom || !$prenom || !$telephone || !$poste || !$date) {
                reponseRecrutement(false, 'Veuillez remplir les champs obligatoires.');
            }

            $postesAutorises = [
                'Agent de sécurité',
                "Chef d'équipe",
                'Superviseur'
            ];

            $statutsAutorises = ['En attente', 'Acceptée', 'Refusée'];

            $dateValide = DateTime::createFromFormat('!Y-m-d', $date);

            if (
                !in_array($poste, $postesAutorises, true)
                || !in_array($statut, $statutsAutorises, true)
                || !$dateValide
                || $dateValide->format('Y-m-d') !== $date
            ) {
                reponseRecrutement(false, 'Certaines informations sont invalides.');
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL) && $email !== '') {
                reponseRecrutement(false, 'Adresse e-mail invalide.');
            }

            if (
                mb_strlen($nom) > 100
                || mb_strlen($prenom) > 100
                || mb_strlen($telephone) > 30
                || mb_strlen($email) > 150
            ) {
                reponseRecrutement(false, 'Certains champs sont trop longs.');
            }

            $fichiersCrees = [];

            try {
                $cv = televerserDocument('cv', 'cv', $dossierRecrutement);
                if ($cv) $fichiersCrees[] = $cv;

                $photo = televerserDocument('photo', 'photo', $dossierRecrutement);
                if ($photo) $fichiersCrees[] = $photo;

                $connexion->beginTransaction();

                $reference = 'CAN-' . date('Ymd') . '-'
                    . strtoupper(bin2hex(random_bytes(3)));

                $requete = $connexion->prepare("
                    INSERT INTO candidatures (
                        reference,
                        nom,
                        prenom,
                        telephone,
                        email,
                        poste,
                        date_candidature,
                        statut,
                        observation,
                        cv,
                        photo,
                        utilisateur_id
                    ) VALUES (
                        :reference,
                        :nom,
                        :prenom,
                        :telephone,
                        :email,
                        :poste,
                        :date,
                        :statut,
                        :observation,
                        :cv,
                        :photo,
                        :utilisateur_id
                    )
                ");

                $requete->execute([
                    ':reference' => $reference,
                    ':nom' => $nom,
                    ':prenom' => $prenom,
                    ':telephone' => $telephone,
                    ':email' => $email ?: null,
                    ':poste' => $poste,
                    ':date' => $date,
                    ':statut' => $statut,
                    ':observation' => $observation ?: null,
                    ':cv' => $cv,
                    ':photo' => $photo,
                    ':utilisateur_id' => $_SESSION['utilisateur_id'] ?? null
                ]);

                $id = (int)$connexion->lastInsertId();

                $candidat = [
                    'id' => $id,
                    'reference' => $reference,
                    'nom' => $nom,
                    'prenom' => $prenom,
                    'telephone' => $telephone,
                    'email' => $email ?: null,
                    'poste' => $poste,
                    'date_candidature' => $date,
                    'observation' => $observation ?: null
                ];

                enregistrerHistoriqueCandidature(
                    $connexion,
                    $candidat,
                    'creation',
                    null,
                    $statut
                );

                notifierNouvelleCandidature($connexion, $candidat);

                $connexion->commit();

                reponseRecrutement(true, 'Candidature enregistrée avec succès.');
            } catch (Throwable $erreur) {
                if ($connexion->inTransaction()) {
                    $connexion->rollBack();
                }

                foreach ($fichiersCrees as $chemin) {
                    $fichier = $racineProjet . '/' . $chemin;
                    if (is_file($fichier)) unlink($fichier);
                }

                throw $erreur;
            }
        }

        /* MODIFIER UNE CANDIDATURE */
        if ($action === 'modifier') {

            $id = (int)($_POST['id'] ?? 0);

            $requete = $connexion->prepare("
                SELECT * FROM candidatures WHERE id = ?
            ");
            $requete->execute([$id]);
            $ancien = $requete->fetch();

            if (!$ancien) {
                reponseRecrutement(false, 'Candidature introuvable.');
            }

            $nom = nettoyerRecrutement($_POST['nom'] ?? '');
            $prenom = nettoyerRecrutement($_POST['prenom'] ?? '');
            $telephone = nettoyerRecrutement($_POST['telephone'] ?? '');
            $email = nettoyerRecrutement($_POST['email'] ?? '');
            $poste = nettoyerRecrutement($_POST['poste'] ?? '');
            $date = nettoyerRecrutement($_POST['date'] ?? '');
            $statut = nettoyerRecrutement($_POST['statut'] ?? '');
            $observation = nettoyerRecrutement($_POST['observation'] ?? '');

            $postesAutorises = [
                'Agent de sécurité',
                "Chef d'équipe",
                'Superviseur'
            ];

            $statutsAutorises = ['En attente', 'Acceptée', 'Refusée'];
            $dateValide = DateTime::createFromFormat('!Y-m-d', $date);

            if (
                !$nom || !$prenom || !$telephone || !$dateValide
                || $dateValide->format('Y-m-d') !== $date
                || !in_array($poste, $postesAutorises, true)
                || !in_array($statut, $statutsAutorises, true)
                || ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL))
            ) {
                reponseRecrutement(false, 'Informations invalides ou incomplètes.');
            }

            $fichiersCrees = [];

            try {
                $cv = televerserDocument('cv', 'cv', $dossierRecrutement);
                if ($cv) $fichiersCrees[] = $cv;
                else $cv = $ancien['cv'];

                $photo = televerserDocument('photo', 'photo', $dossierRecrutement);
                if ($photo) $fichiersCrees[] = $photo;
                else $photo = $ancien['photo'];

                $connexion->beginTransaction();

                $requete = $connexion->prepare("
                    UPDATE candidatures SET
                        nom = :nom,
                        prenom = :prenom,
                        telephone = :telephone,
                        email = :email,
                        poste = :poste,
                        date_candidature = :date,
                        statut = :statut,
                        observation = :observation,
                        cv = :cv,
                        photo = :photo
                    WHERE id = :id
                ");

                $requete->execute([
                    ':nom' => $nom,
                    ':prenom' => $prenom,
                    ':telephone' => $telephone,
                    ':email' => $email ?: null,
                    ':poste' => $poste,
                    ':date' => $date,
                    ':statut' => $statut,
                    ':observation' => $observation ?: null,
                    ':cv' => $cv,
                    ':photo' => $photo,
                    ':id' => $id
                ]);

                $candidat = [
                    'id' => $id,
                    'reference' => $ancien['reference'],
                    'nom' => $nom,
                    'prenom' => $prenom,
                    'telephone' => $telephone,
                    'email' => $email ?: null,
                    'poste' => $poste,
                    'date_candidature' => $date,
                    'observation' => $observation ?: null
                ];

                enregistrerHistoriqueCandidature(
                    $connexion,
                    $candidat,
                    'modification',
                    $ancien['statut'],
                    $statut
                );

                $connexion->commit();

                reponseRecrutement(true, 'Candidature modifiée avec succès.');
            } catch (Throwable $erreur) {
                if ($connexion->inTransaction()) {
                    $connexion->rollBack();
                }

                foreach ($fichiersCrees as $chemin) {
                    $fichier = $racineProjet . '/' . $chemin;
                    if (is_file($fichier)) unlink($fichier);
                }

                throw $erreur;
            }
        }

        /* SUPPRIMER UNE CANDIDATURE */
        if ($action === 'supprimer') {

            $id = (int)($_POST['id'] ?? 0);

            $requete = $connexion->prepare("
                SELECT * FROM candidatures WHERE id = ?
            ");
            $requete->execute([$id]);
            $candidat = $requete->fetch();

            if (!$candidat) {
                reponseRecrutement(false, 'Candidature introuvable.');
            }

            $connexion->beginTransaction();

            enregistrerHistoriqueCandidature(
                $connexion,
                $candidat,
                'suppression',
                $candidat['statut'],
                null
            );

            $requete = $connexion->prepare("
                DELETE FROM candidatures WHERE id = ?
            ");
            $requete->execute([$id]);

            $connexion->commit();

            reponseRecrutement(true, 'Candidature supprimée avec succès.');
        }

        reponseRecrutement(false, 'Action inconnue.');

    } catch (Throwable $erreur) {
        error_log('Recrutement : ' . $erreur->getMessage());

        reponseRecrutement(
            false,
            'Une erreur est survenue. Vérifiez les données et la base de données.'
        );
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion du recrutement | Gestion Sécurité UASZ</title>
    <link rel="stylesheet" href="../../../public/css/recrutement.css">
</head>
<body>

<div class="page-container">

    <aside class="sidebar">
        <div class="logo">
            <div class="logo-icon">U</div>
            <div>
                <h2>Gestion Sécurité</h2>
                <span>UASZ</span>
            </div>
        </div>

        <div class="sidebar-user">
            <div class="user-avatar">AD</div>
            <div>
                <strong>Administration</strong>
                <small>Gestion Sécurité</small>
            </div>
        </div>

        <nav class="navigation">
            <p class="nav-title">MENU PRINCIPAL</p>

            <a href="../tableau_de_bord/tableau_de_bord.php"><span>▦</span> Tableau de bord</a>
            <a href="../utilisateurs/utilisateurs.php"><span>♙</span> Utilisateurs</a>
            <a href="../agents/agents.php"><span>♟</span> Agents</a>
            <a href="../agents/presences.php"><span>◷</span> Présences</a>
            <a href="../agents/plannings.php"><span>▤</span> Plannings</a>
            <a href="../affectations/affectations.php"><span>⌖</span> Affectations</a>
            <a href="recrutement.php" class="active"><span>♧</span> Recrutement</a>
            <a href="../agents/incidents.php"><span>⚠</span> Incidents</a>
            <a href="../demandes/demandes.php"><span>✉</span> Demandes</a>
            <a href="../rapports/rapports.php">Rapports et statistiques</a>
            <a href="../profil/profil.php">Mon profil</a>
            <a href="../notifications/notifications.php">Notifications</a>
        </nav>

        <div class="sidebar-bottom">
            <a href="../authentification/connexion.php" id="deconnexion">
                <span>⇥</span> Déconnexion
            </a>
        </div>
    </aside>

    <main class="main-content">

        <header class="topbar">
            <div>
                <h1>Gestion du recrutement</h1>
                <p>Suivez les candidatures des futurs agents de sécurité.</p>
            </div>

            <div class="topbar-right">
                <span id="dateActuelle" class="date-today"></span>
                <div class="top-avatar">AD</div>
            </div>
        </header>

        <section class="content">

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon blue">♙</div>
                    <div><p>Total des candidatures</p><h2 id="totalCandidatures">0</h2></div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon orange">◷</div>
                    <div><p>En attente</p><h2 id="candidaturesAttente">0</h2></div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon green">✓</div>
                    <div><p>Acceptées</p><h2 id="candidaturesAcceptees">0</h2></div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon red">×</div>
                    <div><p>Refusées</p><h2 id="candidaturesRefusees">0</h2></div>
                </div>
            </div>

            <section class="table-card">

                <div class="section-header">
                    <div>
                        <h2>Liste des candidatures</h2>
                        <p>Consultez et gérez les dossiers des candidats.</p>
                    </div>

                    <button class="btn-primary" id="ouvrirModal">
                        + Nouvelle candidature
                    </button>
                </div>

                <div class="filters">
                    <div class="search-box">
                        <span>⌕</span>
                        <input type="search" id="rechercheCandidat"
                            placeholder="Rechercher un candidat...">
                    </div>

                    <select id="filtreStatut">
                        <option value="">Tous les statuts</option>
                        <option value="En attente">En attente</option>
                        <option value="Acceptée">Acceptées</option>
                        <option value="Refusée">Refusées</option>
                    </select>

                    <select id="filtrePoste">
                        <option value="">Tous les postes</option>
                        <option value="Agent de sécurité">Agent de sécurité</option>
                        <option value="Chef d'équipe">Chef d'équipe</option>
                        <option value="Superviseur">Superviseur</option>
                    </select>
                </div>

                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Référence</th>
                                <th>Nom complet</th>
                                <th>Téléphone</th>
                                <th>Poste demandé</th>
                                <th>Date de candidature</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="tableauCandidatures">
                            <tr><td colspan="7">Chargement des candidatures...</td></tr>
                        </tbody>
                    </table>
                </div>

                <div class="table-footer">
                    <span id="nombreResultats">0 candidature(s)</span>
                </div>

            </section>
        </section>
    </main>
</div>

<div class="modal-overlay" id="modalCandidature">
    <div class="modal">

        <div class="modal-header">
            <div>
                <h2 id="titreModal">Nouvelle candidature</h2>
                <p>Renseignez les informations du candidat.</p>
            </div>
            <button type="button" class="close-modal" id="fermerModal">×</button>
        </div>

        <form id="formulaireCandidature" enctype="multipart/form-data">
            <input type="hidden" name="jeton_csrf" value="<?= htmlspecialchars($jetonCSRF, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" id="idCandidature" name="id">

            <div class="form-row">
                <div class="form-group">
                    <label for="nom">Nom *</label>
                    <input type="text" id="nom" name="nom" maxlength="100" required>
                </div>

                <div class="form-group">
                    <label for="prenom">Prénom *</label>
                    <input type="text" id="prenom" name="prenom" maxlength="100" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="telephone">Téléphone *</label>
                    <input type="tel" id="telephone" name="telephone" maxlength="30"
                        placeholder="Ex. : 77 000 00 00" required>
                </div>

                <div class="form-group">
                    <label for="email">Adresse e-mail</label>
                    <input type="email" id="email" name="email"
                        placeholder="candidat@email.com">
                </div>
            </div>

            <div class="form-group">
                <label for="poste">Poste demandé *</label>
                <select id="poste" name="poste" required>
                    <option value="">Sélectionner un poste</option>
                    <option value="Agent de sécurité">Agent de sécurité</option>
                    <option value="Chef d'équipe">Chef d'équipe</option>
                    <option value="Superviseur">Superviseur</option>
                </select>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="dateCandidature">Date de candidature *</label>
                    <input type="date" id="dateCandidature" name="date" required>
                </div>

                <div class="form-group">
                    <label for="statut">Statut *</label>
                    <select id="statut" name="statut" required>
                        <option value="En attente">En attente</option>
                        <option value="Acceptée">Acceptée</option>
                        <option value="Refusée">Refusée</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="cv">CV du candidat (PDF, 5 Mo maximum)</label>
                <input type="file" id="cv" name="cv" accept=".pdf,application/pdf">
                <small id="nomCV"></small>
            </div>

            <div class="form-group">
                <label for="photo">Photo du candidat (JPG, PNG ou WEBP, 3 Mo maximum)</label>
                <input type="file" id="photo" name="photo" accept="image/jpeg,image/png,image/webp">
                <small id="nomPhoto"></small>
            </div>

            <div class="form-group">
                <label for="observation">Observations</label>
                <textarea id="observation" name="observation" rows="3"
                    placeholder="Informations complémentaires sur le candidat..."></textarea>
            </div>

            <div class="modal-actions">
                <button type="button" class="btn-cancel" id="annulerModal">Annuler</button>
                <button type="submit" class="btn-primary" id="boutonEnregistrer">
                    Enregistrer la candidature
                </button>
            </div>
        </form>
    </div>
</div>

<div class="modal-overlay" id="modalDetails">
    <div class="modal details-modal">
        <div class="modal-header">
            <div>
                <h2>Détails de la candidature</h2>
                <p>Informations du dossier du candidat.</p>
            </div>
            <button type="button" class="close-modal" id="fermerDetails">×</button>
        </div>
        <div id="contenuDetails" class="details-content"></div>
    </div>
</div>

<script src="../../../public/js/recrutement.js?v=2"></script>
</body>
</html>

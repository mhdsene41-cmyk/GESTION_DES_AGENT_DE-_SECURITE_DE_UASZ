
<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';

exigerAcces('notifications');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$utilisateurId = (int) ($_SESSION['utilisateur_id'] ?? 0);

if ($utilisateurId <= 0) {
    header('Location: ../authentification/connexion.php');
    exit;
}

function nettoyer($valeur): string
{
    return htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
}

// Protection CSRF
if (empty($_SESSION['csrf_notifications'])) {
    $_SESSION['csrf_notifications'] = bin2hex(random_bytes(32));
}

$csrf = $_SESSION['csrf_notifications'];

// Traitement des actions AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    $jeton = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';

    if (!hash_equals($csrf, $jeton)) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Jeton de sécurité invalide.'
        ]);
        exit;
    }

    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'marquer_lue') {
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

            if (!$id || $id <= 0) {
                throw new Exception('Notification invalide.');
            }

            $requete = $connexion->prepare(
                "UPDATE notifications
                 SET est_lue = 1
                 WHERE id = :id AND utilisateur_id = :utilisateur_id"
            );

            $requete->execute([
                'id' => $id,
                'utilisateur_id' => $utilisateurId
            ]);

            echo json_encode([
                'success' => true,
                'message' => 'Notification marquée comme lue.'
            ]);
            exit;
        }

        if ($action === 'tout_marquer_lu') {
            $requete = $connexion->prepare(
                "UPDATE notifications
                 SET est_lue = 1
                 WHERE utilisateur_id = :utilisateur_id
                   AND est_lue = 0"
            );

            $requete->execute([
                'utilisateur_id' => $utilisateurId
            ]);

            echo json_encode([
                'success' => true,
                'message' => 'Toutes les notifications ont été marquées comme lues.'
            ]);
            exit;
        }

        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Action non reconnue.'
        ]);
        exit;

    } catch (Throwable $erreur) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Une erreur est survenue pendant le traitement.'
        ]);
        exit;
    }
}

// Informations de l'utilisateur connecté
$requeteUtilisateur = $connexion->prepare(
    "SELECT nom, prenom, role
     FROM utilisateurs
     WHERE id = ?"
);
$requeteUtilisateur->execute([$utilisateurId]);
$utilisateur = $requeteUtilisateur->fetch();

if (!$utilisateur) {
    die('Utilisateur introuvable.');
}

// Statistiques des notifications
$requeteStats = $connexion->prepare(
    "SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN est_lue = 0 THEN 1 ELSE 0 END) AS non_lues,
        SUM(CASE WHEN est_lue = 1 THEN 1 ELSE 0 END) AS lues
     FROM notifications
     WHERE utilisateur_id = ?"
);
$requeteStats->execute([$utilisateurId]);
$stats = $requeteStats->fetch();

// Liste des notifications de l'utilisateur connecté
$requeteNotifications = $connexion->prepare(
    "SELECT id, titre, message, type, lien, est_lue, date_creation
     FROM notifications
     WHERE utilisateur_id = ?
     ORDER BY date_creation DESC"
);
$requeteNotifications->execute([$utilisateurId]);
$notifications = $requeteNotifications->fetchAll();

$total = (int) ($stats['total'] ?? 0);
$nonLues = (int) ($stats['non_lues'] ?? 0);
$lues = (int) ($stats['lues'] ?? 0);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Notifications | Gestion Sécurité UASZ</title>

    <link rel="stylesheet" href="../../../public/css/notifications.css">
</head>

<body>

<div class="page-container">

    <aside class="sidebar">

        <div class="logo">
            <h2>UASZ</h2>
            <p>Gestion Sécurité</p>
        </div>

        <nav class="menu">
            <a href="../tableau_de_bord/tableau_de_bord.php">Tableau de bord</a>
            <a href="../utilisateurs/utilisateurs.php">Utilisateurs</a>
            <a href="../agents/agents.php">Agents</a>
            <a href="../agents/presences.php">Présences</a>
            <a href="../agents/plannings.php">Plannings</a>
            <a href="../agents/incidents.php">Incidents</a>
            <a href="../demandes/demandes.php">Demandes</a>
            <a href="../affectations/affectations.php">Affectations</a>
            <a href="../recrutement/recrutement.php">Recrutement</a>
            <a href="../carrieres/carrieres.php">Carrières</a>
            <a href="../rapports/rapports.php">Rapports et statistiques</a>
            <a href="../profil/profil.php">Mon profil</a>
            <a href="notifications.php" class="active">Notifications</a>
        </nav>

        <a href="../authentification/connexion.php" class="logout">
            Déconnexion
        </a>

    </aside>

    <main class="main-content">

        <header class="topbar">
            <div>
                <h1>Centre de notifications</h1>
                <p>Consultez les alertes et les informations importantes.</p>
            </div>

            <div class="user-info">
                <div class="avatar">
                    <?= nettoyer(mb_substr($utilisateur['prenom'] ?? 'U', 0, 1)) ?>
                    <?= nettoyer(mb_substr($utilisateur['nom'] ?? '', 0, 1)) ?>
                </div>

                <div>
                    <strong>
                        <?= nettoyer(($utilisateur['prenom'] ?? '') . ' ' . ($utilisateur['nom'] ?? '')) ?>
                    </strong>
                    <small><?= nettoyer($utilisateur['role'] ?? '') ?></small>
                </div>
            </div>
        </header>

        <section class="welcome-section">
            <div>
                <h2>Vos notifications</h2>
                <p>Retrouvez ici les informations liées à vos activités sur la plateforme.</p>
            </div>
            <div class="welcome-icon">🔔</div>
        </section>

        <section class="stats-container">

            <div class="stat-card">
                <div class="stat-icon orange">🔔</div>
                <div>
                    <p>Total des notifications</p>
                    <h2 id="totalNotifications"><?= $total ?></h2>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon red">📩</div>
                <div>
                    <p>Non lues</p>
                    <h2 id="notificationsNonLues"><?= $nonLues ?></h2>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon green">✓</div>
                <div>
                    <p>Notifications lues</p>
                    <h2 id="notificationsLues"><?= $lues ?></h2>
                </div>
            </div>

        </section>

        <section class="notifications-section">

            <div class="section-header">
                <div>
                    <h2>Historique des notifications</h2>
                    <p>Suivez les dernières activités de la plateforme.</p>
                </div>

                <button
                    type="button"
                    id="toutMarquerLu"
                    class="btn-primary"
                    <?= $nonLues === 0 ? 'disabled' : '' ?>
                >
                    ✓ Tout marquer comme lu
                </button>
            </div>

            <div class="filters">

                <input
                    type="search"
                    id="rechercheNotification"
                    placeholder="Rechercher une notification..."
                    aria-label="Rechercher une notification"
                >

                <select id="filtreType" aria-label="Filtrer par type">
                    <option value="">Tous les types</option>
                    <option value="Demande">Demandes</option>
                    <option value="Incident">Incidents</option>
                    <option value="Présence">Présences</option>
                    <option value="Planning">Plannings</option>
                    <option value="Système">Système</option>
                </select>

                <select id="filtreStatut" aria-label="Filtrer par statut">
                    <option value="">Tous les statuts</option>
                    <option value="0">Non lues</option>
                    <option value="1">Lues</option>
                </select>

            </div>

            <div id="listeNotifications" class="notification-list">

                <?php foreach ($notifications as $notification): ?>

                    <?php
                    $type = $notification['type'];
                    $icone = [
                        'Demande' => '📋',
                        'Incident' => '🚨',
                        'Présence' => '🕒',
                        'Planning' => '📅',
                        'Système' => '⚙️'
                    ][$type] ?? '🔔';

                    $date = date(
                        'd/m/Y à H:i',
                        strtotime($notification['date_creation'])
                    );
                    ?>

                    <article
                        class="notification-card <?= $notification['est_lue'] ? 'lue' : 'non-lue' ?>"
                        data-id="<?= (int) $notification['id'] ?>"
                        data-type="<?= nettoyer($type) ?>"
                        data-statut="<?= (int) $notification['est_lue'] ?>"
                    >

                        <div class="notification-icon">
                            <?= $icone ?>
                        </div>

                        <div class="notification-content">

                            <div class="notification-heading">
                                <h3><?= nettoyer($notification['titre']) ?></h3>

                                <span class="badge-type">
                                    <?= nettoyer($type) ?>
                                </span>
                            </div>

                            <p><?= nl2br(nettoyer($notification['message'])) ?></p>

                            <div class="notification-footer">
                                <span class="notification-date">
                                    🕒 <?= nettoyer($date) ?>
                                </span>

                                <span class="badge-statut">
                                    <?= $notification['est_lue'] ? 'Lue' : 'Non lue' ?>
                                </span>
                            </div>

                            <div class="notification-actions">

                                <?php if (!empty($notification['lien'])): ?>
                                    <a
                                        class="btn-link"
                                        href="<?= nettoyer($notification['lien']) ?>"
                                    >
                                        Consulter
                                    </a>
                                <?php endif; ?>

                                <?php if (!$notification['est_lue']): ?>
                                    <button type="button" class="btn-read">
                                        Marquer comme lue
                                    </button>
                                <?php endif; ?>

                            </div>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

            <div id="messageVide" class="empty-message" <?= $total > 0 ? 'hidden' : '' ?>>
                <span>🔔</span>
                <h3>Aucune notification</h3>
                <p>Vous n'avez pas encore reçu de notification.</p>
            </div>

            <div id="messageFiltreVide" class="empty-message" hidden>
                <span>🔎</span>
                <h3>Aucun résultat</h3>
                <p>Aucune notification ne correspond à votre recherche.</p>
            </div>

        </section>

        <footer>
            © 2026 Gestion Sécurité UASZ - Tous droits réservés.
        </footer>

    </main>

</div>

<script>
    window.NOTIFICATIONS_CONFIG = {
        csrf: <?= json_encode($csrf) ?>,
        endpoint: 'notifications.php'
    };
</script>

<script src="../../../public/js/notifications.js"></script>

</body>
</html>

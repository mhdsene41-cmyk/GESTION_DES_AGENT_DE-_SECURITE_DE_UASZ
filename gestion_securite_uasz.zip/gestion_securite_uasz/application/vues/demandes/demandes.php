
<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';

exigerAcces('demandes');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$utilisateurConnecte = (int) ($_SESSION['utilisateur_id'] ?? 0);

if ($utilisateurConnecte <= 0) {
    http_response_code(401);
    exit('Session utilisateur invalide.');
}

if (!isset($_SESSION['csrf_demandes'])) {
    $_SESSION['csrf_demandes'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_demandes'];

/**
 * Réponse JSON pour les appels JavaScript.
 */
function repondreJSON($succes, $message = '', $donnees = [])
{
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'succes' => $succes,
        'message' => $message,
        'donnees' => $donnees
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

/**
 * Vérification du jeton de sécurité.
 */
function verifierJetonDemandes()
{
    $jeton = $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['csrf_demandes']) ||
        !hash_equals($_SESSION['csrf_demandes'], $jeton)
    ) {
        repondreJSON(false, 'Votre session a expiré. Rechargez la page.');
    }
}

/**
 * Vérification des champs d'une demande.
 */
function validerDemande($donnees)
{
    $types = [
        'Autorisation',
        'Intervention',
        'Accès',
        'Assistance',
        'Autre'
    ];

    $priorites = [
        'Normale',
        'Importante',
        'Urgente'
    ];

    $statuts = [
        'En attente',
        'Acceptée',
        'Refusée'
    ];

    $demandeur = trim($donnees['demandeur'] ?? '');
    $type = $donnees['type'] ?? '';
    $date = $donnees['date'] ?? '';
    $priorite = $donnees['priorite'] ?? '';
    $statut = $donnees['statut'] ?? '';
    $description = trim($donnees['description'] ?? '');

    if (
        $demandeur === '' ||
        $type === '' ||
        $date === '' ||
        $priorite === '' ||
        $statut === '' ||
        $description === ''
    ) {
        repondreJSON(false, 'Veuillez remplir tous les champs obligatoires.');
    }

    if (mb_strlen($demandeur) > 150) {
        repondreJSON(false, 'Le nom du demandeur est trop long.');
    }

    if (!in_array($type, $types, true)) {
        repondreJSON(false, 'Le type de demande est invalide.');
    }

    if (!in_array($priorite, $priorites, true)) {
        repondreJSON(false, 'La priorité sélectionnée est invalide.');
    }

    if (!in_array($statut, $statuts, true)) {
        repondreJSON(false, 'Le statut sélectionné est invalide.');
    }

    $dateObjet = DateTime::createFromFormat('Y-m-d', $date);

    if (!$dateObjet || $dateObjet->format('Y-m-d') !== $date) {
        repondreJSON(false, 'La date indiquée est invalide.');
    }

    return [
        'demandeur' => $demandeur,
        'type' => $type,
        'date' => $date,
        'priorite' => $priorite,
        'statut' => $statut,
        'description' => $description
    ];
}

/**
 * Génération d'une référence unique.
 */
function genererReferenceDemande()
{
    return 'DEM-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
}

/**
 * Traitement des demandes AJAX.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    verifierJetonDemandes();

    $action = $_POST['action'];

    try {

        /* LISTE DES DEMANDES */
        if ($action === 'lister') {

            $requete = $connexion->query("
                SELECT
                    id,
                    reference,
                    demandeur,
                    type,
                    date_demande,
                    priorite,
                    statut,
                    description
                FROM demandes
                ORDER BY date_creation DESC, id DESC
            ");

            $demandes = $requete->fetchAll();

            repondreJSON(true, 'Demandes récupérées.', $demandes);
        }

        /* AJOUTER UNE DEMANDE */
        if ($action === 'ajouter') {

            $donnees = validerDemande($_POST);

            $connexion->beginTransaction();

            $reference = genererReferenceDemande();

            $insertion = $connexion->prepare("
                INSERT INTO demandes (
                    reference,
                    demandeur,
                    type,
                    date_demande,
                    priorite,
                    statut,
                    description,
                    utilisateur_id
                ) VALUES (
                    :reference,
                    :demandeur,
                    :type,
                    :date_demande,
                    :priorite,
                    :statut,
                    :description,
                    :utilisateur_id
                )
            ");

            $insertion->execute([
                ':reference' => $reference,
                ':demandeur' => $donnees['demandeur'],
                ':type' => $donnees['type'],
                ':date_demande' => $donnees['date'],
                ':priorite' => $donnees['priorite'],
                ':statut' => $donnees['statut'],
                ':description' => $donnees['description'],
                ':utilisateur_id' => $utilisateurConnecte
            ]);

            /*
             * Notifications aux utilisateurs actifs ayant
             * accès au module Notifications, ainsi qu'aux admins.
             */
            $destinataires = $connexion->prepare("
                SELECT DISTINCT u.id
                FROM utilisateurs u
                WHERE u.statut = 'actif'
                  AND u.id <> :utilisateur_connecte
                  AND (
                      u.role = 'administrateur'
                      OR EXISTS (
                          SELECT 1
                          FROM utilisateur_modules um
                          INNER JOIN modules m ON m.id = um.module_id
                          WHERE um.utilisateur_id = u.id
                            AND m.code = 'notifications'
                      )
                  )
            ");

            $destinataires->execute([
                ':utilisateur_connecte' => $utilisateurConnecte
            ]);

            $listeDestinataires = $destinataires->fetchAll(PDO::FETCH_COLUMN);

            $notification = $connexion->prepare("
                INSERT INTO notifications (
                    utilisateur_id,
                    titre,
                    message,
                    type,
                    lien
                ) VALUES (
                    :utilisateur_id,
                    :titre,
                    :message,
                    'Demande',
                    :lien
                )
            ");

            foreach ($listeDestinataires as $destinataireId) {

                $notification->execute([
                    ':utilisateur_id' => (int) $destinataireId,
                    ':titre' => 'Nouvelle demande enregistrée',
                    ':message' => 'La demande ' . $reference .
                        ' de ' . $donnees['demandeur'] .
                        ' (' . $donnees['type'] . ') a été enregistrée.',
                    ':lien' => '../agents/demandes.php'
                ]);
            }

            $connexion->commit();

            repondreJSON(true, 'Demande enregistrée avec succès.');
        }

        /* MODIFIER UNE DEMANDE */
        if ($action === 'modifier') {

            $id = (int) ($_POST['id'] ?? 0);

            if ($id <= 0) {
                repondreJSON(false, 'Identifiant de demande invalide.');
            }

            $donnees = validerDemande($_POST);

            $modification = $connexion->prepare("
                UPDATE demandes
                SET
                    demandeur = :demandeur,
                    type = :type,
                    date_demande = :date_demande,
                    priorite = :priorite,
                    statut = :statut,
                    description = :description
                WHERE id = :id
            ");

            $modification->execute([
                ':demandeur' => $donnees['demandeur'],
                ':type' => $donnees['type'],
                ':date_demande' => $donnees['date'],
                ':priorite' => $donnees['priorite'],
                ':statut' => $donnees['statut'],
                ':description' => $donnees['description'],
                ':id' => $id
            ]);

            if ($modification->rowCount() === 0) {
                $verification = $connexion->prepare(
                    "SELECT id FROM demandes WHERE id = ?"
                );
                $verification->execute([$id]);

                if (!$verification->fetch()) {
                    repondreJSON(false, 'Demande introuvable.');
                }
            }

            repondreJSON(true, 'Demande modifiée avec succès.');
        }

        /* CHANGER LE STATUT */
        if ($action === 'changer_statut') {

            $id = (int) ($_POST['id'] ?? 0);
            $statut = $_POST['statut'] ?? '';

            if (
                $id <= 0 ||
                !in_array($statut, ['En attente', 'Acceptée', 'Refusée'], true)
            ) {
                repondreJSON(false, 'Informations de modification invalides.');
            }

            $modification = $connexion->prepare("
                UPDATE demandes
                SET statut = :statut
                WHERE id = :id
            ");

            $modification->execute([
                ':statut' => $statut,
                ':id' => $id
            ]);

            if ($modification->rowCount() === 0) {
                $verification = $connexion->prepare(
                    "SELECT id FROM demandes WHERE id = ?"
                );
                $verification->execute([$id]);

                if (!$verification->fetch()) {
                    repondreJSON(false, 'Demande introuvable.');
                }
            }

            repondreJSON(true, 'Statut mis à jour.');
        }

        /* SUPPRIMER UNE DEMANDE */
        if ($action === 'supprimer') {

            $id = (int) ($_POST['id'] ?? 0);

            if ($id <= 0) {
                repondreJSON(false, 'Identifiant invalide.');
            }

            $suppression = $connexion->prepare(
                "DELETE FROM demandes WHERE id = ?"
            );

            $suppression->execute([$id]);

            if ($suppression->rowCount() === 0) {
                repondreJSON(false, 'Demande introuvable.');
            }

            repondreJSON(true, 'Demande supprimée avec succès.');
        }

        repondreJSON(false, 'Action inconnue.');

    } catch (Throwable $erreur) {

        if ($connexion->inTransaction()) {
            $connexion->rollBack();
        }

        error_log('Erreur module demandes : ' . $erreur->getMessage());

        repondreJSON(
            false,
            'Une erreur est survenue. Vérifiez la configuration et réessayez.'
        );
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Gestion des demandes | Sécurité UASZ</title>

    <link rel="stylesheet" href="../../../public/css/demandes.css?v=6">
</head>

<body>

<div class="app-container">

    <main class="main-content">

        <!-- BOUTON RETOUR AU TABLEAU DE BORD -->
        <div class="retour-tableau">
            <a href="../tableau_de_bord/tableau_de_bord.php">
                <span>←</span> Retour au tableau de bord
            </a>
        </div>

        <!-- EN-TÊTE -->
        <header class="topbar">

            <div>
                <h1>Gestion des demandes</h1>
                <p>Consultation et traitement des demandes du personnel universitaire.</p>
            </div>

            <div class="user-info">
                <div class="user-avatar">U</div>

                <div>
                    <strong>Utilisateur connecté</strong>
                    <small>Service de sécurité</small>
                </div>
            </div>

        </header>

        <!-- STATISTIQUES -->
        <section class="stats-grid">

            <div class="stat-card">
                <div class="stat-icon blue">📨</div>
                <div>
                    <p>Total des demandes</p>
                    <h2 id="totalDemandes">0</h2>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon orange">⏳</div>
                <div>
                    <p>En attente</p>
                    <h2 id="enAttente">0</h2>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon green">✅</div>
                <div>
                    <p>Acceptées</p>
                    <h2 id="acceptees">0</h2>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon red">❌</div>
                <div>
                    <p>Refusées</p>
                    <h2 id="refusees">0</h2>
                </div>
            </div>

        </section>

        <!-- LISTE DES DEMANDES -->
        <section class="content-card">

            <div class="section-header">

                <div>
                    <h2>Liste des demandes</h2>
                    <p>Consultez et gérez les demandes enregistrées.</p>
                </div>

                <button class="btn-primary" id="btnAjouter">
                    + Nouvelle demande
                </button>

            </div>

            <!-- RECHERCHE ET FILTRES -->
            <div class="filters">

                <input
                    type="text"
                    id="rechercheDemande"
                    placeholder="🔍 Rechercher une demande..."
                >

                <select id="filtreStatut">
                    <option value="">Tous les statuts</option>
                    <option value="En attente">En attente</option>
                    <option value="Acceptée">Acceptée</option>
                    <option value="Refusée">Refusée</option>
                </select>

                <select id="filtreType">
                    <option value="">Tous les types</option>
                    <option value="Autorisation">Autorisation</option>
                    <option value="Intervention">Intervention</option>
                    <option value="Accès">Accès</option>
                    <option value="Assistance">Assistance</option>
                    <option value="Autre">Autre</option>
                </select>

            </div>

            <!-- TABLEAU -->
            <div class="table-container">

                <table>

                    <thead>
                        <tr>
                            <th>Référence</th>
                            <th>Demandeur</th>
                            <th>Type</th>
                            <th>Date</th>
                            <th>Priorité</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody id="tableDemandes"></tbody>

                </table>

            </div>

            <p class="empty-message" id="messageVide">
                Aucune demande trouvée.
            </p>

        </section>

    </main>

</div>

<!-- FENÊTRE MODALE -->
<div class="modal" id="modalDemande">

    <div class="modal-content">

        <div class="modal-header">

            <div>
                <h2 id="titreModal">Nouvelle demande</h2>
                <p>Renseignez les informations de la demande.</p>
            </div>

            <button type="button" class="btn-close" id="btnFermer">
                &times;
            </button>

        </div>

        <form id="formDemande">

            <input type="hidden" id="demandeId">

            <div class="form-group">
                <label for="nomDemandeur">Nom du demandeur *</label>

                <input
                    type="text"
                    id="nomDemandeur"
                    maxlength="150"
                    placeholder="Ex : Mamadou Diop"
                    required
                >
            </div>

            <div class="form-row">

                <div class="form-group">
                    <label for="typeDemande">Type de demande *</label>

                    <select id="typeDemande" required>
                        <option value="">Choisir un type</option>
                        <option value="Autorisation">Autorisation</option>
                        <option value="Intervention">Intervention</option>
                        <option value="Accès">Accès</option>
                        <option value="Assistance">Assistance</option>
                        <option value="Autre">Autre</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="dateDemande">Date *</label>

                    <input type="date" id="dateDemande" required>
                </div>

            </div>

            <div class="form-row">

                <div class="form-group">
                    <label for="prioriteDemande">Priorité *</label>

                    <select id="prioriteDemande" required>
                        <option value="">Choisir une priorité</option>
                        <option value="Normale">Normale</option>
                        <option value="Importante">Importante</option>
                        <option value="Urgente">Urgente</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="statutDemande">Statut *</label>

                    <select id="statutDemande" required>
                        <option value="En attente">En attente</option>
                        <option value="Acceptée">Acceptée</option>
                        <option value="Refusée">Refusée</option>
                    </select>
                </div>

            </div>

            <div class="form-group">
                <label for="descriptionDemande">Description *</label>

                <textarea
                    id="descriptionDemande"
                    rows="4"
                    placeholder="Décrivez l'objet de la demande..."
                    required
                ></textarea>
            </div>

            <div class="form-actions">

                <button type="button" class="btn-secondary" id="btnAnnuler">
                    Annuler
                </button>

                <button type="submit" class="btn-primary" id="btnEnregistrer">
                    Enregistrer
                </button>

            </div>

        </form>

    </div>

</div>

<script>
    window.CSRF_DEMANDES = <?= json_encode($csrfToken) ?>;
</script>

<script src="../../../public/js/demandes.js?v=5"></script>

</body>
</html>

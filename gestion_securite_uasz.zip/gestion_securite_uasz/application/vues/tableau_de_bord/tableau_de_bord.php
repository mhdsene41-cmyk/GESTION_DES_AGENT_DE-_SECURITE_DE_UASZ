
<?php
require_once __DIR__ . '/../../outils/verifier_acces.php';

exigerAcces('tableau_de_bord');

// ==========================================
// INFORMATIONS DE L'UTILISATEUR CONNECTÉ
// ==========================================

$nomUtilisateur = $_SESSION['nom'] ?? 'Utilisateur';
$prenomUtilisateur = $_SESSION['prenom'] ?? '';
$roleUtilisateur = $_SESSION['role'] ?? 'utilisateur';
$idUtilisateur = (int) ($_SESSION['utilisateur_id'] ?? 0);

$nomComplet = trim($prenomUtilisateur . ' ' . $nomUtilisateur);
$initiale = strtoupper(substr($prenomUtilisateur ?: $nomUtilisateur, 0, 1));

$e = function ($valeur) {
    return htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
};

$roleAffiche = ucfirst(str_replace('_', ' ', $roleUtilisateur));

// ==========================================
// PERMISSIONS
// ==========================================

$permissions = [
    'utilisateurs' => verifierAcces('utilisateurs'),
    'agents' => verifierAcces('agents'),
    'recrutement' => verifierAcces('recrutement'),
    'carrieres' => verifierAcces('carrieres'),
    'rapports' => verifierAcces('rapports'),
    'presences' => verifierAcces('presences'),
    'plannings' => verifierAcces('plannings'),
    'incidents' => verifierAcces('incidents'),
    'demandes' => verifierAcces('demandes'),
    'affectations' => verifierAcces('affectations'),
    'profil' => verifierAcces('profil'),
    'notifications' => verifierAcces('notifications')
];

// ==========================================
// STATISTIQUES
// ==========================================

$statistiques = [];

$compter = function ($sql) use ($connexion) {
    return (int) $connexion->query($sql)->fetchColumn();
};

if ($permissions['agents']) {
    $statistiques[] = [
        'titre' => 'Agents de sécurité',
        'valeur' => $compter("SELECT COUNT(*) FROM agents"),
        'description' => 'Effectif enregistré',
        'icone' => '👮',
        'couleur' => 'bleu'
    ];
}

if ($permissions['utilisateurs']) {
    $statistiques[] = [
        'titre' => 'Utilisateurs',
        'valeur' => $compter("SELECT COUNT(*) FROM utilisateurs"),
        'description' => 'Comptes enregistrés',
        'icone' => '👤',
        'couleur' => 'vert'
    ];
}

if ($permissions['incidents']) {
    $statistiques[] = [
        'titre' => 'Incidents signalés',
        'valeur' => $compter("SELECT COUNT(*) FROM incidents"),
        'description' => 'Incidents enregistrés',
        'icone' => '⚠️',
        'couleur' => 'orange'
    ];
}

if ($permissions['demandes']) {
    $statistiques[] = [
        'titre' => 'Demandes en attente',
        'valeur' => $compter("SELECT COUNT(*) FROM demandes WHERE statut = 'En attente'"),
        'description' => 'Demandes à traiter',
        'icone' => '📩',
        'couleur' => 'rouge'
    ];
}

// ==========================================
// NOTIFICATIONS NON LUES
// ==========================================

$notificationsNonLues = 0;

if ($permissions['notifications']) {
    $requeteNotifications = $connexion->prepare("
        SELECT COUNT(*)
        FROM notifications
        WHERE utilisateur_id = ?
        AND est_lue = 0
    ");

    $requeteNotifications->execute([$idUtilisateur]);
    $notificationsNonLues = (int) $requeteNotifications->fetchColumn();
}

// ==========================================
// MENUS DE NAVIGATION
// ==========================================

$menus = [
    'MENU PRINCIPAL' => [
        [
            'code' => 'tableau_de_bord',
            'nom' => 'Tableau de bord',
            'url' => 'tableau_de_bord.php',
            'icone' => '▦',
            'actif' => true
        ],
        [
            'code' => 'utilisateurs',
            'nom' => 'Utilisateurs',
            'url' => '../utilisateurs/utilisateurs.php',
            'icone' => '👤'
        ],
        [
            'code' => 'agents',
            'nom' => 'Agents de sécurité',
            'url' => '../agents/agents.php',
            'icone' => '👮'
        ],
        [
            'code' => 'recrutement',
            'nom' => 'Recrutements',
            'url' => '../recrutement/recrutement.php',
            'icone' => '📋'
        ],
        [
            'code' => 'carrieres',
            'nom' => 'Carrières',
            'url' => '../carrieres/carrieres.php',
            'icone' => '🎓'
        ],
        [
            'code' => 'rapports',
            'nom' => 'Rapports et statistiques',
            'url' => '../rapports/rapports.php',
            'icone' => '📊'
        ]
    ],

    'GESTION DE LA SÉCURITÉ' => [
        [
            'code' => 'presences',
            'nom' => 'Présences',
            'url' => '../agents/presences.php',
            'icone' => '✓'
        ],
        [
            'code' => 'plannings',
            'nom' => 'Plannings',
            'url' => '../agents/plannings.php',
            'icone' => '📅'
        ],
        [
            'code' => 'incidents',
            'nom' => 'Incidents',
            'url' => '../agents/incidents.php',
            'icone' => '⚠'
        ],
        [
            'code' => 'demandes',
            'nom' => 'Demandes',
            'url' => '../demandes/demandes.php',
            'icone' => '✉'
        ],
        [
            'code' => 'affectations',
            'nom' => 'Affectations',
            'url' => '../affectations/affectations.php',
            'icone' => '⇄'
        ]
    ],

    'PARAMÈTRES' => [
        [
            'code' => 'profil',
            'nom' => 'Mon profil',
            'url' => '../profil/profil.php',
            'icone' => '⚙'
        ],
        [
            'code' => 'notifications',
            'nom' => 'Notifications',
            'url' => '../notifications/notifications.php',
            'icone' => '♢'
        ]
    ]
];

// ==========================================
// ACCÈS RAPIDES
// ==========================================

$accesRapides = [
    [
        'code' => 'agents',
        'nom' => 'Agents',
        'description' => 'Gestion des agents de sécurité',
        'url' => '../agents/agents.php',
        'icone' => '👮',
        'couleur' => 'bleu'
    ],
    [
        'code' => 'presences',
        'nom' => 'Présences',
        'description' => 'Suivi des présences',
        'url' => '../agents/presences.php',
        'icone' => '✓',
        'couleur' => 'vert'
    ],
    [
        'code' => 'incidents',
        'nom' => 'Incidents',
        'description' => 'Suivi des événements signalés',
        'url' => '../agents/incidents.php',
        'icone' => '⚠️',
        'couleur' => 'orange'
    ],
    [
        'code' => 'rapports',
        'nom' => 'Rapports',
        'description' => 'Consultation des rapports',
        'url' => '../rapports/rapports.php',
        'icone' => '📊',
        'couleur' => 'violet'
    ],
    [
        'code' => 'demandes',
        'nom' => 'Demandes',
        'description' => 'Traitement des demandes',
        'url' => '../demandes/demandes.php',
        'icone' => '📩',
        'couleur' => 'rouge'
    ],
    [
        'code' => 'plannings',
        'nom' => 'Plannings',
        'description' => 'Organisation des équipes',
        'url' => '../agents/plannings.php',
        'icone' => '📅',
        'couleur' => 'jaune'
    ],
    [
        'code' => 'affectations',
        'nom' => 'Affectations',
        'description' => 'Suivi des affectations',
        'url' => '../affectations/affectations.php',
        'icone' => '⇄',
        'couleur' => 'vert'
    ]
];

$accesRapides = array_values(array_filter(
    $accesRapides,
    function ($module) use ($permissions) {
        return $permissions[$module['code']] ?? false;
    }
));

// ==========================================
// ACTIVITÉS RÉCENTES
// ==========================================

$activites = [];

if ($permissions['incidents']) {
    $sqlIncidents = "
        SELECT
            'Incident signalé' AS activite,
            i.numero AS detail,
            COALESCE(CONCAT(u.prenom, ' ', u.nom), 'Utilisateur') AS utilisateur,
            i.date_creation AS date_activite,
            i.statut AS statut,
            '../agents/incidents.php' AS lien
        FROM incidents i
        LEFT JOIN utilisateurs u ON u.id = i.utilisateur_id
        ORDER BY i.date_creation DESC
        LIMIT 6
    ";

    $incidentsRecents = $connexion->query($sqlIncidents)->fetchAll(PDO::FETCH_ASSOC);
    $activites = array_merge($activites, $incidentsRecents);
}

if ($permissions['demandes']) {
    $sqlDemandes = "
        SELECT
            CONCAT('Demande : ', d.type) AS activite,
            d.reference AS detail,
            COALESCE(
                CONCAT(u.prenom, ' ', u.nom),
                d.demandeur,
                'Utilisateur'
            ) AS utilisateur,
            d.date_creation AS date_activite,
            d.statut AS statut,
            '../demandes/demandes.php' AS lien
        FROM demandes d
        LEFT JOIN utilisateurs u ON u.id = d.utilisateur_id
        ORDER BY d.date_creation DESC
        LIMIT 6
    ";

    $demandesRecentes = $connexion->query($sqlDemandes)->fetchAll(PDO::FETCH_ASSOC);
    $activites = array_merge($activites, $demandesRecentes);
}

usort($activites, function ($a, $b) {
    return strtotime($b['date_activite']) <=> strtotime($a['date_activite']);
});

$activites = array_slice($activites, 0, 6);

$afficherActivites = $permissions['incidents'] || $permissions['demandes'];

// ==========================================
// STATUTS
// ==========================================

$libellesStatuts = [
    'nouveau' => 'Nouveau',
    'en_cours' => 'En cours',
    'resolu' => 'Résolu',
    'cloture' => 'Clôturé',
    'En attente' => 'En attente',
    'Acceptée' => 'Acceptée',
    'Refusée' => 'Refusée'
];

function classeStatut($statut)
{
    $classes = [
        'nouveau' => 'statut-nouveau',
        'en_cours' => 'statut-cours',
        'resolu' => 'statut-termine',
        'cloture' => 'statut-termine',
        'En attente' => 'statut-attente',
        'Acceptée' => 'statut-termine',
        'Refusée' => 'statut-refuse'
    ];

    return $classes[$statut] ?? 'statut-neutre';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tableau de bord | Gestion Sécurité UASZ</title>

    <link rel="stylesheet" href="../../../public/css/tableau_de_bord.css">

    <style>
        /* ASSISTANT UASZ */

        .assistant-uasz {
            margin: 30px 0;
            padding: 25px;
            background: #fff;
            border: 1px solid #e5eaf2;
            border-radius: 16px;
            box-shadow: 0 5px 20px rgba(15, 23, 42, .05);
        }

        .assistant-entete {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 20px;
        }

        .assistant-logo {
            width: 52px;
            height: 52px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 14px;
            background: #0f2747;
            color: #fff;
            font-size: 25px;
        }

        .assistant-titre h2 {
            margin: 0 0 5px;
            color: #0f2747;
            font-size: 20px;
        }

        .assistant-titre p {
            margin: 0;
            color: #64748b;
            font-size: 13px;
        }

        .assistant-en-ligne {
            margin-left: auto;
            color: #15803d;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
        }

        .assistant-en-ligne::before {
            content: "";
            display: inline-block;
            width: 8px;
            height: 8px;
            margin-right: 6px;
            border-radius: 50%;
            background: #22c55e;
        }

        .assistant-messages {
            height: 300px;
            overflow-y: auto;
            padding: 18px;
            background: #f8fafc;
            border: 1px solid #e8edf4;
            border-radius: 12px;
        }

        .message-uasz {
            display: flex;
            margin-bottom: 15px;
        }

        .message-uasz.utilisateur {
            justify-content: flex-end;
        }

        .message-uasz.assistant {
            justify-content: flex-start;
        }

        .message-bulle {
            max-width: 80%;
            padding: 12px 15px;
            border-radius: 12px;
            font-size: 14px;
            line-height: 1.6;
            white-space: pre-line;
            overflow-wrap: anywhere;
        }

        .message-uasz.assistant .message-bulle {
            background: #fff;
            color: #334155;
            border: 1px solid #e2e8f0;
            border-bottom-left-radius: 3px;
        }

        .message-uasz.utilisateur .message-bulle {
            background: #0f2747;
            color: #fff;
            border-bottom-right-radius: 3px;
        }

        .assistant-questions {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 15px 0;
        }

        .assistant-question {
            padding: 9px 13px;
            border: 1px solid #dbe3ef;
            border-radius: 20px;
            background: #fff;
            color: #0f2747;
            font-size: 12px;
            cursor: pointer;
            transition: .2s;
        }

        .assistant-question:hover {
            background: #fff7e6;
            border-color: #e9a526;
        }

        .assistant-formulaire {
            display: flex;
            gap: 10px;
        }

        .assistant-formulaire input {
            flex: 1;
            min-width: 0;
            padding: 13px 15px;
            border: 1px solid #dbe3ef;
            border-radius: 9px;
            outline: none;
            font-size: 14px;
        }

        .assistant-formulaire input:focus {
            border-color: #e9a526;
            box-shadow: 0 0 0 3px rgba(233, 165, 38, .12);
        }

        .assistant-formulaire button {
            padding: 0 20px;
            border: none;
            border-radius: 9px;
            background: #0f2747;
            color: #fff;
            font-weight: 600;
            cursor: pointer;
            transition: .2s;
        }

        .assistant-formulaire button:hover {
            background: #1d416c;
        }

        .assistant-carte-lien {
            display: inline-block;
            margin-top: 8px;
            color: #b7790b;
            font-weight: 600;
            text-decoration: none;
        }

        .assistant-carte-lien:hover {
            text-decoration: underline;
        }

        .assistant-note {
            margin: 12px 0 0;
            color: #94a3b8;
            font-size: 11px;
        }

        @media (max-width: 600px) {
            .assistant-uasz {
                padding: 15px;
            }

            .assistant-messages {
                height: 280px;
                padding: 12px;
            }

            .message-bulle {
                max-width: 92%;
            }

            .assistant-en-ligne {
                display: none;
            }

            .assistant-formulaire button {
                padding: 0 13px;
            }
        }
    </style>
</head>

<body>

<div class="conteneur-principal">

    <!-- BARRE LATÉRALE -->

    <aside class="barre-laterale" id="barreLaterale">

        <div class="logo">
            <div class="logo-icone">U</div>

            <div>
                <h2>UASZ</h2>
                <p>Gestion Sécurité</p>
            </div>
        </div>

        <?php if ($permissions['profil']): ?>

            <!-- PROFIL CLIQUABLE -->

            <a href="../profil/profil.php"
               class="profil-administrateur lien-profil"
               title="Cliquer pour consulter votre profil">

                <div class="avatar">
                    <?= $e($initiale) ?>
                </div>

                <div class="informations-profil">
                    <h3><?= $e($nomComplet) ?></h3>

                    <p>
                        <span class="point-en-ligne"></span>
                        <?= $e($roleAffiche) ?>
                    </p>

                    <span class="indication-profil">
                        Mon profil <span aria-hidden="true">›</span>
                    </span>
                </div>

            </a>

        <?php else: ?>

            <div class="profil-administrateur">
                <div class="avatar"><?= $e($initiale) ?></div>

                <div class="informations-profil">
                    <h3><?= $e($nomComplet) ?></h3>
                    <p>
                        <span class="point-en-ligne"></span>
                        <?= $e($roleAffiche) ?>
                    </p>
                </div>
            </div>

        <?php endif; ?>

        <nav class="navigation">

            <?php foreach ($menus as $titre => $elements): ?>

                <?php
                $elementsVisibles = array_filter(
                    $elements,
                    function ($element) use ($permissions) {
                        return $element['code'] === 'tableau_de_bord'
                            || ($permissions[$element['code']] ?? false);
                    }
                );
                ?>

                <?php if (!empty($elementsVisibles)): ?>

                    <p class="titre-menu"><?= $e($titre) ?></p>

                    <?php foreach ($elementsVisibles as $element): ?>

                        <a href="<?= $e($element['url']) ?>"
                           class="lien-menu <?= !empty($element['actif']) ? 'actif' : '' ?>">

                            <span class="icone-menu"><?= $e($element['icone']) ?></span>
                            <span><?= $e($element['nom']) ?></span>

                            <?php if ($element['code'] === 'notifications' && $notificationsNonLues > 0): ?>
                                <span class="badge-notification">
                                    <?= $notificationsNonLues ?>
                                </span>
                            <?php endif; ?>

                        </a>

                    <?php endforeach; ?>

                <?php endif; ?>

            <?php endforeach; ?>

        </nav>

        <div class="deconnexion">
            <a href="../authentification/deconnexion.php">
                <span>↪</span> Déconnexion
            </a>
        </div>

    </aside>

    <!-- CONTENU PRINCIPAL -->

    <main class="contenu-principal">

        <!-- ENTÊTE -->

        <header class="entete">

            <div class="entete-gauche">

                <button type="button"
                        class="bouton-menu"
                        id="boutonMenu"
                        aria-label="Ouvrir le menu"
                        aria-expanded="false">
                    ☰
                </button>

                <div>
                    <h1>Tableau de bord</h1>
                    <p>Bienvenue dans votre espace de gestion.</p>
                </div>

            </div>

            <div class="informations-entete">

                <div class="date-entete">
                    <span>◷</span>
                    <span id="dateActuelle">Chargement...</span>
                </div>

                <?php if ($permissions['notifications']): ?>

                    <a href="../notifications/notifications.php"
                       class="bouton-notification"
                       aria-label="Notifications">

                        ♢

                        <?php if ($notificationsNonLues > 0): ?>
                            <span class="point-notification"></span>
                        <?php endif; ?>

                    </a>

                <?php endif; ?>

                <?php if ($permissions['profil']): ?>
                    <a href="../profil/profil.php"
                       class="avatar-entete"
                       title="Mon profil">
                        <?= $e($initiale) ?>
                    </a>
                <?php else: ?>
                    <div class="avatar-entete"><?= $e($initiale) ?></div>
                <?php endif; ?>

            </div>

        </header>

        <!-- BIENVENUE -->

        <section class="bienvenue">

            <div class="contenu-bienvenue">

                <span class="sous-titre">ESPACE DE GESTION</span>

                <h2>
                    Bienvenue, <?= $e($prenomUtilisateur ?: $nomUtilisateur) ?> !
                </h2>

                <p>
                    Retrouvez ici les informations et les fonctionnalités
                    auxquelles votre compte est autorisé à accéder.
                </p>

                <?php if ($permissions['agents']): ?>
                    <a href="../agents/agents.php" class="bouton-bienvenue">
                        Consulter les agents <span>→</span>
                    </a>
                <?php endif; ?>

            </div>

            <div class="illustration-bienvenue" aria-hidden="true">
                <div class="cercle-exterieur">
                    <div class="cercle-interieur">UASZ</div>
                </div>
            </div>

        </section>

        <!-- ASSISTANT UASZ -->

        <section class="assistant-uasz">

            <div class="assistant-entete">

                <div class="assistant-logo">🤖</div>

                <div class="assistant-titre">
                    <h2>Assistant UASZ</h2>
                    <p>Votre guide numérique de l'université</p>
                </div>

                <span class="assistant-en-ligne">Assistant disponible</span>

            </div>

            <div class="assistant-messages"
                 id="messagesAssistant"
                 aria-live="polite">

                <div class="message-uasz assistant">
                    <div class="message-bulle">Bonjour ! 👋 Bienvenue sur l'assistant UASZ.

Je suis votre guide numérique. Je peux vous renseigner sur l'Université Assane Seck de Ziguinchor, sa localisation et certains lieux du campus.

Que souhaitez-vous savoir ?</div>
                </div>

            </div>

            <div class="assistant-questions">

                <button type="button" class="assistant-question"
                        data-question="Où se trouve l'université ?">
                    📍 Localisation
                </button>

                <button type="button" class="assistant-question"
                        data-question="Comment consulter la carte du campus ?">
                    🗺️ Carte du campus
                </button>

                <button type="button" class="assistant-question"
                        data-question="Où se trouve la bibliothèque ?">
                    📚 Bibliothèque
                </button>

                <button type="button" class="assistant-question"
                        data-question="Qu'est-ce que l'UASZ ?">
                    🎓 Présentation
                </button>

                <button type="button" class="assistant-question"
                        data-question="Où se trouve le département informatique ?">
                    💻 Informatique
                </button>

            </div>

            <form class="assistant-formulaire" id="formulaireAssistant">

                <input type="text"
                       id="questionAssistant"
                       placeholder="Posez votre question sur l'UASZ..."
                       autocomplete="off"
                       required>

                <button type="submit">Envoyer ➤</button>

            </form>

            <p class="assistant-note">
                Assistant local : les réponses proviennent d'une base de questions préparées.
            </p>

        </section>

        <!-- STATISTIQUES -->

        <?php if (!empty($statistiques)): ?>

            <section class="section-statistiques">

                <div class="titre-section">
                    <div>
                        <h2>Vue générale</h2>
                        <p>Indicateurs des modules auxquels vous avez accès</p>
                    </div>
                </div>

                <div class="grille-statistiques">

                    <?php foreach ($statistiques as $statistique): ?>

                        <article class="carte-statistique">

                            <div class="icone-statistique <?= $e($statistique['couleur']) ?>">
                                <?= $e($statistique['icone']) ?>
                            </div>

                            <div class="details-statistique">
                                <p><?= $e($statistique['titre']) ?></p>

                                <h3>
                                    <?= number_format($statistique['valeur'], 0, ',', ' ') ?>
                                </h3>

                                <span><?= $e($statistique['description']) ?></span>
                            </div>

                        </article>

                    <?php endforeach; ?>

                </div>

            </section>

        <?php endif; ?>

        <!-- ACCÈS RAPIDES -->

        <?php if (!empty($accesRapides)): ?>

            <section class="section-modules">

                <div class="titre-section">
                    <div>
                        <h2>Accès rapides</h2>
                        <p>Vos fonctionnalités accessibles en un clic</p>
                    </div>
                </div>

                <div class="grille-modules">

                    <?php foreach ($accesRapides as $module): ?>

                        <a href="<?= $e($module['url']) ?>" class="carte-module">

                            <div class="icone-module <?= $e($module['couleur']) ?>">
                                <?= $e($module['icone']) ?>
                            </div>

                            <div class="texte-module">
                                <h3><?= $e($module['nom']) ?></h3>
                                <p><?= $e($module['description']) ?></p>
                            </div>

                            <span class="fleche-module">→</span>

                        </a>

                    <?php endforeach; ?>

                </div>

            </section>

        <?php endif; ?>

        <!-- ACTIVITÉS RÉCENTES -->

        <?php if ($afficherActivites): ?>

            <section class="section-activites">

                <div class="titre-section">

                    <div>
                        <h2>Activités récentes</h2>
                        <p>Dernières demandes et derniers incidents enregistrés</p>
                    </div>

                    <?php if ($permissions['rapports']): ?>
                        <a href="../rapports/rapports.php" class="lien-voir-plus">
                            Voir les rapports →
                        </a>
                    <?php endif; ?>

                </div>

                <div class="tableau-activites">

                    <table>

                        <thead>
                            <tr>
                                <th>ACTIVITÉ</th>
                                <th>UTILISATEUR</th>
                                <th>DATE</th>
                                <th>STATUT</th>
                                <th></th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if (!empty($activites)): ?>

                            <?php foreach ($activites as $activite): ?>

                                <tr>

                                    <td>
                                        <strong><?= $e($activite['activite']) ?></strong>
                                        <small><?= $e($activite['detail']) ?></small>
                                    </td>

                                    <td><?= $e($activite['utilisateur']) ?></td>

                                    <td>
                                        <?= $e(date('d/m/Y à H:i', strtotime($activite['date_activite']))) ?>
                                    </td>

                                    <td>
                                        <span class="badge-statut <?= $e(classeStatut($activite['statut'])) ?>">
                                            <?= $e($libellesStatuts[$activite['statut']] ?? $activite['statut']) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <a class="lien-activite" href="<?= $e($activite['lien']) ?>">
                                            Consulter →
                                        </a>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="5" class="aucune-activite">
                                    <div class="icone-vide">📭</div>
                                    <p>Aucune activité enregistrée pour le moment.</p>
                                </td>
                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </section>

        <?php endif; ?>

        <!-- PIED DE PAGE -->

        <footer class="pied-page">
            <p>© <span id="anneeActuelle"><?= date('Y') ?></span> Gestion Sécurité UASZ</p>
            <p>Université Assane Seck de Ziguinchor</p>
        </footer>

    </main>

</div>

<div class="fond-menu" id="fondMenu"></div>

<!-- SCRIPT DE L'ASSISTANT UASZ -->

<script>
document.addEventListener("DOMContentLoaded", function () {

    const formulaire = document.getElementById("formulaireAssistant");
    const champQuestion = document.getElementById("questionAssistant");
    const zoneMessages = document.getElementById("messagesAssistant");

    if (!formulaire || !champQuestion || !zoneMessages) {
        return;
    }

    const lienCarte = "https://mapcarta.com/fr/W218915006/Itin%C3%A9raires";

    const reponsesUASZ = [
        {
            mots: ["bibliotheque", "livres", "lecture"],
            reponse: "La bibliothèque universitaire est un lieu de consultation de documents et de travail pour les étudiants. Vous pouvez consulter la carte de l'université pour explorer les environs. Vérifiez l'emplacement exact avant de vous déplacer.",
            carte: true
        },
        {
            mots: ["informatique", "departement", "informaticien"],
            reponse: "Vous recherchez le département informatique de l'UASZ ? Je peux vous orienter vers la carte générale du campus. Je ne dispose pas encore de coordonnées confirmées pour ce département.",
            carte: true
        },
        {
            mots: ["carte", "itineraire", "plan", "orientation"],
            reponse: "Vous pouvez consulter la carte de l'Université Assane Seck et explorer les itinéraires disponibles sur Mapcarta.",
            carte: true
        },
        {
            mots: ["localisation", "adresse", "situe", "situee", "ou se trouve"],
            reponse: "L'Université Assane Seck de Ziguinchor se trouve à Ziguinchor, au Sénégal. Consultez la carte pour visualiser sa localisation et préparer votre itinéraire.",
            carte: true
        },
        {
            mots: ["uasz", "universite", "presentation"],
            reponse: "UASZ signifie Université Assane Seck de Ziguinchor. C'est un établissement d'enseignement supérieur situé à Ziguinchor, au Sénégal. 🎓",
            carte: false
        },
        {
            mots: ["bonjour", "salut", "bonsoir", "coucou"],
            reponse: "Bonjour ! 😊 Bienvenue sur l'assistant UASZ. Je suis disponible pour vous orienter et répondre à vos questions sur l'université.",
            carte: false
        },
        {
            mots: ["merci", "remercie"],
            reponse: "Avec plaisir ! 😊 N'hésitez pas à me poser une autre question.",
            carte: false
        },
        {
            mots: ["aide", "question", "aider"],
            reponse: "Je peux vous renseigner sur l'université, sa localisation, la carte du campus, la bibliothèque et le département informatique. Vous pouvez également utiliser les questions rapides proposées.",
            carte: false
        }
    ];

    function normaliser(texte) {
        return texte
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[?!.,;:]/g, " ")
            .replace(/\s+/g, " ")
            .trim();
    }

    function ajouterMessage(texte, type, afficherCarte = false) {

        const conteneur = document.createElement("div");
        conteneur.className = "message-uasz " + type;

        const bulle = document.createElement("div");
        bulle.className = "message-bulle";
        bulle.textContent = texte;

        if (afficherCarte) {

            const lien = document.createElement("a");

            lien.href = lienCarte;
            lien.target = "_blank";
            lien.rel = "noopener noreferrer";
            lien.className = "assistant-carte-lien";
            lien.textContent = "🗺️ Ouvrir la carte de l'UASZ";

            bulle.appendChild(document.createElement("br"));
            bulle.appendChild(lien);
        }

        conteneur.appendChild(bulle);
        zoneMessages.appendChild(conteneur);
        zoneMessages.scrollTop = zoneMessages.scrollHeight;
    }

    function obtenirReponse(question) {

        const texte = normaliser(question);

        for (const element of reponsesUASZ) {

            const correspond = element.mots.some(function (mot) {
                return texte.includes(normaliser(mot));
            });

            if (correspond) {
                return {
                    texte: element.reponse,
                    carte: element.carte
                };
            }
        }

        return {
            texte: "Je n'ai pas encore de réponse préparée pour cette question. 🤔 Essayez de me demander des informations sur l'université, la bibliothèque, le département informatique, la localisation ou la carte du campus.",
            carte: false
        };
    }

    function envoyerQuestion(question) {

        const texte = question.trim();

        if (texte === "") {
            return;
        }

        ajouterMessage(texte, "utilisateur");

        const resultat = obtenirReponse(texte);

        ajouterMessage(
            resultat.texte,
            "assistant",
            resultat.carte
        );
    }

    formulaire.addEventListener("submit", function (evenement) {

        evenement.preventDefault();

        envoyerQuestion(champQuestion.value);

        champQuestion.value = "";
        champQuestion.focus();
    });

    document.querySelectorAll(".assistant-question").forEach(function (bouton) {

        bouton.addEventListener("click", function () {
            envoyerQuestion(this.dataset.question || "");
        });

    });

});
</script>

<script src="../../../public/js/tableau_de_bord.js"></script>

</body>
</html>

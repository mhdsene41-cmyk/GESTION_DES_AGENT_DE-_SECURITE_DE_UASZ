
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../configuration/connexion_bd.php';

// Vérifier la connexion
if (!isset($_SESSION['utilisateur_id'])) {
    header("Location: /gestion_securite_uasz/application/vues/authentification/connexion.php");
    exit;
}

/**
 * Afficher une page commune lorsque l'accès est refusé.
 */
function afficherAccesRefuse()
{
    http_response_code(403);

    echo <<<'HTML'
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accès refusé | Gestion Sécurité UASZ</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .message {
            background: white;
            padding: 35px;
            border-radius: 12px;
            text-align: center;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        h2 {
            color: #c0392b;
        }

        p {
            color: #555;
            line-height: 1.6;
        }

        a {
            display: inline-block;
            margin-top: 15px;
            padding: 12px 20px;
            background: #111c32;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: background 0.2s;
        }

        a:hover {
            background: #243b60;
        }
    </style>
</head>

<body>
    <div class="message">
        <h2>Accès refusé !</h2>

        <p>Vous n'avez pas accès à cette interface.</p>

        <p>Veuillez contacter votre administrateur.</p>

        <a href="/gestion_securite_uasz/application/vues/tableau_de_bord/tableau_de_bord.php">
            Retour au tableau de bord
        </a>
    </div>
</body>
</html>
HTML;

    exit;
}

/**
 * Vérifier si l'utilisateur possède l'autorisation d'accès à un module.
 */
function verifierAcces($code_module)
{
    global $connexion;

    // L'administrateur possède tous les accès.
    if (($_SESSION['role'] ?? '') === 'administrateur') {
        return true;
    }

    $requete = $connexion->prepare("
        SELECT COUNT(*)
        FROM utilisateur_modules um
        INNER JOIN modules m ON m.id = um.module_id
        WHERE um.utilisateur_id = ?
        AND m.code = ?
    ");

    $requete->execute([
        $_SESSION['utilisateur_id'],
        $code_module
    ]);

    return $requete->fetchColumn() > 0;
}

/**
 * Exiger une autorisation pour accéder à un module.
 */
function exigerAcces($code_module)
{
    if (!verifierAcces($code_module)) {
        afficherAccesRefuse();
    }
}

/**
 * Vérifier si l'utilisateur possède un rôle précis.
 */
function exigerRole($role)
{
    if (($_SESSION['role'] ?? '') !== $role) {
        afficherAccesRefuse();
    }
}

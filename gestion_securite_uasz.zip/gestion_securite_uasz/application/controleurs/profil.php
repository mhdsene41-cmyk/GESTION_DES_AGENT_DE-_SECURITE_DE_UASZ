
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../outils/verifier_acces.php';
require_once __DIR__ . '/../../configuration/connexion_bd.php';

exigerAcces('profil');

function repondre($succes, $message, $donnees = null, $code = 200)
{
    http_response_code($code);

    echo json_encode([
        'succes' => $succes,
        'message' => $message,
        'donnees' => $donnees
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

function lireDonnees()
{
    $contenu = file_get_contents('php://input');
    $donnees = json_decode($contenu, true);

    return is_array($donnees) ? $donnees : $_POST;
}

$idUtilisateur = $_SESSION['utilisateur_id'] ?? null;

if (!$idUtilisateur) {
    repondre(false, 'Session expirée. Veuillez vous reconnecter.', null, 401);
}

if (empty($_SESSION['csrf_profil'])) {
    $_SESSION['csrf_profil'] = bin2hex(random_bytes(32));
}

try {

    /* =====================================
       RECUPERATION DU PROFIL
    ===================================== */

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {

        $requete = $connexion->prepare(
            "SELECT id, nom, prenom, identifiant, email,
                    telephone, role, statut, date_creation
             FROM utilisateurs
             WHERE id = :id
             LIMIT 1"
        );

        $requete->execute([
            'id' => $idUtilisateur
        ]);

        $utilisateur = $requete->fetch();

        if (!$utilisateur) {
            repondre(false, 'Utilisateur introuvable.', null, 404);
        }

        repondre(true, 'Profil récupéré.', [
            'utilisateur' => $utilisateur,
            'csrf_token' => $_SESSION['csrf_profil']
        ]);
    }

    /* =====================================
       VERIFICATION DE LA METHODE
    ===================================== */

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        repondre(false, 'Méthode non autorisée.', null, 405);
    }

    $donnees = lireDonnees();

    /* =====================================
       VERIFICATION CSRF
    ===================================== */

    $jeton = $donnees['csrf_token'] ?? '';

    if (
        !is_string($jeton) ||
        !hash_equals($_SESSION['csrf_profil'], $jeton)
    ) {
        repondre(
            false,
            'Requête de sécurité invalide. Actualisez la page.',
            null,
            403
        );
    }

    $action = $donnees['action'] ?? '';

    /* =====================================
       MODIFICATION DU PROFIL
    ===================================== */

    if ($action === 'modifier_profil') {

        $nom = trim($donnees['nom'] ?? '');
        $prenom = trim($donnees['prenom'] ?? '');
        $email = trim($donnees['email'] ?? '');
        $telephone = trim($donnees['telephone'] ?? '');

        if ($nom === '' || $prenom === '') {
            repondre(
                false,
                'Le nom et le prénom sont obligatoires.',
                null,
                422
            );
        }

        if (
            mb_strlen($nom) > 100 ||
            mb_strlen($prenom) > 100
        ) {
            repondre(false, 'Le nom ou le prénom est trop long.', null, 422);
        }

        if (
            $email !== '' &&
            !filter_var($email, FILTER_VALIDATE_EMAIL)
        ) {
            repondre(false, 'Adresse e-mail invalide.', null, 422);
        }

        if (
            mb_strlen($email) > 150 ||
            mb_strlen($telephone) > 30
        ) {
            repondre(false, 'L’e-mail ou le téléphone est trop long.', null, 422);
        }

        $requete = $connexion->prepare(
            "UPDATE utilisateurs
             SET nom = :nom,
                 prenom = :prenom,
                 email = :email,
                 telephone = :telephone
             WHERE id = :id"
        );

        $requete->execute([
            'nom' => $nom,
            'prenom' => $prenom,
            'email' => $email !== '' ? $email : null,
            'telephone' => $telephone !== '' ? $telephone : null,
            'id' => $idUtilisateur
        ]);

        repondre(true, 'Informations personnelles mises à jour.');
    }

    /* =====================================
       MODIFICATION DU MOT DE PASSE
    ===================================== */

    if ($action === 'modifier_mot_de_passe') {

        $ancien = $donnees['ancien_mot_de_passe'] ?? '';
        $nouveau = $donnees['nouveau_mot_de_passe'] ?? '';
        $confirmation = $donnees['confirmation_mot_de_passe'] ?? '';

        if (
            $ancien === '' ||
            $nouveau === '' ||
            $confirmation === ''
        ) {
            repondre(
                false,
                'Veuillez remplir tous les champs du mot de passe.',
                null,
                422
            );
        }

        if (strlen($nouveau) < 8) {
            repondre(
                false,
                'Le nouveau mot de passe doit contenir au moins 8 caractères.',
                null,
                422
            );
        }

        if ($nouveau !== $confirmation) {
            repondre(
                false,
                'Les deux nouveaux mots de passe ne correspondent pas.',
                null,
                422
            );
        }

        $requete = $connexion->prepare(
            "SELECT mot_de_passe
             FROM utilisateurs
             WHERE id = :id
             LIMIT 1"
        );

        $requete->execute([
            'id' => $idUtilisateur
        ]);

        $compte = $requete->fetch();

        if (
            !$compte ||
            !password_verify($ancien, $compte['mot_de_passe'])
        ) {
            repondre(
                false,
                'L’ancien mot de passe est incorrect.',
                null,
                422
            );
        }

        $nouveauHash = password_hash($nouveau, PASSWORD_DEFAULT);

        $requete = $connexion->prepare(
            "UPDATE utilisateurs
             SET mot_de_passe = :mot_de_passe
             WHERE id = :id"
        );

        $requete->execute([
            'mot_de_passe' => $nouveauHash,
            'id' => $idUtilisateur
        ]);

        repondre(true, 'Mot de passe modifié avec succès.');
    }

    repondre(false, 'Action inconnue.', null, 400);

} catch (PDOException $erreur) {

    error_log('Erreur profil : ' . $erreur->getMessage());

    repondre(
        false,
        'Une erreur est survenue lors du traitement.',
        null,
        500
    );

} catch (Throwable $erreur) {

    error_log('Erreur générale profil : ' . $erreur->getMessage());

    repondre(
        false,
        'Une erreur inattendue est survenue.',
        null,
        500
    );
}

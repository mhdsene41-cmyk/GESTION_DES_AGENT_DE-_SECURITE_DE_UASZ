
<?php
require_once __DIR__ . '/../outils/verifier_acces.php';
require_once __DIR__ . '/../../configuration/connexion_bd.php';

exigerAcces('rapports');

header('Content-Type: application/json; charset=utf-8');

function envoyerJSON($succes, $donnees = [], $message = '')
{
    echo json_encode([
        'succes' => $succes,
        'donnees' => $donnees,
        'message' => $message
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

function validerDateRapport($date)
{
    if ($date === null || $date === '') {
        return true;
    }

    $objetDate = DateTime::createFromFormat('Y-m-d', $date);

    return $objetDate && $objetDate->format('Y-m-d') === $date;
}

function obtenirStatistiques($connexion, $table, $colonneDate, $colonneGroupe, $dateDebut, $dateFin)
{
    $sql = "SELECT $colonneGroupe AS libelle, COUNT(*) AS total
            FROM $table
            WHERE 1 = 1";

    $parametres = [];

    if ($dateDebut !== '') {
        $sql .= " AND $colonneDate >= :dateDebut";
        $parametres[':dateDebut'] = $dateDebut;
    }

    if ($dateFin !== '') {
        $sql .= " AND $colonneDate < DATE_ADD(:dateFin, INTERVAL 1 DAY)";
        $parametres[':dateFin'] = $dateFin;
    }

    $sql .= " GROUP BY $colonneGroupe ORDER BY $colonneGroupe";

    $requete = $connexion->prepare($sql);
    $requete->execute($parametres);

    $resultats = [];

    foreach ($requete->fetchAll(PDO::FETCH_ASSOC) as $ligne) {
        $resultats[$ligne['libelle']] = (int) $ligne['total'];
    }

    return $resultats;
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        envoyerJSON(false, [], 'Méthode non autorisée.');
    }

    $dateDebut = trim($_GET['dateDebut'] ?? '');
    $dateFin = trim($_GET['dateFin'] ?? '');

    if (!validerDateRapport($dateDebut) || !validerDateRapport($dateFin)) {
        envoyerJSON(false, [], 'Les dates fournies sont invalides.');
    }

    if ($dateDebut !== '' && $dateFin !== '' && $dateDebut > $dateFin) {
        envoyerJSON(false, [], 'La date de début doit précéder la date de fin.');
    }

    // Nombre total d'agents actuellement actifs.
    $requeteAgents = $connexion->query(
        "SELECT COUNT(*) FROM agents WHERE statut = 'actif'"
    );
    $totalAgents = (int) $requeteAgents->fetchColumn();

    // Statistiques par module.
    $presences = obtenirStatistiques(
        $connexion,
        'presences',
        'date_presence',
        'statut',
        $dateDebut,
        $dateFin
    );

    $incidents = obtenirStatistiques(
        $connexion,
        'incidents',
        'date_incident',
        'statut',
        $dateDebut,
        $dateFin
    );

    $demandes = obtenirStatistiques(
        $connexion,
        'demandes',
        'date_demande',
        'statut',
        $dateDebut,
        $dateFin
    );

    $affectations = obtenirStatistiques(
        $connexion,
        'affectations',
        'date_affectation',
        'etat',
        $dateDebut,
        $dateFin
    );

    $totalPresences = array_sum($presences);
    $totalIncidents = array_sum($incidents);
    $totalDemandes = array_sum($demandes);
    $totalAffectations = array_sum($affectations);

    $donnees = [
        'agents' => $totalAgents,
        'presences' => $totalPresences,
        'incidents' => $totalIncidents,
        'demandes' => $totalDemandes,

        'details' => [
            'presences' => $presences,
            'incidents' => $incidents,
            'demandes' => $demandes,
            'affectations' => $affectations
        ],

        'totaux' => [
            'agents' => $totalAgents,
            'presences' => $totalPresences,
            'incidents' => $totalIncidents,
            'demandes' => $totalDemandes,
            'affectations' => $totalAffectations
        ]
    ];

    envoyerJSON(true, $donnees, 'Rapports chargés avec succès.');

} catch (PDOException $erreur) {
    error_log('Erreur rapports : ' . $erreur->getMessage());
    envoyerJSON(false, [], 'Une erreur est survenue lors du chargement des statistiques.');
} catch (Throwable $erreur) {
    error_log('Erreur rapports : ' . $erreur->getMessage());
    envoyerJSON(false, [], 'Impossible de charger les rapports.');
}
